import {describe,it,expect} from 'vitest';
import {rainSheetFactor} from './rainSheetFactor';
import {integrateMediaSegment} from './medium';

describe('fixed broad rain shaft trial',()=>{
 it('opens a zero interval and concentrates high sheets without a uniform fade',()=>{
  for(const sheet of [0,.2,.35])expect(rainSheetFactor(sheet)).toBe(0);
  for(const sheet of [.65,.8,1])expect(rainSheetFactor(sheet)).toBe(2);
  expect(rainSheetFactor(.5)).toBeCloseTo(.5,12);
  // Compare with actual old material coefficients, not another copy of the new helper.
  expect(rainSheetFactor(.25)).toBeLessThan(.15+1.85*.25*.25);
  expect(rainSheetFactor(.75)).toBeGreaterThan(.15+1.85*.75*.75);
 });
 it('remains finite, bounded and monotone for every UNORM8 sample code',()=>{
  let previous=0;
  for(let code=0;code<=255;code++){
   const factor=rainSheetFactor(code/255);
   expect(Number.isFinite(factor)).toBe(true);
   expect(factor).toBeGreaterThanOrEqual(previous);
   expect(factor).toBeGreaterThanOrEqual(0);expect(factor).toBeLessThanOrEqual(2);
   previous=factor;
  }
 });
 it('opens transmission through weak shafts while making strong shafts optically denser',()=>{
  // A one-km, rain-only segment isolates broad coverage; source/base, amount,
  // attachment, evaporation and the original streak factor are common scalars.
  const common=.6*.8*1*(.35+1.3*.5)*.8*.85;
  const segment=(factor:number)=>integrateMediaSegment(0,[0,0,0],common*factor,[.3,.3,.3],1);
  const weakOld=segment(.15+1.85*.25*.25),weakNew=segment(rainSheetFactor(.25));
  const strongOld=segment(.15+1.85*.75*.75),strongNew=segment(rainSheetFactor(.75));
  expect(weakOld.transmittance).toBeLessThan(1);
  expect(weakNew.transmittance).toBe(1);expect(weakNew.radiance).toEqual([0,0,0]);
  expect(strongNew.transmittance).toBeLessThan(strongOld.transmittance);
  // No claim of conserved column mass, GPU arithmetic or a rendered contrast gain.
 });
});
