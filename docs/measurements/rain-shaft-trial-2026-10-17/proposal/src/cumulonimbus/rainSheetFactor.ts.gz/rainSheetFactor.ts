/** Fixed artistic trial for finite samples of the existing broad sheet field.
 * A zero interval separates rain shafts; high values concentrate the same field.
 * These thresholds are not microphysical measurements or a mass normalization.
 * Native distance, virga and motion still require visual qualification.
 */
export const RAIN_SHEET_LOW=.35;
export const RAIN_SHEET_HIGH=.65;
export const RAIN_SHEET_PEAK=2;
export function rainSheetFactor(sheetValue:number):number{
 const t=Math.max(0,Math.min(1,(sheetValue-RAIN_SHEET_LOW)/(RAIN_SHEET_HIGH-RAIN_SHEET_LOW)));
 const shaftCoverage=t*t*(3-2*t);
 return RAIN_SHEET_PEAK*shaftCoverage*shaftCoverage;
}
export const RAIN_SHEET_WGSL=`
fn rainSheetFactor(sheetValue:f32)->f32{
 let shaftCoverage=smoothstep(${RAIN_SHEET_LOW},${RAIN_SHEET_HIGH},sheetValue);
 return ${RAIN_SHEET_PEAK}.0*shaftCoverage*shaftCoverage;
}`;
