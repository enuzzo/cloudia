# Attribuzione di tre punti della baseline74

Esito: il becco interno è prodotto dal rigonfiamento laterale interno della torre matura, non dal primo cap dell’incus. Non è una conclusione sull’intera fotografia. Nessuna nuova variante preparata. Audit chiuso e congelato; la proposta di rientro sotto è INESEGUITA e NON AUTORIZZATA da root, perché allargherebbe la U già critica.

## Riferimento congelato e camera

Baseline10493afa7f6d90389c39e17b2cad79397dfdac01. Volume SHA-256 `a53410c45b04143710cffd098b6a33deade3242c66ecf7eecc6405a214a93b00`;10sorgenti copiati e verificati in frozen-source. La ricostruzione del layout e dei parent è identica alle1.918Lobe della baseline già archiviata; non usa l’helper orientato ritirato. Il layout è stato ricontrollato anche su72/73/77/80 senza raster o bake.

Immagine: baseline-74-front.jpg copiata byte per byte, SHA-256 `bfeffac68a071d1c6920ccd5480a13f56eb9102140f9c9d277acf08aa77e2ec2`. La pagina pixel-map.html contiene soltanto una tabella UV/quote/pixel con le identità dei contributor, senza raster-base o annotazioni. Il JPEG rimane separato e invariato. Il documento HTML non è stato aperto in browser durante questo audit; la fotografia originale è stata ispezionata direttamente.

Camera source: origin[0,2.7,16], forward[0,0,−1], aspect16/9, tanFov0.2867, approach/inspection0. Formula screenY=1−2v−0.16; surface1 influisce sul confronto ma approach0 mantiene il raggio orbitale16. Output nativo2560×1440, JPEG restituito1280×720. I punti richiesti sono arrotondati al centro del pixel nativo contenente la coordinata.

Box supporto e emptyStep0.0546875 derivati dalle precedenti misure native256 dello stesso volume e confrontati esattamente con il raw v50-worker-rain-30.json.gz. Il raw usa un’altra posa/condizione meteo, ma queste due quantità dipendono dallo stesso volume e dal limite conservativo, non da pitch/rain; la camera è quella frontale del confronto. Provenienza/SHA in prior-native-support.json e v50-raw-crosscheck.json.

## Metodo e significato dei pesi

Tre soli raggi con il passo ordinario7/384 e jitter derivato dal pixel. Il salto vuoto originale è3volte il passo ordinario: omettere i salti in regioni a densità nulla conserva la fase dei campioni attivi. Sono applicati t60, wind55%, drift, inverse shear/growth, riferimento flow16³ filtrato half-float e il campionatore fine originale. Il macroR8 a256³ e il dettaglioRGB a128³ vengono calcolati esclusivamente nei texel richiesti; nessun volume completo.

La smooth union è ricostruita nell’ordine originale, con arrotondamento Float32 del field, bounds di raster originali, spalla10493, carving originale e quantizzazione R8. Ai6campioni effettivi che attraversanoτ1/τ3 si ricostruiscono le derivate della catena prefixSDF; sono poi pesate con l’interpolazione macroR8 degli8vicini. Questi pesi identificano chi sostiene il field locale: non sono contributi additivi di massa o di RGB. L’ablazione locale del gruppo dominante verifica il significato causale.

La prima passata valutava il punto interpolato dentro il segmento che attraversaτ. È preservata separatamente; il report finale usa la vera posizione di campionamento del marcher, mantenendo anche hitT/interpolatedWorld. Le12posizioni distinte delle due letture restano sotto20; nessun altro raggio o sweep.

| Punto | Pixel nativo | τ | Dominanti effettivi | Source XYZ |
|---|---|---:|---|---|
| becco | [1369, 437] | 1 | 5: 94.52%; 537: 4.34%; 547: 1.14% | 0.315412, 3.635240, 0.586590 |
| becco | [1369, 437] | 3 | 5: 100.00% | 0.354318, 3.634681, 0.421726 |
| polso | [1351, 370] | 1 | shoulder: 76.13%; 402: 9.89%; 3: 5.58% | 0.218057, 4.104808, 0.282482 |
| polso | [1351, 370] | 3 | shoulder: 90.07%; 402: 4.15%; 3: 2.22% | 0.229774, 4.111229, 0.150572 |
| spalla-esterna | [1128, 462] | 1 | 15: 98.14%; 2: 1.86% | -1.097816, 3.474232, 0.389265 |
| spalla-esterna | [1128, 462] | 3 | 15: 100.00% | -1.127806, 3.473731, 0.202240 |

Core5 = main.shoulder0: centro[0.1627321101,3.5844864041,0.1434988400], raggi[0.6378708804,0.6040369198,0.8316949884], blend0.16. Il core da solo sostiene94.52% del beccoτ1 e100% aτ3. Billow537(parent5) aggiunge4.34% e547(parent5)1.14% aτ1. Nessun contributo di cap0, collars dell’incus o testa giovane a quei due stencil.

La spalla inclinata promossa10493 sostiene76.13%/90.07% del polsoτ1/τ3; intervengono anche billow402(parent4, testa matura), collo/core3 e contributi minori. La spalla esterna proviene98.14%/100% dal core15 (upwind.upper, massa laterale preesistente) con1.86% del core2 al primo campione.

L’origine di core5 è il ciclo di spalle laterali del turret maturo in frozen-source/volume.ts:184–192. Per74: j0, angle0.6587944723, level0.6191384683, radius0.7213875305, bulge0.6792897148 prima delle trasformazioni comuni. I dati completi sono in semantic-portability.json; primitive-contributors.json include i singoli ellissoidi e i parent reali.

## Un solo controfattuale locale

Si omette esclusivamente il gruppo core5+18billow+72figli nel calcolo degli stessi8texel dei6stencil, preservando ogni altro contributo e l’ordine dell’unione. Beccoτ1:0.770251→0; beccoτ3:0.474717→0. Polsoτ1:0.871372→0.870978 (−0.0452%); polsoτ3 e i due campioni della spalla esterna invariati. Nessun globale modificato né render prodotto.

È prova della responsabilità locale del gruppo, non una dimostrazione che eliminarlo migliori la nube: aprirebbe ulteriormente la U ed esporrebbe la struttura retrostante.

## Proposta concreta, non implementata

Se si decide un prossimo trial sul becco, propongo una sola ritrazione laterale dell’intero rigonfiamento interno della torre matura, mantenendo raggi, Y e decorazioni. Il gruppo va selezionato per parent semantico della torre matura e proiezione geometrica verso la fondazione della cella giovane, mai per indice/seed o j0. Alla quota del core si interpola l’asse fondazione→testa matura; il gruppo con massima proiezione positiva sul vettore orizzontale verso la cella giovane rientra fino al piano passante per quell’asse, rimuovendo soltanto tale componente laterale. Non ci sono fattori0.5 o altri parametri da cercare.

| Seed | Spalla più interna, dal layout reale | Core diagnostico | Proiezione verso giovane |
|---|---:|---:|---:|
| 72 | nessun ruolo sheared: invariato | — | — |
| 73 | nessun ruolo sheared: invariato | — | — |
| 74 | j0 | 5 | 0.621072280 |
| 77 | j1 | 6 | 0.613791247 |
| 80 | j1 | 6 | 0.344182043 |

Per74 il vettore di ritrazione derivato sarebbe[-0.579758379, 0.000000000, -0.222735265]; non è stato applicato né rivalutato. Su77/80 il lato interno appartiene a j1, confermando che j0 non è un ruolo stabile. La portabilità dimostrata è del selettore geometrico sul layout; non dell’effetto artistico nei pixel77/80, che qui non sono stati tracciati.

Tradeoff: ridurrebbe il becco e conserverebbe il rilievo sul corpo, ma potrebbe rendere la torre più verticale/aprire la U. Il polso resta dominato dalla spalla10493 e non verrebbe corretto direttamente. Questo trial sarebbe un intervento sul rigonfiamento identificato, non una soluzione del fan torre→incus. La scelta di provarlo deve dipendere dalla priorità visiva; la mappa non giustifica allargamenti ciechi ad altri gruppi. Criterio decisivo: l’eventuale rientro deve essere giudicato per continuità della massa e larghezza della sella/U, oltre alla sparizione del becco. Il suo effetto geometrico tende ad aprire la U, quindi può peggiorare proprio la forma globale già criticata.

## Limiti e riproduzione

CPU con arithmetic binary64, Float32 del field e flow half-float filtrato; WGSL può differire per precisione e jitter entro il passo. τ misura estinzione: non sono ricostruiti RGB, LUT atmosferica o cache di luce dell’intera fotografia. Le formule materiali/erosione/estinzione originali sono conservate. L’illuminazione cambia quanto un contributo appare chiaro, non chi occupa questi campioni.

Lavoro finale:6stencil di attribuzione+6controfattuali alle stesse posizioni,465campioni su3raggi,1.636macrotexel in cache su16.777.216;1.424texel dettaglio128³ e95texel flow16³. Nessun bake/test/buildAPP/GPU/browser o nuovo candidato.

Riproduzione puntuale: `node audit-pixels.mjs` dalla presente directory, con le dipendenze locali originali presenti. Lo script genera solo layout e texel richiesti, verifica ogni layout contro le copie congelate già archiviate, poi riscrive esclusivamente gli output esterni dell’audit. Il codice annotato è in layout-trace.ts e i dati completi compressi in layout-and-stencils.json.gz. Nessuna modifica a prodotto/docs/Git o candidati precedenti.

## Decisione finale di root

Audit terminato. La mappa numerica identifica la causa locale del becco, ma root non autorizza il rientro laterale proposto: aprirebbe la U, difetto prioritario. La proposta rimane integralmente conservata come ineseguita. Un eventuale prossimo lavoro macro dovrà considerare una ridistribuzione della massa che alimenti il corpo senza aggravare il vuoto, non un altro abbassamento o una rasatura. Nessun nuovo candidato, test, bake o build è stato avviato dopo questo verdetto.
