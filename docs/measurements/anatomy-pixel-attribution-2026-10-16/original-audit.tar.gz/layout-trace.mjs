// ../../../../../Documents/Codex/Cloudia-QA-2026-10-16-cycle15/secondary-hierarchy/baseline-source/src/cumulonimbus/sun.ts
var SUN_LEFT = [-0.75, 0.8, 0.24];
var SUN_RIGHT = [0.75, 0.8, 0.24];

// ../../../../../Documents/Codex/Cloudia-QA-2026-10-16-cycle15/secondary-hierarchy/baseline-source/src/cumulonimbus/motion.ts
var MOTION_LOOP_SECONDS = 68;
var THERMAL_DISPLACEMENT = [0.42, 0.82, 0.34];
var smooth = (a, b, x) => {
  const u = Math.max(0, Math.min(1, (x - a) / (b - a)));
  return u * u * (3 - 2 * u);
};
function motionState(time, seed) {
  time = Math.max(0, time);
  const phase = seed % 71 / 71 * 0.35;
  const thermal = (period, offset, radius) => {
    const age = (time / period + offset) % 1;
    return [0.9 + age * 4.5, Math.sin(Math.PI * age) ** 2, radius];
  };
  return {
    height: 0.68 + 0.32 * smooth(0, 28, time),
    width: 0.88 + 0.12 * smooth(0, 28, time),
    anvil: 0.58 + 0.42 * smooth(8, 38, time),
    time,
    seedPhase: phase,
    family: seed % 3,
    thermalA: thermal(34, phase, 1.15),
    thermalB: thermal(MOTION_LOOP_SECONDS, phase + 0.47, 1.05)
  };
}
function referencePosition(position, state, iceRange, wind) {
  const y = 0.72 + (position[1] - 0.72) / state.height, ice = smooth(iceRange[0], iceRange[1], y);
  const shear = Math.max(0, Math.min(1, (position[1] - 0.72) / 6.2)) ** 1.5;
  return [(position[0] - wind[0] * shear) * ((1 - ice) / state.width + ice / state.anvil), y, (position[2] - wind[1] * shear) / state.width];
}
function writeDisplacement(x, y, z, state, iceRange, out) {
  if (state.seedPhase !== void 0) {
    const ice2 = smooth(iceRange[0], iceRange[1], y), gate2 = smooth(0.75, 1.3, y) * (1 - ice2), scatterGate = smooth(0.75, 1.5, y);
    const dispersion = state.dispersion ?? 0, spread = state.family === 1 ? 1.35 : 1;
    let sx2 = 0, sy2 = 0, sz2 = 0, erosion = 0;
    for (let i = 0; i < 5; i++) {
      const age2 = (state.time / (18.7 + i * 4.23) + i * 0.213 + state.seedPhase) % 1;
      const cx = [-0.85, 0.55, -0.18, 1, -1.2][i] * spread + 0.2 * Math.sin(state.time * 0.037 + i), cz = [0.15, -0.45, 0.65, 0.3, -0.35][i];
      const dx2 = x - cx, dy2 = y - (0.95 + age2 * (iceRange[0] - 0.45)), dz2 = z - cz, r = [1.28, 1.15, 0.95, 0.9, 1.05][i];
      const radial = (dx2 * dx2 + dz2 * dz2) / (r * r), w2 = Math.max(0, 1 - radial - dy2 * dy2 / (r * r));
      const a = w2 * w2 * Math.sin(Math.PI * age2) ** 2 * gate2;
      sx2 += dx2 * 0.9 * a;
      sy2 += (1.1 - 1.6 * radial) * a;
      sz2 += dz2 * 0.85 * a;
      erosion += 0.14 * a * radial;
    }
    const age = (state.time / 23.7 + state.seedPhase + 0.37) % 1;
    const dx = x - (1.45 + 0.18 * Math.sin(state.time * 0.13)), dz = z + 0.1;
    const dy = y - (iceRange[0] - (iceRange[0] - 1.05) * age), w = Math.max(0, 1 - (dx * dx + dz * dz) / 1.05 ** 2 - dy * dy / 1.4 ** 2);
    const sink = w * w * Math.sin(Math.PI * age) ** 2 * scatterGate;
    sy2 -= 0.95 * sink;
    sx2 += dx * 0.45 * sink;
    sz2 += dz * 0.45 * sink;
    erosion += 0.06 * sink;
    const outflow = ice2 * smooth(-1, 1.5, x);
    sx2 += outflow * 0.22 * Math.sin(y * 3.3 + z * 0.8 - state.time * 0.31);
    sy2 += outflow * 0.055 * Math.sin(x * 2.1 + z * 0.9 - state.time * 0.37);
    sz2 += outflow * 0.1 * Math.sin(x * 0.9 - y * 2 + state.time * 0.17);
    sx2 += dispersion * x * 0.4 * scatterGate;
    sy2 += dispersion * 0.28 * scatterGate;
    sz2 += dispersion * z * 0.4 * scatterGate;
    out[0] = sx2 / (1 + Math.abs(sx2) / THERMAL_DISPLACEMENT[0]);
    out[1] = sy2 / (1 + Math.abs(sy2) / THERMAL_DISPLACEMENT[1]);
    out[2] = sz2 / (1 + Math.abs(sz2) / THERMAL_DISPLACEMENT[2]);
    out[3] = Math.min(0.18, erosion + outflow * 0.035 * (0.5 + 0.5 * Math.sin(x * 3.4 + y * 5.1 - state.time * 0.43)) + dispersion * 0.1 * scatterGate);
    return;
  }
  const ice = smooth(iceRange[0], iceRange[1], y), gate = smooth(0.75, 1.3, y) * (1 - ice);
  let sx = 0, sy = 0, sz = 0;
  for (let i = 0; i < 2; i++) {
    const thermal = i === 0 ? state.thermalA : state.thermalB;
    const dx = x - (i === 0 ? -0.65 : 0.48), dy = y - thermal[0], dz = z - (i === 0 ? 0.1 : -0.35);
    const radius2 = thermal[2] * thermal[2], radial = (dx * dx + dz * dz) / radius2;
    const w = Math.max(0, 1 - radial - dy * dy / radius2), a = w * w * thermal[1] * gate;
    sx += dx * 0.32 * a;
    sy += (0.38 - 0.5 * radial) * a;
    sz += dz * 0.32 * a;
  }
  out[0] = sx;
  out[1] = sy + ice * 0.05 * Math.sin(x * 1.4 - state.time * (2 * Math.PI / MOTION_LOOP_SECONDS) + z * 0.4);
  out[2] = sz;
  out[3] = 0;
}

// ../../../../../Documents/Codex/Cloudia-QA-2026-10-16-cycle15/secondary-hierarchy/baseline-source/src/cumulonimbus/inclinedShoulder.ts
function prepareInclinedShoulder(start, end, width, depth) {
  if (![...start, ...end, width, depth].every(Number.isFinite) || width <= 0 || depth <= 0) {
    throw new RangeError("An inclined shoulder needs finite anchors and positive radii");
  }
  const delta = end.map((value, axis) => value - start[axis]);
  const length = Math.hypot(...delta);
  if (length < 1e-9) throw new RangeError("An inclined shoulder needs distinct anchors");
  const along = delta.map((value) => value / length);
  const horizontal = Math.hypot(along[0], along[1]);
  const side = horizontal > 1e-9 ? [along[1] / horizontal, -along[0] / horizontal, 0] : [1, 0, 0];
  const through = [
    along[1] * side[2] - along[2] * side[1],
    along[2] * side[0] - along[0] * side[2],
    along[0] * side[1] - along[1] * side[0]
  ];
  const center = start.map((value, axis) => (value + end[axis]) * 0.5);
  const reach = length * 0.5 + Math.min(width, depth) * 0.32;
  const slope = Math.min(reach, width, depth);
  const radius = center.map((_, axis) => Math.hypot(reach * along[axis], width * side[axis], depth * through[axis]));
  return {
    min: center.map((value, axis) => value - radius[axis]),
    max: center.map((value, axis) => value + radius[axis]),
    sample(x, y, z) {
      const dx = x - center[0], dy = y - center[1], dz = z - center[2];
      return (1 - Math.hypot(
        (dx * along[0] + dy * along[1] + dz * along[2]) / reach,
        (dx * side[0] + dy * side[1] + dz * side[2]) / width,
        (dx * through[0] + dy * through[1] + dz * through[2]) / depth
      )) * slope;
    }
  };
}

// node_modules/three/src/constants.js
var NeverDepth = 0;
var AlwaysDepth = 1;
var LessDepth = 2;
var LessEqualDepth = 3;
var EqualDepth = 4;
var GreaterEqualDepth = 5;
var GreaterDepth = 6;
var NotEqualDepth = 7;

// node_modules/three/src/utils.js
var _setConsoleFunction = null;
function enhanceLogMessage(params) {
  const message = params[0];
  if (typeof message === "string" && message.startsWith("TSL:")) {
    const stackTrace = params[1];
    if (stackTrace && stackTrace.isStackTrace) {
      params[0] += " " + stackTrace.getLocation();
    } else {
      params[1] = 'Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.';
    }
  }
  return params;
}
function warn(...params) {
  params = enhanceLogMessage(params);
  const message = "THREE." + params.shift();
  if (_setConsoleFunction) {
    _setConsoleFunction("warn", message, ...params);
  } else {
    const stackTrace = params[0];
    if (stackTrace && stackTrace.isStackTrace) {
      console.warn(stackTrace.getError(message));
    } else {
      console.warn(message, ...params);
    }
  }
}
var ReversedDepthFuncs = {
  [NeverDepth]: AlwaysDepth,
  [LessDepth]: GreaterDepth,
  [EqualDepth]: NotEqualDepth,
  [LessEqualDepth]: GreaterEqualDepth,
  [AlwaysDepth]: NeverDepth,
  [GreaterDepth]: LessDepth,
  [NotEqualDepth]: EqualDepth,
  [GreaterEqualDepth]: LessEqualDepth
};

// node_modules/three/src/math/MathUtils.js
var DEG2RAD = Math.PI / 180;
var RAD2DEG = 180 / Math.PI;
function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

// node_modules/three/src/extras/DataUtils.js
var _tables = /* @__PURE__ */ _generateTables();
function _generateTables() {
  const buffer = new ArrayBuffer(4);
  const floatView = new Float32Array(buffer);
  const uint32View = new Uint32Array(buffer);
  const baseTable = new Uint32Array(512);
  const shiftTable = new Uint32Array(512);
  for (let i = 0; i < 256; ++i) {
    const e = i - 127;
    if (e < -27) {
      baseTable[i] = 0;
      baseTable[i | 256] = 32768;
      shiftTable[i] = 24;
      shiftTable[i | 256] = 24;
    } else if (e < -14) {
      baseTable[i] = 1024 >> -e - 14;
      baseTable[i | 256] = 1024 >> -e - 14 | 32768;
      shiftTable[i] = -e - 1;
      shiftTable[i | 256] = -e - 1;
    } else if (e <= 15) {
      baseTable[i] = e + 15 << 10;
      baseTable[i | 256] = e + 15 << 10 | 32768;
      shiftTable[i] = 13;
      shiftTable[i | 256] = 13;
    } else if (e < 128) {
      baseTable[i] = 31744;
      baseTable[i | 256] = 64512;
      shiftTable[i] = 24;
      shiftTable[i | 256] = 24;
    } else {
      baseTable[i] = 31744;
      baseTable[i | 256] = 64512;
      shiftTable[i] = 13;
      shiftTable[i | 256] = 13;
    }
  }
  const mantissaTable = new Uint32Array(2048);
  const exponentTable = new Uint32Array(64);
  const offsetTable = new Uint32Array(64);
  for (let i = 1; i < 1024; ++i) {
    let m = i << 13;
    let e = 0;
    while ((m & 8388608) === 0) {
      m <<= 1;
      e -= 8388608;
    }
    m &= ~8388608;
    e += 947912704;
    mantissaTable[i] = m | e;
  }
  for (let i = 1024; i < 2048; ++i) {
    mantissaTable[i] = 939524096 + (i - 1024 << 13);
  }
  for (let i = 1; i < 31; ++i) {
    exponentTable[i] = i << 23;
  }
  exponentTable[31] = 1199570944;
  exponentTable[32] = 2147483648;
  for (let i = 33; i < 63; ++i) {
    exponentTable[i] = 2147483648 + (i - 32 << 23);
  }
  exponentTable[63] = 3347054592;
  for (let i = 1; i < 64; ++i) {
    if (i !== 32) {
      offsetTable[i] = 1024;
    }
  }
  return {
    floatView,
    uint32View,
    baseTable,
    shiftTable,
    mantissaTable,
    exponentTable,
    offsetTable
  };
}
function toHalfFloat(val) {
  if (Math.abs(val) > 65504) warn("DataUtils.toHalfFloat(): Value out of range.");
  val = clamp(val, -65504, 65504);
  _tables.floatView[0] = val;
  const f = _tables.uint32View[0];
  const e = f >> 23 & 511;
  return _tables.baseTable[e] + ((f & 8388607) >> _tables.shiftTable[e]);
}
function fromHalfFloat(val) {
  const m = val >> 10;
  _tables.uint32View[0] = _tables.mantissaTable[_tables.offsetTable[m] + (val & 1023)] + _tables.exponentTable[m];
  return _tables.floatView[0];
}
var DataUtils = class {
  /**
   * Returns a half precision floating point value (FP16) from the given single
   * precision floating point value (FP32).
   *
   * @param {number} val - A single precision floating point value.
   * @return {number} The FP16 value.
   */
  static toHalfFloat(val) {
    return toHalfFloat(val);
  }
  /**
   * Returns a single precision floating point value (FP32) from the given half
   * precision floating point value (FP16).
   *
   * @param {number} val - A half precision floating point value.
   * @return {number} The FP32 value.
   */
  static fromHalfFloat(val) {
    return fromHalfFloat(val);
  }
};

// ../../../../../Documents/Codex/Cloudia-QA-2026-10-16-cycle15/secondary-hierarchy/baseline-source/src/cumulonimbus/volume.ts
var BOUNDS_MIN = [-5, -0.5, -3.5];
var BOUNDS_SIZE = [10, 8.5, 7];
var EXTINCTION = 18;
var ICE_EXTINCTION = 6.5;
var materialExtinction = (ice) => EXTINCTION + (ICE_EXTINCTION - EXTINCTION) * ice;
var VOLUME_RESOLUTION = 256;
var DETAIL_RESOLUTION = 128;
var EMPTY_SKIP_LIMIT = 0.04;
var voxelCenter = (index, axis, size) => BOUNDS_MIN[axis] + (index + 0.5) / size * BOUNDS_SIZE[axis];
var heightErosionScale = (worldY) => (0.48 + 0.52 * smoothstep(1.6, 2.5, worldY)) * (1 - 0.55 * smoothstep(5.1, 6.2, worldY));
function densitySupportBounds(envelope) {
  const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  for (let z = 0; z < envelope.size; z++) for (let y = 0; y < envelope.size; y++) for (let x = 0; x < envelope.size; x++) {
    if (!envelope.data[((z * envelope.size + y) * envelope.size + x) * 4]) continue;
    const point = [x, y, z];
    for (let axis = 0; axis < 3; axis++) {
      min[axis] = Math.min(min[axis], point[axis]);
      max[axis] = Math.max(max[axis], point[axis]);
    }
  }
  if (!Number.isFinite(min[0])) return { min: [...BOUNDS_MIN], max: BOUNDS_MIN.map((v, i) => v + BOUNDS_SIZE[i]) };
  const anchor = [0, 0.72, 0];
  for (let axis = 0; axis < 3; axis++) {
    const voxel = BOUNDS_SIZE[axis] / envelope.size, pad = voxel + [0.08, 0.06, 0.08][axis] + THERMAL_DISPLACEMENT[axis];
    min[axis] = Math.max(BOUNDS_MIN[axis], Math.min(anchor[axis], BOUNDS_MIN[axis] + (min[axis] + 0.5) * voxel - pad));
    max[axis] = Math.min(BOUNDS_MIN[axis] + BOUNDS_SIZE[axis], Math.max(anchor[axis], BOUNDS_MIN[axis] + (max[axis] + 0.5) * voxel + pad));
  }
  return { min, max };
}
var morphologyFamily = (seed) => ["congestus", "multicell", "sheared"][(Math.trunc(seed) % 3 + 3) % 3];
var clamp2 = (v) => Math.max(0, Math.min(1, v));
var smoothstep = (a, b, x) => {
  const t = clamp2((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};
function random(seed) {
  return () => {
    seed |= 0;
    seed = seed + 1831565813 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t ^= t + Math.imul(t ^ t >>> 7, 61 | t);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function cloudParameters(seed) {
  const rng = random(seed ^ 1103547991), family = morphologyFamily(seed);
  const height = rng(), width = rng(), spread = rng(), lean = rng();
  if (family === "congestus") return { family, towerHeight: 0.65 + height * 0.09, towerWidth: 1 + width * 0.12, anvilSpread: 0.55 + spread * 0.16, windLean: (lean - 0.5) * 0.045 };
  if (family === "multicell") return { family, towerHeight: 0.78 + height * 0.12, towerWidth: 1 + width * 0.1, anvilSpread: 0.82 + spread * 0.18, windLean: 0.025 + lean * 0.045 };
  return { family, towerHeight: 0.73 + height * 0.13, towerWidth: 0.96 + width * 0.12, anvilSpread: 0.94 + spread * 0.12, windLean: 0.19 + lean * 0.07 };
}
function noise(x, y, z, seed, period = 0) {
  const ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z);
  let fx = x - ix, fy = y - iy, fz = z - iz;
  fx = fx * fx * (3 - 2 * fx);
  fy = fy * fy * (3 - 2 * fy);
  fz = fz * fz * (3 - 2 * fz);
  const h = (a, b, c) => {
    if (period) {
      a &= period - 1;
      b &= period - 1;
      c &= period - 1;
    }
    let n = Math.imul(a, 73856093) ^ Math.imul(b, 19349663) ^ Math.imul(c, 83492791) ^ seed;
    n = Math.imul(n ^ n >>> 13, 1274126177);
    return (n >>> 0) / 4294967295;
  };
  const lerp = (a, b, t) => a + (b - a) * t;
  return lerp(
    lerp(lerp(h(ix, iy, iz), h(ix + 1, iy, iz), fx), lerp(h(ix, iy + 1, iz), h(ix + 1, iy + 1, iz), fx), fy),
    lerp(lerp(h(ix, iy, iz + 1), h(ix + 1, iy, iz + 1), fx), lerp(h(ix, iy + 1, iz + 1), h(ix + 1, iy + 1, iz + 1), fx), fy),
    fz
  );
}
function generateDetail(size = DETAIL_RESOLUTION, seed = 71) {
  const data = new Uint8Array(size ** 3 * 4), cellular = cellularNoise(seed + 513);
  for (let z = 0; z < size; z++) for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const px = (x + 0.5) / size, py = (y + 0.5) / size, pz = (z + 0.5) / size, i = ((z * size + y) * size + x) * 4;
    data[i] = Math.round((cellular(px * 32, py * 32, pz * 32) * 0.65 + noise(px * 8, py * 8, pz * 8, seed, 8) * 0.35) * 255);
    data[i + 1] = Math.round(noise(px * 16, py * 16, pz * 16, seed + 21, 16) * 255);
    data[i + 2] = Math.round(noise(px * 32, py * 32, pz * 32, seed + 39, 32) * 255);
    data[i + 3] = 255;
  }
  return { size, data };
}
function sampleDetail(detail, x, y, z, channel, repeat = true) {
  const normalize = (v) => repeat ? v - Math.floor(v) : clamp2(v);
  const { size, data } = detail, px = normalize(x) * size - 0.5, py = normalize(y) * size - 0.5, pz = normalize(z) * size - 0.5;
  const ix = Math.floor(px), iy = Math.floor(py), iz = Math.floor(pz), fx = px - ix, fy = py - iy, fz = pz - iz;
  const index = (v) => repeat ? (v + size) % size : Math.max(0, Math.min(size - 1, v));
  const at = (a, b, c) => data[((index(c) * size + index(b)) * size + index(a)) * 4 + channel] / 255;
  let sum = 0;
  for (let dz = 0; dz < 2; dz++) for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) sum += at(ix + dx, iy + dy, iz + dz) * (dx ? fx : 1 - fx) * (dy ? fy : 1 - fy) * (dz ? fz : 1 - fz);
  return sum;
}
var erodeDensity = (density, erosion) => clamp2((density - erosion) / (1 - erosion));
function iceHeights(seed) {
  const h = cloudParameters(seed).towerHeight;
  return [0.72 + (5.15 - 0.72) * h, 0.72 + (5.95 - 0.72) * h];
}
function sampleCloudDensity(envelope, detail, x, y, z, ice, additionalErosion = 0) {
  const r = sampleDetail(detail, x * 0.3, y * 0.3, z * 0.3, 0), g = sampleDetail(detail, x * 0.3, y * 0.3, z * 0.3, 1), b = sampleDetail(detail, x * 0.3, y * 0.3, z * 0.3, 2);
  const wx = (g - 0.5) * (0.16 - 0.08 * ice), wy = (b - 0.5) * (0.12 - 0.1 * ice), wz = (r - 0.5) * (0.16 - 0.06 * ice);
  const warped = sampleDetail(envelope, (x + wx - BOUNDS_MIN[0]) / 10, (y + wy - BOUNDS_MIN[1]) / 8.5, (z + wz - BOUNDS_MIN[2]) / 7, 0, false);
  let erosion = (1 - r) * 0.38 + (1 - b) * 0.08;
  let material = 1;
  if (ice > 0) {
    const bend = sampleDetail(detail, x * 0.12, y * 0.1, z * 0.06, 1);
    const ix = x * 0.055 + bend * 0.08, iy = y * 0.34 + x * 0.022 + (bend - 0.5) * 0.06, iz = z * 0.08 + (bend - 0.5) * 0.025;
    const wisps = sampleDetail(detail, ix, iy, iz, 0), breakup = sampleDetail(detail, ix, iy, iz, 2);
    erosion = erosion * (1 - ice) + (0.08 + (1 - wisps) * 0.5) * ice;
    const strand = smoothstep(0.3, 0.7, wisps);
    material = 1 - ice + (0.012 + 0.56 * strand ** 1.7) * (0.65 + 0.35 * smoothstep(0.25, 0.75, breakup)) * (1 - 0.7 * smoothstep(0.4, 3.8, x)) * ice;
  }
  return erodeDensity(warped, Math.min(0.92, erosion + additionalErosion)) * material;
}
function bakeOccupancy(envelope, detail, additional = [0, 0, 0]) {
  const coarse = detail.size, fine = envelope.size, mask = new Uint8Array(coarse ** 3);
  for (let z = 0; z < fine; z++) for (let y = 0; y < fine; y++) for (let x = 0; x < fine; x++) {
    if (envelope.data[((z * fine + y) * fine + x) * 4] === 0) continue;
    mask[(Math.floor(z * coarse / fine) * coarse + Math.floor(y * coarse / fine)) * coarse + Math.floor(x * coarse / fine)] = 1;
  }
  const radius = BOUNDS_SIZE.map((extent, axis) => Math.ceil(([0.08, 0.06, 0.08][axis] + additional[axis] + extent / fine) / (extent / coarse)));
  const edge = coarse + 1, difference = new Int32Array(edge ** 3);
  for (let z = 0; z < coarse; z++) for (let y = 0; y < coarse; y++) for (let x = 0; x < coarse; x++) {
    if (!mask[(z * coarse + y) * coarse + x]) continue;
    const lo = [Math.max(0, x - radius[0]), Math.max(0, y - radius[1]), Math.max(0, z - radius[2])];
    const hi = [Math.min(coarse, x + radius[0] + 1), Math.min(coarse, y + radius[1] + 1), Math.min(coarse, z + radius[2] + 1)];
    for (let c = 0; c < 2; c++) for (let b = 0; b < 2; b++) for (let a = 0; a < 2; a++)
      difference[((c ? hi[2] : lo[2]) * edge + (b ? hi[1] : lo[1])) * edge + (a ? hi[0] : lo[0])] += (a + b + c) % 2 ? -1 : 1;
  }
  for (let z = 0; z < edge; z++) for (let y = 0; y < edge; y++) for (let x = 1; x < edge; x++) difference[(z * edge + y) * edge + x] += difference[(z * edge + y) * edge + x - 1];
  for (let z = 0; z < edge; z++) for (let y = 1; y < edge; y++) for (let x = 0; x < edge; x++) difference[(z * edge + y) * edge + x] += difference[(z * edge + y - 1) * edge + x];
  for (let z = 1; z < edge; z++) for (let y = 0; y < edge; y++) for (let x = 0; x < edge; x++) difference[(z * edge + y) * edge + x] += difference[((z - 1) * edge + y) * edge + x];
  for (let z = 0; z < coarse; z++) for (let y = 0; y < coarse; y++) for (let x = 0; x < coarse; x++) detail.data[((z * coarse + y) * coarse + x) * 4 + 3] = difference[(z * edge + y) * edge + x] > 0 ? 255 : 0;
}
function cellularNoise(seed) {
  const rng = random(seed), points = new Float32Array(32 ** 3 * 3);
  for (let i = 0; i < points.length; i++) points[i] = rng();
  return (x, y, z) => {
    const ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z);
    const fx = x - ix, fy = y - iy, fz = z - iz;
    let distance = 3;
    for (let dz = -1; dz <= 1; dz++) for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const idx = (((iz + dz & 31) * 32 + (iy + dy & 31)) * 32 + (ix + dx & 31)) * 3;
      const ax = dx + points[idx] - fx, ay = dy + points[idx + 1] - fy, az = dz + points[idx + 2] - fz;
      distance = Math.min(distance, ax * ax + ay * ay + az * az);
    }
    return 1 - clamp2(Math.sqrt(distance));
  };
}
function generateVolume(size = VOLUME_RESOLUTION, seed = 71, progress) {
  const n = size ** 3, field = new Float32Array(n), density = new Float32Array(n);
  field.fill(-10);
  const rng = random(seed);
  const cellular = cellularNoise(seed + 137);
  const shape = cloudParameters(seed);
  const liquid = [], iceCores = [], summits = [], foundations = [];
  const capParents = /* @__PURE__ */ new Map();
  const __roles = /* @__PURE__ */ new Map(), __authoredShoulders = /* @__PURE__ */ new Map();
  const anatomy = random(seed ^ 456640933);
  const turret = (x, z, height, width, lean, role = "tower") => {
    const siteX = x + (anatomy() - 0.5) * 0.28, siteZ = z + (anatomy() - 0.5) * 0.32;
    const lower = 2.25 + (anatomy() - 0.5) * 0.3, crest = height + (anatomy() - 0.5) * 0.42;
    const shoulder = lower + (crest - lower) * (0.43 + anatomy() * 0.16);
    const offset = (anatomy() - 0.5) * 0.34, depth = (anatomy() - 0.5) * 0.3;
    const girth = width * (0.91 + anatomy() * 0.18), tipWidth = girth * (0.67 + anatomy() * 0.2);
    const top = [siteX + lean + offset, crest, siteZ + depth, tipWidth, 0.65 + anatomy() * 0.24, tipWidth * (0.86 + anatomy() * 0.2)];
    const foundation = [siteX, lower, siteZ, girth * 1.2, 0.94 + anatomy() * 0.14, girth * 1.06];
    liquid.push(foundation);
    foundations.push(foundation);
    __roles.set(foundation, role + ".foundation");
    __roles.set(top, role + ".top");
    liquid.push([siteX + lean * 0.4 + offset * 0.6, shoulder, siteZ + depth * 0.6, girth * (0.91 + anatomy() * 0.12), (crest - lower) * 0.37, girth * 0.94]);
    __roles.set(liquid.at(-1), role + ".middle");
    liquid.push([siteX + lean * 0.72 + offset, (shoulder + crest) * 0.5, siteZ + depth, girth * 0.74, (crest - shoulder) * 0.5 + 0.48, girth * 0.77], top);
    __roles.set(liquid.at(-2), role + ".neck");
    summits.push(top);
    const shoulders = 2 + Math.floor(anatomy() * 2), phase = anatomy() * Math.PI * 2;
    for (let j = 0; j < shoulders; j++) {
      const angle = phase + j * (2.05 + anatomy() * 0.65), level = 0.3 + anatomy() * 0.38;
      const radius = girth * (0.62 + anatomy() * 0.24), bulge = girth * (0.45 + anatomy() * 0.2);
      liquid.push([
        siteX + lean * level + Math.cos(angle) * radius,
        lower + (crest - lower) * level,
        siteZ + depth * level + Math.sin(angle) * radius,
        bulge,
        bulge * (0.88 + anatomy() * 0.4),
        bulge * (0.82 + anatomy() * 0.3),
        0.16
      ]);
      __roles.set(liquid.at(-1), role + ".shoulder" + j);
      __authoredShoulders.set(liquid.at(-1), { role, j, angle, level, radius, bulge, siteX, siteZ, lower, crest, lean, depth, offset, girth });
    }
  };
  if (shape.family === "congestus") {
    liquid.push([-0.25, 1.6, 0, 3.05, 0.9, 1.9], [-1.5, 2.25, -0.25, 1.55, 0.9, 1.3], [1.35, 2.1, 0.25, 1.5, 0.8, 1.2]);
    turret(-1.55, -0.35, 4.95, 1.04, -0.15);
    turret(0.15, 0.4, 5.35, 0.99, 0.1);
    turret(1.55, -0.25, 4.55, 0.88, 0.17);
    const top = summits.reduce((a, b) => a[1] > b[1] ? a : b);
    const cap = [top[0] + top[3] * 0.3, top[1] + top[4] * 0.48, top[2], top[3] * 1.65, top[4] * 0.56, top[5] * 1.1, 0.06];
    iceCores.push(cap);
    capParents.set(top, cap);
  } else if (shape.family === "multicell") {
    liquid.push([-1.5, 1.5, -0.25, 2.1, 0.85, 1.55], [1.25, 1.55, 0.25, 2, 0.9, 1.6]);
    turret(-1.7, -0.35, 5.45, 0.98, -0.22);
    turret(1.25, 0.3, 4.5, 0.9, 0.25);
    const [older, younger] = summits;
    const pulseX = older[0] * 0.42 + younger[0] * 0.58, pulseZ = (older[2] + younger[2]) * 0.5 + Math.min(older[5], younger[5]) * 0.35;
    const pulseHeight = 0.72 + (Math.min(older[1], younger[1]) - 0.72) * (0.58 + anatomy() * 0.08);
    const pulseWidth = Math.min(older[3], younger[3]) * (0.72 + anatomy() * 0.16);
    liquid.push(
      [pulseX - 0.08, 1.95, pulseZ, pulseWidth * 1.22, (pulseHeight - 0.72) * 0.42, pulseWidth * 1.12, 0.18],
      [pulseX, (1.95 + pulseHeight) * 0.5, pulseZ, pulseWidth * 0.87, (pulseHeight - 1.95) * 0.5 + 0.32, pulseWidth * 0.9, 0.16],
      [pulseX + 0.08, pulseHeight, pulseZ + 0.05, pulseWidth * 0.9, pulseWidth * 0.98, pulseWidth * 0.94, 0.16]
    );
    for (const top of summits) {
      const cap = [top[0] + top[3] * 0.34, top[1] + top[4] * 0.48, top[2], top[3] * 1.65, top[4] * 0.5, top[5] * 1.14, 0.055];
      iceCores.push(cap);
      capParents.set(top, cap);
    }
  } else {
    liquid.push([-1.2, 1.55, 0, 2.65, 0.87, 1.8]);
    __roles.set(liquid.at(-1), "base");
    turret(-1.45, -0.3, 5.3, 1.05, 0.5, "main");
    turret(0.75, 0.5, 4.35, 0.82, 0.24, "young");
    liquid.push([-2.45, 2.7, 0.15, 0.82, 1, 0.83], [-2.15, 3.75, 0.1, 0.64, 0.72, 0.68]);
    __roles.set(liquid.at(-2), "upwind.lower");
    __roles.set(liquid.at(-1), "upwind.upper");
    const [a, b] = summits, rise = Math.min(a[1], b[1]) - 0.72;
    liquid.push([
      (a[0] + b[0]) * 0.5,
      0.72 + rise * 0.5,
      (a[2] + b[2]) * 0.5,
      Math.abs(a[0] - b[0]) * 0.5 + Math.min(a[3], b[3]) * 0.68,
      rise * 0.29 + 0.16,
      Math.max(a[5], b[5]) * 0.95 + Math.abs(a[2] - b[2]) * 0.35,
      0.18
    ]);
    __roles.set(liquid.at(-1), "shared.body");
    iceCores.push([-0.25, 5.85, -0.2, 1.45, 0.44, 1.3, 0.045], [1.45, 6.02, -0.2, 2.25, 0.36, 1.05, 0.035]);
    __roles.set(iceCores.at(-2), "incus.root");
    __roles.set(iceCores.at(-1), "incus.distal");
  }
  if (shape.family !== "sheared") for (let i = 0; i < summits.length; i++) {
    const top = summits[i], foot = foundations[i];
    const bottom = 0.72 + (top[1] - 0.72) * 0.18, roof = 0.72 + (top[1] - 0.72) * (shape.family === "congestus" ? 0.76 : 0.68);
    liquid.push([
      foot[0] + (top[0] - foot[0]) * 0.32,
      (bottom + roof) * 0.5,
      foot[2] + (top[2] - foot[2]) * 0.32,
      foot[3] * 0.94,
      (roof - bottom) * 0.5 + 0.1,
      foot[5] * 0.98,
      0.18
    ]);
  }
  const transform = (c, isIce) => {
    const width = isIce ? shape.anvilSpread : shape.towerWidth;
    c[0] = c[0] * shape.towerWidth + (c[1] - 0.72) * shape.windLean;
    c[1] = 0.72 + (c[1] - 0.72) * shape.towerHeight;
    c[2] *= shape.towerWidth;
    c[3] *= width * (isIce ? 1 : 1.16);
    c[4] *= shape.towerHeight * (isIce ? 1 : 1.1);
    c[5] *= shape.towerWidth * (isIce ? 1 : 1.16);
  };
  liquid.forEach((c) => transform(c, false));
  iceCores.forEach((c) => transform(c, true));
  const highest = Math.max(...summits.map((c) => c[1]));
  for (const top of summits) {
    if (shape.family === "congestus" && !capParents.has(top)) continue;
    if (shape.family !== "multicell" && top[1] < highest - 0.28 * shape.towerHeight) continue;
    const cap = capParents.get(top) ?? iceCores.reduce((a, b) => Math.hypot(a[0] - top[0], a[2] - top[2]) < Math.hypot(b[0] - top[0], b[2] - top[2]) ? a : b);
    const broadShoulder = shape.family === "sheared" && top[1] === highest;
    for (const t of broadShoulder ? [0.1, 0.42, 0.78] : [0.3, 0.72]) {
      const reach = broadShoulder ? Math.sqrt(t) : t * t;
      const rx = top[3] * (1 - reach) + Math.min(cap[3] * (broadShoulder ? 0.95 : 0.72), top[3] * (broadShoulder ? 2.05 : 1.65)) * reach;
      const rz = top[5] * (1 - reach) + cap[5] * (broadShoulder ? 0.9 : 0.72) * reach;
      liquid.push([
        top[0] + (cap[0] - top[0]) * t,
        top[1] + (cap[1] - top[1]) * t,
        top[2] + (cap[2] - top[2]) * t,
        rx,
        0.3 + (cap[1] - top[1]) * 0.48,
        rz,
        0.14
      ]);
      __roles.set(liquid.at(-1), (__roles.get(top) ?? "tower") + ".collar.t=" + t);
    }
  }
  const lobes = [...liquid, ...iceCores], __parents = /* @__PURE__ */ new Map();
  const __append = (lobe, parent) => {
    lobes.push(lobe);
    __parents.set(lobe, parent);
  };
  [...liquid, ...iceCores].forEach((c, i) => {
    const isIce = i >= liquid.length, count = isIce ? 10 : 18;
    for (let j = 0; j < count; j++) {
      const theta = rng() * Math.PI * 2, elevation = (rng() - 0.5) * 1.8;
      const scale = Math.min(c[3], c[4], c[5]);
      const shearedIce = isIce && shape.family === "sheared";
      const s = !isIce ? Math.max(0.16, Math.min(0.7, scale * (0.32 + rng() * 0.27))) : shearedIce ? 0.34 + rng() * 0.3 : Math.max(0.16, Math.min(0.48, Math.min(c[3], c[5]) * (0.26 + rng() * 0.24)));
      const radius = isIce ? 0.68 : 0.78, stretchX = isIce ? shearedIce ? 1.7 : 1.45 : 1, stretchY = isIce ? shearedIce ? 0.16 : 0.48 : 1;
      __append([
        c[0] + Math.cos(theta) * c[3] * radius * Math.cos(elevation),
        c[1] + Math.sin(elevation) * c[4] * radius,
        c[2] + Math.sin(theta) * c[5] * radius * Math.cos(elevation),
        s * stretchX,
        s * stretchY,
        s * 0.85,
        isIce ? 0.045 : 0.2
      ], c);
      if (!isIce) {
        const l = lobes.at(-1);
        for (let k = 0; k < 4; k++) {
          const a = rng() * Math.PI * 2, e = (rng() - 0.5) * 2, r = s * (0.24 + rng() * 0.22);
          __append([l[0] + Math.cos(a) * s * 0.76 * Math.cos(e), l[1] + Math.sin(e) * s * 0.76, l[2] + Math.sin(a) * s * 0.76 * Math.cos(e), r, r * 0.9, r], l);
        }
      }
    }
  });
  const capRng = random(seed ^ 2695083);
  for (const core of iceCores) for (let j = 0; j < 14; j++) {
    const reach = capRng() * 2 - 1, side = capRng() * 2 - 1;
    if (shape.family === "sheared") __append([
      core[0] + reach * core[3] * 0.82,
      core[1] + (capRng() - 0.5) * 0.18,
      core[2] + side * core[5] * 0.78,
      0.35 + capRng() * 0.7,
      0.14 + capRng() * 0.16,
      0.25 + capRng() * 0.42,
      0.035
    ], core);
    else lobes.push([
      core[0] + reach * core[3] * 0.76,
      core[1] + (capRng() - 0.5) * core[4] * 1.6,
      core[2] + side * core[5] * 0.78,
      core[3] * (0.2 + capRng() * 0.32),
      core[4] * (0.55 + capRng() * 0.6),
      core[5] * (0.2 + capRng() * 0.35),
      0.045
    ]);
  }
  const iceRng = random(seed ^ 1943411241);
  const streakCount = shape.family === "congestus" ? 16 : shape.family === "multicell" ? 36 : 48;
  for (let j = 0; j < streakCount; j++) {
    if (shape.family !== "sheared") {
      const core = iceCores[j % iceCores.length], reach2 = 0.55 + iceRng() * 0.65;
      lobes.push([
        core[0] + core[3] * reach2,
        core[1] + (iceRng() - 0.5) * core[4] * 1.8 + reach2 * core[4] * 0.15,
        core[2] + (iceRng() - 0.5) * core[5] * 1.4,
        core[3] * (0.24 + iceRng() * 0.36),
        0.035 + iceRng() * 0.05,
        0.07 + iceRng() * 0.14,
        0.035
      ]);
      continue;
    }
    const reach = iceRng(), rx = (0.55 + iceRng() * 0.75) * shape.anvilSpread;
    const origin = -0.1, length = 3.5;
    const cx = (origin + reach * length) * shape.anvilSpread + 5.3 * shape.windLean;
    lobes.push([
      cx,
      0.72 + (6 + (iceRng() - 0.5) * 0.6 - 0.72) * shape.towerHeight,
      -0.2 + (iceRng() - 0.5) * 1.7 * shape.towerWidth,
      rx,
      0.055 + iceRng() * 0.045,
      0.17 + iceRng() * 0.22,
      0.045
    ]);
  }
  for (const [axis, radius, limit] of [[0, 3, 4.35], [2, 5, 2.8]]) {
    const extent = Math.max(...lobes.map((c) => Math.abs(c[axis]) + c[radius]));
    const scale = Math.min(1, limit / extent);
    for (const c of lobes) {
      c[axis] *= scale;
      c[radius] *= scale;
    }
  }
  return { lobes, authoredShoulders: [...__authoredShoulders].map(([c, info]) => ({ index: lobes.indexOf(c), ...info })), roles: [...__roles].map(([c, role]) => [lobes.indexOf(c), role]), parents: [...__parents].map(([c, p]) => [lobes.indexOf(c), lobes.indexOf(p)]), summits: summits.map((c) => lobes.indexOf(c)), foundations: foundations.map((c) => lobes.indexOf(c)), iceCores: iceCores.map((c) => lobes.indexOf(c)) };
}
export {
  BOUNDS_MIN,
  BOUNDS_SIZE,
  DETAIL_RESOLUTION,
  DataUtils,
  EMPTY_SKIP_LIMIT,
  EXTINCTION,
  ICE_EXTINCTION,
  SUN_LEFT,
  SUN_RIGHT,
  VOLUME_RESOLUTION,
  bakeOccupancy,
  cellularNoise,
  clamp2 as clamp,
  cloudParameters,
  densitySupportBounds,
  erodeDensity,
  generateDetail,
  generateVolume,
  heightErosionScale,
  iceHeights,
  materialExtinction,
  morphologyFamily,
  motionState,
  noise,
  prepareInclinedShoulder,
  referencePosition,
  sampleCloudDensity,
  sampleDetail,
  smoothstep,
  voxelCenter,
  writeDisplacement
};
