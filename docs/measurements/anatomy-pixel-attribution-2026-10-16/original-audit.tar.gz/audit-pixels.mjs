import {readFile,writeFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {gzipSync,gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const qa=dirname(fileURLToPath(import.meta.url));
const repo='/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle15/secondary-hierarchy/baseline-source';
const require=createRequire(`${repo}/package.json`),{build}=require('esbuild');
const sha=b=>createHash('sha256').update(b).digest('hex');
const exact=(text,target,replacement)=>{assert.equal(text.split(target).length,2,`Expected one target: ${target.slice(0,100)}`);return text.replace(target,replacement);};
const original=await readFile(`${qa}/frozen-source/volume.ts`,'utf8');let code=original;
code=exact(code,'  const capParents=new Map<Lobe,Lobe>();','  const capParents=new Map<Lobe,Lobe>();const __roles=new Map<Lobe,string>(),__authoredShoulders=new Map<Lobe,any>();');
code=exact(code,'lean:number) => {',"lean:number,role='tower') => {");
code=exact(code,'    liquid.push(foundation);foundations.push(foundation);','    liquid.push(foundation);foundations.push(foundation);__roles.set(foundation,role+\'.foundation\');__roles.set(top,role+\'.top\');');
code=exact(code,'    // A buried neck keeps the main mass connected without smoothing the summit.',"    __roles.set(liquid.at(-1)!,role+'.middle');\n    // A buried neck keeps the main mass connected without smoothing the summit.");
code=exact(code,'    summits.push(top);',"    __roles.set(liquid.at(-2)!,role+'.neck');summits.push(top);");
code=exact(code,'bulge*(.82+anatomy()*.3),.16]);','bulge*(.82+anatomy()*.3),.16]);__roles.set(liquid.at(-1)!,role+\'.shoulder\'+j);__authoredShoulders.set(liquid.at(-1)!,{role,j,angle,level,radius,bulge,siteX,siteZ,lower,crest,lean,depth,offset,girth});');
code=exact(code,'    turret(-1.45,-.3,5.3,1.05,.5);',"    turret(-1.45,-.3,5.3,1.05,.5,'main');");
code=exact(code,'    turret(.75,.5,4.35,.82,.24);',"    turret(.75,.5,4.35,.82,.24,'young');");
code=exact(code,'    liquid.push([-1.2,1.55,0,2.65,.87,1.8]);',"    liquid.push([-1.2,1.55,0,2.65,.87,1.8]);__roles.set(liquid.at(-1)!,'base');");
code=exact(code,'    liquid.push([-2.45,2.7,.15,.82,1.0,.83],[-2.15,3.75,.1,.64,.72,.68]);',"    liquid.push([-2.45,2.7,.15,.82,1.0,.83],[-2.15,3.75,.1,.64,.72,.68]);__roles.set(liquid.at(-2)!,'upwind.lower');__roles.set(liquid.at(-1)!,'upwind.upper');");
code=exact(code,'Math.max(a[5],b[5])*.95+Math.abs(a[2]-b[2])*.35,.18]);',"Math.max(a[5],b[5])*.95+Math.abs(a[2]-b[2])*.35,.18]);__roles.set(liquid.at(-1)!,'shared.body');");
code=exact(code,'    iceCores.push([-.25,5.85,-.2,1.45,.44,1.3,.045],[1.45,6.02,-.2,2.25,.36,1.05,.035]);',"    iceCores.push([-.25,5.85,-.2,1.45,.44,1.3,.045],[1.45,6.02,-.2,2.25,.36,1.05,.035]);__roles.set(iceCores.at(-2)!,'incus.root');__roles.set(iceCores.at(-1)!,'incus.distal');");
code=exact(code,'rx,.3+(cap[1]-top[1])*.48,rz,.14]);',"rx,.3+(cap[1]-top[1])*.48,rz,.14]);__roles.set(liquid.at(-1)!,(__roles.get(top)??'tower')+'.collar.t='+t);");
code=exact(code,'  const lobes:Lobe[]=[...liquid,...iceCores];',`  const lobes:Lobe[]=[...liquid,...iceCores],__parents=new Map<Lobe,Lobe>();
  const __append=(lobe:Lobe,parent:Lobe)=>{lobes.push(lobe);__parents.set(lobe,parent);};`);
code=exact(code,'      lobes.push([c[0]+Math.cos(theta)*c[3]*radius*Math.cos(elevation), c[1]+Math.sin(elevation)*c[4]*radius,\n        c[2]+Math.sin(theta)*c[5]*radius*Math.cos(elevation), s*stretchX, s*stretchY, s*.85, isIce?.045:.2]);',
  '      __append([c[0]+Math.cos(theta)*c[3]*radius*Math.cos(elevation), c[1]+Math.sin(elevation)*c[4]*radius,\n        c[2]+Math.sin(theta)*c[5]*radius*Math.cos(elevation), s*stretchX, s*stretchY, s*.85, isIce?.045:.2],c);');
code=exact(code,'          lobes.push([l[0]+Math.cos(a)*s*.76*Math.cos(e),l[1]+Math.sin(e)*s*.76,l[2]+Math.sin(a)*s*.76*Math.cos(e),r,r*.9,r]);',
  '          __append([l[0]+Math.cos(a)*s*.76*Math.cos(e),l[1]+Math.sin(e)*s*.76,l[2]+Math.sin(a)*s*.76*Math.cos(e),r,r*.9,r],l);');
code=exact(code,"    if(shape.family==='sheared') lobes.push([core[0]+reach*core[3]*.82,core[1]+(capRng()-.5)*.18,\n      core[2]+side*core[5]*.78,.35+capRng()*.7,.14+capRng()*.16,.25+capRng()*.42,.035]);",
  "    if(shape.family==='sheared') __append([core[0]+reach*core[3]*.82,core[1]+(capRng()-.5)*.18,\n      core[2]+side*core[5]*.78,.35+capRng()*.7,.14+capRng()*.16,.25+capRng()*.42,.035],core);");
const cutoff='  // Rasterize lobes into their local bounds instead of testing every lobe at every voxel.';
assert.equal(code.split(cutoff).length,2);code=code.slice(0,code.indexOf(cutoff))+`return {lobes,authoredShoulders:[...__authoredShoulders].map(([c,info])=>({index:lobes.indexOf(c),...info})),roles:[...__roles].map(([c,role])=>[lobes.indexOf(c),role]),parents:[...__parents].map(([c,p])=>[lobes.indexOf(c),lobes.indexOf(p)]),summits:summits.map(c=>lobes.indexOf(c)),foundations:foundations.map(c=>lobes.indexOf(c)),iceCores:iceCores.map(c=>lobes.indexOf(c))};}\n`;
code+=`export {noise,cellularNoise,smoothstep,clamp};\nexport {prepareInclinedShoulder} from './inclinedShoulder';\nexport {motionState,referencePosition,writeDisplacement} from './motion';\nexport {DataUtils} from ${JSON.stringify(require.resolve('three/src/extras/DataUtils.js'))};\n`;
await writeFile(`${qa}/layout-trace.ts`,code);
await build({stdin:{contents:code,loader:'ts',resolveDir:`${repo}/src/cumulonimbus`,sourcefile:'volume.ts'},bundle:true,format:'esm',platform:'node',outfile:`${qa}/layout-trace.mjs`,logLevel:'silent'});
const mod=await import(`${qa}/layout-trace.mjs`),{clamp,smoothstep,noise,cellularNoise}=mod;
const layout=mod.generateVolume(8,74),reference=JSON.parse(gunzipSync(await readFile(`${qa}/reference-baseline74-layout.json.gz`)));
assert.deepEqual(layout.lobes,reference.geometry.post,'Instrumented layout differs from actual frozen10493');
const lobes=layout.lobes,roles=new Map(layout.roles),parents=new Map(layout.parents),groups=lobes.map((_,i)=>{let n=i;while(parents.has(n))n=parents.get(n);return n;});
const groupName=i=>roles.get(i)??`streak-or-other-${i}`;
const size=256,detailSize=128,seed=74,bmin=[-5,-.5,-3.5],extent=[10,8.5,7];
const center=(i,a,n=size)=>bmin[a]+(i+.5)/n*extent[a];
const bounds=lobes.map(l=>({start:l.slice(0,3).map((c,a)=>Math.max(1,Math.floor((c-l[a+3]-.35-bmin[a])/extent[a]*size-.5))),end:l.slice(0,3).map((c,a)=>Math.min(size-2,Math.ceil((c+l[a+3]+.35-bmin[a])/extent[a]*size-.5)))}));
const mature=layout.summits.reduce((a,b)=>lobes[a][1]>lobes[b][1]?a:b),m=lobes[mature],foot=lobes[layout.foundations[layout.summits.indexOf(mature)]],cap=layout.iceCores.map(i=>lobes[i]).reduce((a,b)=>Math.hypot(a[0]-m[0],a[2]-m[2])<Math.hypot(b[0]-m[0],b[2]-m[2])?a:b);
const shoulder=mod.prepareInclinedShoulder([0,1,2].map(a=>foot[a]+(m[a]-foot[a])*.68),[cap[0]+cap[3]*.28,cap[1]-cap[4]*.1,cap[2]],Math.max(m[3]*.95,foot[3]*.62),Math.max(m[5]*.95,cap[5]*.68));
const shoulderBounds={start:shoulder.min.map((v,a)=>Math.max(1,Math.floor((v-.35-bmin[a])/extent[a]*size-.5))),end:shoulder.max.map((v,a)=>Math.min(size-2,Math.ceil((v+.35-bmin[a])/extent[a]*size-.5)))};
const iceRange=mod.iceHeights(seed),cellular=cellularNoise(seed+137),detailCellular=cellularNoise(seed+513);
const rawCache=new Map(),detailCache=new Map(),flowCache=new Map();let sdfEvaluations=0;
const counts={rawHits:0,rawMisses:0,detailHits:0,detailMisses:0,flowMisses:0};
function rawVoxel(x,y,z,skip=null,trace=false) {
  x=Math.max(0,Math.min(size-1,x));y=Math.max(0,Math.min(size-1,y));z=Math.max(0,Math.min(size-1,z));
  const key=`${x},${y},${z}`,cacheKey=skip===null?key:`${skip}:${key}`;
  if(!trace&&rawCache.has(cacheKey)){counts.rawHits++;return rawCache.get(cacheKey);}
  counts.rawMisses++;if(x===0||y===0||z===0||x===size-1||y===size-1||z===size-1)return {value:0,field:-10};
  const p=[center(x,0),center(y,1),center(z,2)];let field=-10,weights=new Map(),prefix=[];
  const merge=(sd,blend,id)=>{const old=field,h=clamp(.5+.5*(old-sd)/blend);field=Math.fround(sd+(old-sd)*h+blend*h*(1-h));
    if(trace&&h<1){for(const [key,w]of weights){const nw=w*h;if(nw<1e-12)weights.delete(key);else weights.set(key,nw);}weights.set(id,(weights.get(id)??0)+1-h);prefix.push({id,sd,h,before:old,after:field});}};
  for(let i=0;i<lobes.length;i++) {
    if(skip!==null&&groups[i]===skip)continue;const b=bounds[i];if(x<b.start[0]||x>b.end[0]||y<b.start[1]||y>b.end[1]||z<b.start[2]||z>b.end[2])continue;
    const l=lobes[i],sd=(1-Math.sqrt(((p[0]-l[0])/l[3])**2+((p[1]-l[1])/l[4])**2+((p[2]-l[2])/l[5])**2))*Math.min(l[3],l[4],l[5]);sdfEvaluations++;merge(sd,l[6]??.2,i);
  }
  const b=shoulderBounds;
  if(skip!=='shoulder'&&x>=b.start[0]&&x<=b.end[0]&&y>=b.start[1]&&y<=b.end[1]&&z>=b.start[2]&&z<=b.end[2])merge(shoulder.sample(...p),.16,'shoulder');
  let value=0,carving=null;
  if(field>=-.3){const px=p[0]-bmin[0],py=p[1]-bmin[1],pz=p[2]-bmin[2];
    const n1=noise(px*1.25,py*1.25,pz*1.25,seed),n2=noise(px*3.6,py*3.6,pz*3.6,seed+12),n3=noise(px*9,py*9,pz*9,seed+42),c1=cellular(px*1.8,py*1.8,pz*1.8),c2=cellular(px*4.5,py*4.5,pz*4.5);
    const erosion=Math.min(0,(n1-.5)*.2-(1-c1)*.52-(1-c2)*.2+(n3-.5)*.1),ice=smoothstep(...iceRange,p[1]),fibers=noise(px*.3+py*.17,py*5,pz,seed+81),interior=1-.6*smoothstep(.04,.28,field);
    carving=erosion*mod.heightErosionScale(p[1])*interior*(1-ice)-(.012+(1-fibers)*.045+(1-n1)*.07+(1-n2)*.025)*ice;
    value=Math.round(Math.fround(clamp((field+carving-(.025-.017*ice))*(10+ice*4))*(.65+.35*n2)*(1-ice*(1-fibers)*.5)*clamp((p[1]-.72)/.24))*255)/255;
  }
  const result={value,field};if(trace)Object.assign(result,{index:[x,y,z],point:p,carving,weights:[...weights].map(([id,weight])=>({id,weight,group:id==='shoulder'?'shoulder':groups[id],role:id==='shoulder'?'inclinedShoulder10493':groupName(groups[id]),lobe:id==='shoulder'?null:lobes[id]})),prefix});
  if(!trace)rawCache.set(cacheKey,result);return result;
}
function detailVoxel(x,y,z){x=(x+detailSize)%detailSize;y=(y+detailSize)%detailSize;z=(z+detailSize)%detailSize;const key=`${x},${y},${z}`;
  if(detailCache.has(key)){counts.detailHits++;return detailCache.get(key);}counts.detailMisses++;
  const p=[(x+.5)/detailSize,(y+.5)/detailSize,(z+.5)/detailSize];
  const v=[Math.round((detailCellular(p[0]*32,p[1]*32,p[2]*32)*.65+noise(p[0]*8,p[1]*8,p[2]*8,seed,8)*.35)*255)/255,
    Math.round(noise(p[0]*16,p[1]*16,p[2]*16,seed+21,16)*255)/255,Math.round(noise(p[0]*32,p[1]*32,p[2]*32,seed+39,32)*255)/255];detailCache.set(key,v);return v;}
function linearDetail(p){const v=p.map(x=>(x-Math.floor(x))*detailSize-.5),i=v.map(Math.floor),f=v.map((x,a)=>x-i[a]),sum=[0,0,0];
  for(let z=0;z<2;z++)for(let y=0;y<2;y++)for(let x=0;x<2;x++){const q=detailVoxel(i[0]+x,i[1]+y,i[2]+z),w=(x?f[0]:1-f[0])*(y?f[1]:1-f[1])*(z?f[2]:1-f[2]);for(let c=0;c<3;c++)sum[c]+=q[c]*w;}return sum;}
function macro(p,skip=null,trace=false){const v=p.map((x,a)=>clamp((x-bmin[a])/extent[a])*size-.5),i=v.map(Math.floor),f=v.map((x,a)=>x-i[a]);let sum=0;const neighbors=[];
  for(let z=0;z<2;z++)for(let y=0;y<2;y++)for(let x=0;x<2;x++){const q=rawVoxel(i[0]+x,i[1]+y,i[2]+z,skip,trace),w=(x?f[0]:1-f[0])*(y?f[1]:1-f[1])*(z?f[2]:1-f[2]);sum+=q.value*w;if(trace)neighbors.push({...q,trilinearWeight:w});}return{value:sum,neighbors};}
const state=mod.motionState(60,seed);state.dispersion=0;
const wind=[.55*(.52+.23*Math.sin(60*.055+state.seedPhase*3)),.55*.26*Math.sin(60*.031+.6)],drift=[.55*(.32*Math.sin(60*.027)+.11*Math.sin(60*.071)),Math.sin(60*.04)*.015,0];
function flow(p){const v=p.map((x,a)=>(x-bmin[a])/extent[a]*16-.5),i=v.map(Math.floor),f=v.map((x,a)=>x-i[a]),out=[0,0,0,0];
  for(let z=0;z<2;z++)for(let y=0;y<2;y++)for(let x=0;x<2;x++){const k=[i[0]+x,i[1]+y,i[2]+z].map(a=>Math.max(0,Math.min(15,a))),key=k.join(',');let q=flowCache.get(key);
    if(!q){q=[0,0,0,0];mod.writeDisplacement(center(k[0],0,16),center(k[1],1,16),center(k[2],2,16),state,iceRange,q);q=q.map(c=>mod.DataUtils.fromHalfFloat(mod.DataUtils.toHalfFloat(c)));flowCache.set(key,q);counts.flowMisses++;}
    const w=(x?f[0]:1-f[0])*(y?f[1]:1-f[1])*(z?f[2]:1-f[2]);for(let c=0;c<4;c++)out[c]+=q[c]*w;}return out;}
function densityAt(world,skip=null,trace=false){const reference=mod.referencePosition(world.map((v,a)=>v-drift[a]),state,iceRange,wind),flowValue=flow(reference),local=reference.map((v,a)=>v-flowValue[a]),ice=smoothstep(...iceRange,local[1]),fine=linearDetail(local.map(v=>v*.3));
  const warpedPoint=local.map((v,a)=>v+([fine[1],fine[2],fine[0]][a]-.5)*([.16,.12,.16][a]+([.08,.02,.1][a]-[.16,.12,.16][a])*ice)),raw=macro(warpedPoint,skip,trace);
  let erosion=(1-fine[0])*.38+(1-fine[2])*.08+flowValue[3],material=1;
  if(ice>0){const bend=linearDetail([local[0]*.12,local[1]*.10,local[2]*.06])[1],iceDetail=linearDetail([local[0]*.055+bend*.08,local[1]*.34+local[0]*.022+(bend-.5)*.06,local[2]*.08+(bend-.5)*.025]),wisps=iceDetail[0];
    erosion=erosion*(1-ice)+(.08+(1-wisps)*.5+flowValue[3])*ice;const strand=smoothstep(.3,.7,wisps);material=1-ice+(.012+.56*strand**1.7)*(.65+.35*smoothstep(.25,.75,iceDetail[2]))*(1-.7*smoothstep(.4,3.8,local[0]))*ice;}
  erosion=Math.min(.92,erosion);let density=raw.value>=.002?clamp((raw.value-erosion)/(1-erosion))*material:0;if(density<.002)density=0;
  const result={density,sigma:mod.materialExtinction(ice)*density,world,reference,local,warpedPoint,ice,flow:flowValue,raw:raw.value,erosion,material};if(trace)result.neighbors=raw.neighbors;return result;}
const prior=JSON.parse(await readFile(`${qa}/prior-native-support.json`,'utf8')),box=prior.rendererSupportBounds,origin=[0,2.7,16],width=2560,height=1440,step=7/384;
const requests=[{name:'becco',uv:[.535,.304]},{name:'polso',uv:[.528,.257]},{name:'spalla-esterna',uv:[.441,.321]}],rays=[],attributions=[];
for(const req of requests){const pixel=[Math.floor(req.uv[0]*width),Math.floor(req.uv[1]*height)],uv=[(pixel[0]+.5)/width,(pixel[1]+.5)/height],screen=[uv[0]*2-1,1-uv[1]*2-.16],un=[screen[0]*(width/height)*.2867,screen[1]*.2867,-1],len=Math.hypot(...un),ray=un.map(v=>v/len);
  const intervals=ray.map((d,a)=>[(box.min[a]+drift[a]-origin[a])/d,(box.max[a]+drift[a]-origin[a])/d].sort((a,b)=>a-b)),near=Math.max(0,...intervals.map(v=>v[0])),far=Math.min(...intervals.map(v=>v[1]));
  const fract=x=>x-Math.floor(x),jitter=fract(52.9829189*fract(pixel[0]*.06711056+pixel[1]*.00583715));
  let t=near+step*jitter,tau=0;const samples=[],targets=[];
  while(t<far&&tau< -Math.log(.006)){const p=origin.map((v,a)=>v+ray[a]*t),d=densityAt(p),ds=Math.min(step,far-t),increment=d.sigma*ds,previous=tau;tau+=increment;
    samples.push({t,world:p,density:d.density,sigma:d.sigma,tau});
    for(const target of [1,3])if(previous<target&&tau>=target){const hitT=t+ds*(target-previous)/increment,interpolatedWorld=origin.map((v,a)=>v+ray[a]*hitT),world=p,stencil=densityAt(world,null,true),weights=new Map();
      for(const n of stencil.neighbors)for(const w of n.weights??[]){const signal=w.weight*n.value*n.trilinearWeight;weights.set(w.group,(weights.get(w.group)??0)+signal);}
      const total=[...weights.values()].reduce((a,b)=>a+b,0),ranking=[...weights].map(([group,weight])=>({group,role:group==='shoulder'?'inclinedShoulder10493':groupName(group),supportWeight:weight,normalizedWeight:total?weight/total:0,core:group==='shoulder'?null:lobes[group]})).sort((a,b)=>b.supportWeight-a.supportWeight);
      const item={name:req.name,targetTau:target,sampleT:t,hitT,interpolatedWorld,tauBefore:previous,tauAfter:tau,stencil,ranking};attributions.push(item);targets.push({targetTau:target,sampleT:t,hitT,interpolatedWorld,tauBefore:previous,tauAfter:tau,world,local:stencil.local,density:stencil.density,ranking:ranking.slice(0,5)});
    }t+=ds;
  }
  rays.push({name:req.name,requestedUV:req.uv,pixel,uv,screen,origin,ray,near,far,jitter,step,finalTau:tau,targets,samples});
  console.log(JSON.stringify({name:req.name,pixel,ray,near,far,finalTau:tau,targets}));
}
assert(attributions.length<=20);
const primary=attributions.find(v=>v.name==='becco'&&v.targetTau===1);assert(primary&&primary.ranking.length);
const suspect=primary.ranking[0].group,skipReport=[];
for(const item of attributions){const old=item.stencil,now=densityAt(old.world,suspect,false);skipReport.push({name:item.name,tau:item.targetTau,world:old.world,local:old.local,suspectGroup:suspect,suspectRole:suspect==='shoulder'?'inclinedShoulder10493':groupName(suspect),baselineDensity:old.density,withoutSuspectDensity:now.density,relativeDensityLoss:old.density?(old.density-now.density)/old.density:null,baselineRaw:old.raw,withoutSuspectRaw:now.raw});}
await writeFile(`${qa}/layout-and-stencils.json.gz`,gzipSync(JSON.stringify({sourceSha256:sha(original),layout,groups,attributions})));
const report={baseline:'10493',sourceSha256:sha(original),layoutMatchesFrozenBaseline:true,lobeCount:lobes.length,origin,inspection:0,aspect:width/height,tanFov:.2867,screenYOffset:-.16,time:60,seed,state,wind,drift,iceRange,
  supportBounds:box,supportProvenance:prior,steps:{ordinary:step,empty:.0546875,emptyIsIntegerMultiple:3},rays,counterfactual:{scope:'One suspected contributor group removed only in the same local macro/fine stencils; no global density or image edited.',suspectGroup:suspect,suspectRole:suspect==='shoulder'?'inclinedShoulder10493':groupName(suspect),groupPrimitiveCount:groups.filter(v=>v===suspect).length,results:skipReport},
  work:{attributionStencils:attributions.length,localCounterfactualStencils:skipReport.length,raySamples:rays.reduce((n,v)=>n+v.samples.length,0),...counts,sdfEvaluations,uniqueRawCacheEntries:rawCache.size,uniqueDetail128Texels:detailCache.size,uniqueFlow16Texels:flowCache.size,totalMacro256Texels:256**3},
  limitations:['Exactly three requested approximate image points, not the whole photograph; at most20 detailed attribution stencils.','CPU binary64 reference with Float32 macro field/R8 quantization and filtered half-float flow; WGSL arithmetic/jitter rounding can differ.','Integer empty steps preserve ordinary sample phase; mask lookup omitted in zero-density space. No full volume/occupancy bake.','Tau attribution measures attenuation; cached lighting/RGB photometry and full image raster were not reconstructed. The original light/material/extinction definitions were retained.','Prefix support weights are analytic SDF derivatives weighted by local macro R8 interpolation, not additive visible mass; a local group-removal counterfactual verifies their interpretation.']};
await writeFile(`${qa}/pixel-attribution.json`,JSON.stringify(report,null,2)+'\n');
const originalAll=JSON.parse(gunzipSync(await readFile('/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle15/secondary-hierarchy/geometry-traces.json.gz')));
const portability=[];
for(const seed of [72,73,74,77,80]) {
 const l=mod.generateVolume(8,seed),old=originalAll.traces.find(v=>v.label==='baseline'&&v.seed===seed);assert.deepEqual(l.lobes,old.geometry.post);
 const roles=new Map(l.roles),par=new Map(l.parents),group=i=>{while(par.has(i))i=par.get(i);return i;};
 const mains=l.authoredShoulders.filter(v=>v.role==='main');
 let innerDirection=null,mainFoot=null,mainTop=null;
 if(mains.length){mainFoot=l.lobes[[...roles].find(([i,role])=>role==='main.foundation')[0]];mainTop=l.lobes[[...roles].find(([i,role])=>role==='main.top')[0]];const youngFoot=l.lobes[[...roles].find(([i,role])=>role==='young.foundation')[0]],d=[youngFoot[0]-mainFoot[0],youngFoot[2]-mainFoot[2]],n=Math.hypot(...d);innerDirection=d.map(v=>v/n);}
 const shoulders=mains.map(v=>{const core=l.lobes[v.index],t=(core[1]-mainFoot[1])/(mainTop[1]-mainFoot[1]),axis=mainFoot.slice(0,3).map((x,i)=>x+(mainTop[i]-x)*t),lateral=[core[0]-axis[0],core[2]-axis[2]],projection=lateral[0]*innerDirection[0]+lateral[1]*innerDirection[1];return {...v,core,axisAtCoreHeight:axis,innerFacingProjection:projection,groupCount:l.lobes.map((_,i)=>group(i)).filter(i=>i===v.index).length};});
 portability.push({seed,layoutExact:true,mainShoulders:shoulders,innerDirection,strongestInnerFacingOrdinal:shoulders.length?shoulders.reduce((a,b)=>a.innerFacingProjection>b.innerFacingProjection?a:b).j:null});
}
await writeFile(`${qa}/semantic-portability.json`,JSON.stringify({scope:'Layout-only metadata, no raster/grid/volume; role and ordinal are not assumed to carry the same facing direction across seeds.',results:portability},null,2)+'\n');
console.log(JSON.stringify({counterfactual:report.counterfactual,work:report.work,portability}));
