import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {gzipSync} from 'node:zlib';
import assert from 'node:assert/strict';

const qa=dirname(fileURLToPath(import.meta.url));
const require=createRequire(`${qa}/candidate-source/package.json`),{build}=require('esbuild');
const sha=b=>createHash('sha256').update(b).digest('hex');
const exact=(text,target,replacement)=>{assert.equal(text.split(target).length,2,`Expected one target: ${target.slice(0,80)}`);return text.replace(target,replacement);};
const seeds=[72,73,74,77,80],sizes=[32,64],results=[],traces=[],reference=new Map();
const traceDir=`${qa}/diagnostics`;await mkdir(traceDir,{recursive:true});
const sources={};

for(const label of ['baseline','candidate']) {
  const root=`${qa}/${label==='baseline'?'baseline':'candidate'}-source`;
  const source=await readFile(`${root}/src/cumulonimbus/volume.ts`,'utf8');
  let code=source;
  code=exact(code,'function random(seed: number) {',`let __rngAudit:any[]=[];
function random(seed: number) {
  const audit={initialSeed:seed,words:[] as number[]};__rngAudit.push(audit);`);
  code=exact(code,'return ((t ^ t >>> 14) >>> 0) / 4294967296;',
    'const word=(t ^ t >>> 14) >>> 0;audit.words.push(word);return word / 4294967296;');
  code=exact(code,'const shape=cloudParameters(seed);',
    'const shape=cloudParameters(seed);const __contractions:any[]=[],__parents:any[]=[],__applications=new Map<Lobe,number>();');
  code=exact(code,'const scale=Math.min(1,limit/extent);',
    'const scale=Math.min(1,limit/extent);__contractions.push({axis,radius,limit,extent,scale});');
  const raster='  // Rasterize lobes into their local bounds instead of testing every lobe at every voxel.';
  const pre=`const __pre=lobes.map(c=>[...c]);`;
  if(label==='candidate') {
    code=exact(code,'    lobes.push(lobe);\n    if(secondaryCrown.has(parent)) secondaryCrown.add(lobe);',
      '    lobes.push(lobe);__parents.push([lobe,parent]);\n    if(secondaryCrown.has(parent)) secondaryCrown.add(lobe);');
    code=exact(code,"  if(shape.family==='sheared') {\n    const secondarySummit=",`${pre}
  const __taggedCores=[...secondaryCrown].filter(c=>liquid.includes(c));
  if(shape.family==='sheared') {
    const secondarySummit=`);
    code=exact(code,'for(const lobe of secondaryCrown) lobe[1]-=deltaY;',
      'for(const lobe of secondaryCrown) {__applications.set(lobe,(__applications.get(lobe)??0)+1);lobe[1]-=deltaY;}');
  } else code=exact(code,raster,`${pre}\n${raster}`);
  const trace=`const __geometry={pre:__pre,post:lobes.map(c=>[...c]),
    uniqueLobes:new Set(lobes).size,lobeCount:lobes.length,liquidCount:liquid.length,
    summits:summits.map(c=>lobes.indexOf(c)),foundations:foundations.map(c=>lobes.indexOf(c)),iceCores:iceCores.map(c=>lobes.indexOf(c)),
    contractions:__contractions,parents:__parents.map(([child,parent])=>[lobes.indexOf(child),lobes.indexOf(parent)]),
    tagged:${label==='candidate'?'[...secondaryCrown].map(c=>lobes.indexOf(c))':'[]'},
    taggedCores:${label==='candidate'?'__taggedCores.map(c=>lobes.indexOf(c))':'[]'},
    applications:[...__applications].map(([c,count])=>({index:lobes.indexOf(c),count}))};`;
  code=exact(code,raster,`${trace}\n${raster}`);
  code=exact(code,'const supportMargin=.13+Math.hypot(...BOUNDS_SIZE)/size;',
    'const supportMargin=.13+Math.hypot(...BOUNDS_SIZE)/size;const __support={skipped:0,missed:0,maxMissed:0};');
  code=exact(code,'if(field[i]<-supportMargin) {density[i]=0;continue;}',`if(field[i]<-supportMargin) {
    const py=voxelCenter(y,1,size),ice=smoothstep(iceStart,iceEnd,py);
    const exact=sampleCloudDensity(envelope,detail,voxelCenter(x,0,size),py,voxelCenter(z,2,size),ice);
    __support.skipped++;if(exact>0){__support.missed++;__support.maxMissed=Math.max(__support.maxMissed,exact);}
    density[i]=0;continue;
  }`);
  code=exact(code,'return {size, data, sunsetLight, detail, supportBounds:',
    'return {size, data, sunsetLight, detail,diagnostics:{geometry:__geometry,support:__support,rng:__rngAudit},supportBounds:');
  code+='\nexport function __resetAudit(){__rngAudit=[];}\n';
  const stem=`${traceDir}/${label}`;await writeFile(`${stem}.ts`,code);
  await build({stdin:{contents:code,loader:'ts',sourcefile:'volume.ts',resolveDir:`${root}/src/cumulonimbus`},
    bundle:true,platform:'node',format:'esm',outfile:`${stem}.mjs`,logLevel:'silent'});
  sources[label]={runtimeSourceSha256:sha(source),instrumentedSourceSha256:sha(code),bundleSha256:sha(await readFile(`${stem}.mjs`))};
  const mod=await import(`${stem}.mjs`);
  for(const size of sizes) for(const seed of seeds) {
    mod.__resetAudit();const start=performance.now();
    let v=mod.generateVolume(size,seed),r=new Uint8Array(size**3),detailRGB=new Uint8Array(v.detail.size**3*3);
    const geometry=v.diagnostics.geometry;
    const rng=v.diagnostics.rng.map(({initialSeed,words})=>({initialSeed,count:words.length,sha256:sha(new Uint32Array(words))}));
    let mass=0,occupied=0,minValue=255,maxValue=0;
    const faces=[Infinity,Infinity,Infinity,Infinity,Infinity,Infinity],occupiedMin=[Infinity,Infinity,Infinity],occupiedMax=[-Infinity,-Infinity,-Infinity];
    for(let z=0;z<size;z++)for(let y=0;y<size;y++)for(let x=0;x<size;x++) {
      const i=(z*size+y)*size+x,d=v.data[i*4];r[i]=d;mass+=d/255;minValue=Math.min(minValue,d);maxValue=Math.max(maxValue,d);
      if(!d)continue;occupied++;
      for(let axis=0;axis<3;axis++) {const p=mod.voxelCenter([x,y,z][axis],axis,size);
        occupiedMin[axis]=Math.min(occupiedMin[axis],p);occupiedMax[axis]=Math.max(occupiedMax[axis],p);
        faces[axis*2]=Math.min(faces[axis*2],p-mod.BOUNDS_MIN[axis]);
        faces[axis*2+1]=Math.min(faces[axis*2+1],mod.BOUNDS_MIN[axis]+mod.BOUNDS_SIZE[axis]-p);}
    }
    for(let i=0;i<v.detail.size**3;i++)for(let c=0;c<3;c++)detailRGB[i*3+c]=v.detail.data[i*4+c];
    const hashes={density:sha(r),rgba:sha(v.data),sunset:sha(v.sunsetLight),detailRGBA:sha(v.detail.data),detailRGB:sha(detailRGB)};
    const item={label,size,seed,elapsedMs:performance.now()-start,hashes,occupied,mass,range:[minValue,maxValue],faceClearance:faces,
      occupiedMin,occupiedMax,supportBounds:v.supportBounds,support:v.diagnostics.support,rng,
      geometrySummary:{lobeCount:geometry.lobeCount,uniqueLobes:geometry.uniqueLobes,taggedCount:geometry.tagged.length,taggedCores:geometry.taggedCores,contractions:geometry.contractions}};
    assert.equal(item.support.missed,0,`${label}/${size}/${seed} skipped nonzero density`);
    assert.equal(geometry.uniqueLobes,geometry.lobeCount,`${label}/${size}/${seed} aliased lobe`);
    const key=`${size}-${seed}`;
    if(label==='baseline') reference.set(key,{r,geometry,rng,hashes,faces,supportBounds:v.supportBounds});
    else {
      const old=reference.get(key);assert(old);const tagged=new Set(geometry.tagged);
      assert.deepEqual(geometry.pre,old.geometry.post,`${key} pre-translation geometry differs`);
      assert.deepEqual(rng,old.rng,`${key} RNG streams differ`);
      assert.deepEqual(geometry.contractions,old.geometry.contractions,`${key} contractions differ`);
      const sheared=mod.morphologyFamily(seed)==='sheared';assert.equal(tagged.size,sheared?182:0);
      assert.equal(geometry.applications.length,tagged.size);assert(geometry.applications.every(v=>v.count===1&&tagged.has(v.index)));
      let deltaY=0,taggedHead=null;
      if(sheared) {
        const matureIndex=geometry.summits.reduce((a,b)=>geometry.pre[a][1]>geometry.pre[b][1]?a:b);
        const headIndex=geometry.summits.find(i=>tagged.has(i));assert.notEqual(headIndex,undefined);
        deltaY=.5*(geometry.pre[matureIndex][1]-geometry.pre[headIndex][1]);
        taggedHead={index:headIndex,before:geometry.pre[headIndex],after:geometry.post[headIndex],matureIndex,mature:geometry.post[matureIndex]};
      }
      let moved=0,unchanged=0;const movedIndices=[];
      for(let i=0;i<geometry.post.length;i++) {
        const before=old.geometry.post[i],after=geometry.post[i];
        if(tagged.has(i)) {const expected=[...before];expected[1]-=deltaY;assert.deepEqual(after,expected,`${key} tag ${i}`);moved++;movedIndices.push(i);}
        else {assert.deepEqual(after,before,`${key} untagged ${i} changed`);unchanged++;}
      }
      assert.deepEqual(geometry.iceCores.map(i=>geometry.post[i]),old.geometry.iceCores.map(i=>old.geometry.post[i]));
      assert.deepEqual(geometry.foundations.map(i=>geometry.post[i]),old.geometry.foundations.map(i=>old.geometry.post[i]));
      let increased=0,decreased=0,equal=0,maxIncrease=0,maxDecrease=0;
      const changedMin=[Infinity,Infinity,Infinity],changedMax=[-Infinity,-Infinity,-Infinity];
      for(let i=0;i<r.length;i++) {
        const diff=r[i]-old.r[i];if(!diff){equal++;continue;}
        if(diff>0){increased++;maxIncrease=Math.max(maxIncrease,diff);}else{decreased++;maxDecrease=Math.max(maxDecrease,-diff);}
        const coords=[i%size,Math.floor(i/size)%size,Math.floor(i/(size*size))];
        for(let a=0;a<3;a++){const p=mod.voxelCenter(coords[a],a,size);changedMin[a]=Math.min(changedMin[a],p);changedMax[a]=Math.max(changedMax[a],p);}
      }
      item.comparison={preGeometryExact:true,rngExact:true,nonTaggedPrimitiveExact:true,contractionExact:true,
        unchangedPrimitiveCount:unchanged,movedPrimitiveCount:moved,deltaY,taggedHead,movedIndices,
        channelEqual:Object.fromEntries(Object.entries(hashes).map(([k,h])=>[k,old.hashes[k]===h])),
        density:{increased,decreased,equal,maxIncrease,maxDecrease,changedMin:increased+decreased?changedMin:null,changedMax:increased+decreased?changedMax:null},
        faceClearanceDelta:faces.map((f,i)=>f-old.faces[i]),supportBoundsExact:JSON.stringify(v.supportBounds)===JSON.stringify(old.supportBounds)};
      if(!sheared)assert(Object.values(item.comparison.channelEqual).every(Boolean),`${key} non-sheared output changed`);
      reference.delete(key);
    }
    if(size===32) traces.push({label,seed,geometry});
    results.push(item);await writeFile(`${qa}/comparison-32-64.partial.json`,JSON.stringify({sources,results},null,2)+'\n');
    console.log(JSON.stringify({label,size,seed,elapsedMs:Math.round(item.elapsedMs),tagged:geometry.tagged.length,occupied,mass,support:item.support,
      comparison:item.comparison?{moved:item.comparison.movedPrimitiveCount,deltaY:item.comparison.deltaY,density:item.comparison.density,channels:item.comparison.channelEqual}:null}));
    v=null;r=null;detailRGB=null;globalThis.gc?.();await new Promise(r=>setImmediate(r));
  }
}
await writeFile(`${qa}/geometry-traces.json.gz`,gzipSync(JSON.stringify({sources,traces})));
const report={description:'Frozen10493 shoulder baseline vs one semantic downward secondary-neck/head translation. CPU32³/64³ with matching detail32³/64³; no native256³/render/FPS/visual claim.',
  scope:{seeds,sizes,faceOrder:['x-','x+','y-','y+','z-','z+'],densityUnit:'R8/255',rngHashEncoding:'Uint32 native little-endian words, original order',
    caveat:'Invariant non-tagged primitive parameters do not mean invariant final density/light at every overlapping voxel.'},sources,results};
await writeFile(`${qa}/comparison-32-64.json`,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({pass:true,volumes:results.length,totalSkippedReevaluated:results.reduce((a,v)=>a+v.support.skipped,0),missed:results.reduce((a,v)=>a+v.support.missed,0)}));
