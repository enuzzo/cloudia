# Candidato esterno: gerarchia della seconda torre

Stato: preparato soltanto come testo. Il root deve dichiarare CPU libera prima di eseguire JavaScript, typecheck, test, build, raster o bake. Nessuna promozione al prodotto o accettazione artistica.

Base dichiarata dal root: checkpoint `10493`, sorgenti congelati in `cycle14/final-source`; lo snapshot conserva il manifest di provenienza con parent `08c33cb`. La spalla inclinata promossa resta invariata. `candidate-source/` è una copia completa dei sorgenti congelati con il medesimo symlink locale `node_modules`; nessuna dipendenza è installata o copiata. `baseline-snapshot/` conserva volume/helper/test originali; `baseline-input-manifest.json` identifica la chiusura completa di partenza.

## Unica modifica

La seconda chiamata sheared a `turret` riceve il ruolo semantico `secondary`. Collo e testa entrano in un `Set<Lobe>`; il ruolo viene ereditato da ogni billow e relativo child attraverso il riferimento al parent. Non si usano indici fissi dei lobes, né vengono aggiunti sorteggi RNG.

Dopo tutte le decorazioni e la contrazione orizzontale, il Set è visitato una sola volta:

`deltaY = .5 * (matureSummitY - secondarySummitY)`

`cy -= deltaY`

Raggi, X/Z e blend sono conservati. Fondazione, corpo intermedio, spalle laterali, corpo comune, colonna matura, incudine e spalla inclinata mantengono l'authoring precedente. Il Set dovrebbe contenere 182 primitive (due core, 18 billows ciascuno, quattro child per billow); il numero è una previsione da verificare, non un risultato eseguito.

Il cambiamento rende più bassa la corona giovane; non riempie il cielo superiore né risolve l'uncino/U globale. Il sottogruppo può diventare più opaco perché scende verso quote meno glaciali. La verifica futura deve distinguere questo effetto dalla gerarchia della sagoma.

## Cosa è stato controllato senza esecuzione

Copia e hash dei file di input; un solo file runtime differente (`src/cumulonimbus/volume.ts`); helper e test della spalla identici; symlink `node_modules` conservato. Patch leggibile: `secondary-hierarchy.patch`. Il manifest della copia candidata contiene gli SHA dei sorgenti e marca esplicitamente lo stato non eseguito.

Dopo il via libera CPU, i controlli richiesti sono: appartenenza semantica esatta e visita unica; delta uguale alla formula; invarianti di raggi/RNG e geometria esterna al gruppo; identità dei seed72/73; supporto del bake e luce calcolata dalla stessa densità modificata; confronto visivo degli stessi seed/pose. Non sono stati preparati altri fattori né varianti concorrenti.
