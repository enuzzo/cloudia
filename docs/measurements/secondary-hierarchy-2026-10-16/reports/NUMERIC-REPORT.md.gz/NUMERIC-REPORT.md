# Candidato esterno: gerarchia della seconda torre

Stato: verifiche numeriche mirate PASS; QA visiva ancora di root. Nessuna promozione artistica.

Il candidato applica una sola traslazione verticale al collo e alla testa della torre giovane sheared, con le loro decorazioni esistenti. La distanza tra i due summit aumenta di metà della differenza originaria. Questo cambia la gerarchia delle altezze; non pretende di riempire la U o risolvere l’uncino dell’incus.

## Sorgenti e integrità

- Baseline dichiarata da root: 10493, copiata da ciclo14/final-source in baseline-source (108 file; 612.911 byte).
- Candidato congelato in candidate-source (108 file; 613.814 byte).
- Unico sorgente diverso: src/cumulonimbus/volume.ts. SHA-256 candidato: `3db1246ae8741521be70d336a8ecdbee92bf33ea24f83246359faa909bad1b35`.
- SHA-256 baseline volume: `a53410c45b04143710cffd098b6a33deade3242c66ecf7eecc6405a214a93b00`.
- Tutti i file sono stati verificati prima e dopo test/build/probe. Nessun sorgente runtime corretto durante questa validazione.

## Geometria e casualità

Il trace verifica le primitive effettivamente costruite, prima e dopo la traslazione. Per ogni seed sheared sono taggati 182 riferimenti distinti: 2 core × (1 + 18 billow + 72 figli). Ogni riferimento viene traslato una sola volta. L’identità del padre dei figli è il billow catturato prima del loop; il Set non usa indici fissi. Gli indici nel JSON servono esclusivamente a rendere controllabile il trace.

La geometria pre-traslazione è esattamente identica alla baseline per ogni primitiva. Sequenza, conteggio e hash di ogni flusso RNG sono identici. Tutti i parametri delle primitive non taggate, i fattori di contrazione X/Z, fondazioni e incus sono identici. Il summit maturo resta il massimo: anche il suo riferimento al piede/cap e i parametri della spalla inclinata restano identici. La finale densità/luce può cambiare nei volumi sovrapposti e lungo l’illuminazione; non si afferma l’invarianza del campo in ogni voxel.

| Seed | Primitive totali | Traslate | Intatte | ΔY | Testa Y prima → dopo |
|---|---:|---:|---:|---:|---:|
| 72 | 2589 | 0 | 2589 | 0.000000000 | — |
| 73 | 2179 | 0 | 2179 | 0.000000000 | — |
| 74 | 1918 | 182 | 1736 | 0.403113044 | 3.803153 → 3.400040 |
| 77 | 1827 | 182 | 1645 | 0.401887605 | 3.460110 → 3.058222 |
| 80 | 1918 | 182 | 1736 | 0.452008461 | 3.664734 → 3.212726 |

## Densità e margini

20 volumi CPU: baseline e candidato, seed 72/73/74/77/80, risoluzioni 32³ e 64³ con dettaglio rispettivamente 32³ e 64³. Sono stati rivalutati con il campionatore fine tutti i 2.066.839 voxel scartati dal pre-filtro: nessuno conteneva densità positiva. Nessuna inferenza di prova nativa a 256³/128³.

72/73 sono identici byte per byte in densità, RGBA, luce bassa e dettaglio completo. Nei tre sheared il rumore RGB è identico; maschera alpha di occupazione, densità e luce cambiano come atteso. A 64³:

| Seed | R aumentati / diminuiti | Massa R/255 prima → dopo | Variazione | Margini alle 6 facce |
|---|---:|---:|---:|---|
| 74 | 189 / 189 | 8430.075 → 8383.035 | -0.558% | 2.109375, 1.328125, 1.261719, 2.589844, 1.804688, 1.695312 |
| 77 | 203 / 221 | 7799.114 → 7742.694 | -0.723% | 2.109375, 1.171875, 1.261719, 2.855469, 1.695312, 1.695312 |
| 80 | 188 / 244 | 6211.910 → 6127.851 | -1.353% | 2.421875, 1.484375, 1.261719, 2.722656, 1.804688, 1.914062 |

Ordine facce: X−, X+, Y−, Y+, Z−, Z+. Tutti i sei margini restano identici anche a 32³; i supportBounds restano identici. L’integrale R/255 è una somma di densità quantizzata sul campionamento, non una misura di massa meteorologica.

Una generazione aggiuntiva del candidato originale senza strumentazione, a 64³ seed74, produce gli stessi hash su tutti i canali e gli stessi supportBounds del probe strumentato (`uninstrumented-confirmation.json`).

## Test, build e riproduzione

- `npm run typecheck`: PASS.
- `npm test -- src/cumulonimbus/volume.test.ts src/cumulonimbus/inclinedShoulder.test.ts --maxWorkers=1`: 31/31 PASS.
- `node build-app.mjs`: build APP PASS; output `trial-dist`, nessuna build hero. Resta il normale avviso bundle >500 kB.
- Node v26.11.0. node_modules è il symlink locale esistente; attributo Dropbox ignore=1 verificato prima delle esecuzioni. Nessuna installazione.

Dalla directory di questo report, con le dipendenze originali disponibili tramite il symlink:

```sh
node --expose-gc probe-secondary-hierarchy.mjs
node --expose-gc confirm-uninstrumented.mjs
cd candidate-source
npm run typecheck
npm test -- src/cumulonimbus/volume.test.ts src/cumulonimbus/inclinedShoulder.test.ts --maxWorkers=1
cd ..
node build-app.mjs
```

La ricostruzione sovrascrive esclusivamente gli output esterni del probe. `comparison-32-64.json` contiene tutte le misure e gli hash; `geometry-traces.json.gz` contiene ogni primitiva prima/dopo; `tag-closure-verification.json` collega semanticamente i due core ai rispettivi figli; `dist-manifest.json` elenca file, dimensioni e SHA-256 dell’app pronta. La sorgente strumentata vive solo in diagnostics, separata da candidate-source e dalla build.

Il progetto prodotto, docs e Git non sono stati modificati da questo sottoaudit. La U/uncino resta il riferimento critico per il giudizio visivo, a camera fissa; nessun PASS artistico è dedotto dai numeri.
