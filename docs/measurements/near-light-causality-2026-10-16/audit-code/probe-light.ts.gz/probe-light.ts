/** Read-only CPU audit of a verified existing cloud cache. No generation/render. */
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {sampleCloudDensity,sampleDetail,materialExtinction,BOUNDS_MIN,BOUNDS_SIZE} from './source-snapshots/volume';
import {writeFilteredSourcePosition} from './motionField-runtime';
import {solarDirection} from './source-snapshots/sun';
import {atmosphereLighting,skyRadiance} from './source-snapshots/atmosphere';
const dir=import.meta.dir,base='/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle10/rain-work/data';
const sha=(v:Uint8Array|string)=>createHash('sha256').update(v).digest('hex');
const input=JSON.parse(readFileSync(base+'/manifest.json','utf8')),frozen=JSON.parse(readFileSync(dir+'/snapshot-manifest.json','utf8'));
for(const [path,proof] of Object.entries(frozen.files) as any){if(sha(readFileSync(dir+'/source-snapshots/'+path.split('/').at(-1)))!==proof.sha256)throw Error('Source mismatch '+path);}
for(const name of ['volume','motion','motionField','light'])if(frozen.files['src/cumulonimbus/'+name+'.ts'].sha256!==input.sourceHashesAfter[name])throw Error('Material cache source mismatch '+name);
const dataChecks:any={};
function binary(name:string){const data=readFileSync(base+'/'+name),proof=input.files[name];if(data.byteLength!==proof.bytes||sha(data)!==proof.sha256)throw Error('Input hash '+name);dataChecks[name]=proof;return data;}
const volume={size:256,data:binary('macro-rgba8.bin')},detail={size:128,data:binary('detail-rgba8.bin')},flowBytes=binary('flow-rgba16f.bin');
const field=new Uint16Array(flowBytes.buffer,flowBytes.byteOffset,flowBytes.byteLength/2),state=input.state,iceRange=input.iceRange;
const time=60,windStrength=.55,phase=(72%71)/71*.35;
const wind=[windStrength*(.52+.23*Math.sin(time*.055+phase*3)),windStrength*.26*Math.sin(time*.031+.6)];
const drift=[windStrength*(.32*Math.sin(time*.027)+.11*Math.sin(time*.071)),Math.sin(time*.04)*.015,0];
const target=[-.28995623264629566,2.4981598424383944,-.02734375],surface=1.4795113574194039;
const origin=[target[0],target[1],target[2]+surface],aspect=1280/720,tanFov=.2867;
const sun=solarDirection(0),lighting=atmosphereLighting(sun,1,0);
const clamp=(x:number,a=0,b=1)=>Math.max(a,Math.min(b,x));
const smooth=(a:number,b:number,x:number)=>{const t=clamp((x-a)/(b-a));return t*t*(3-2*t);};
const norm=(p:number[])=>{const l=Math.hypot(...p);return p.map(v=>v/l);};
const q=new Float64Array(4);let evaluations=0;
function material(p:number[],distance:number,micro=true){
 evaluations++;writeFilteredSourcePosition(p.map((v,i)=>v-drift[i]),state,iceRange,wind,field,q);
 const local=[q[0],q[1],q[2]],coord=local.map((v,i)=>(v-BOUNDS_MIN[i])/BOUNDS_SIZE[i]);
 if(coord.some(v=>v<0||v>1))return {rho:0,sigma:0,ice:0,local,coord,micro:0,light:[0,0,0]};
 const ice=smooth(iceRange[0],iceRange[1],q[1]),weight=(1-smooth(.08,.3,distance))*(1-ice);
 const microErosion=micro&&weight>.001?weight*(1-sampleDetail(detail,q[0]*8,q[1]*8,q[2]*8,2))*.055:0;
 let rho=sampleCloudDensity(volume,detail,q[0],q[1],q[2],ice,q[3]+microErosion);if(rho<.002)rho=0;
 const light=[1,2,3].map(c=>sampleDetail(volume,coord[0],coord[1],coord[2],c,false)*16);
 return {rho,sigma:rho*materialExtinction(ice),ice,local,coord,micro:microErosion,light};
}
const film=(v:number)=>clamp(v*(2.51*v+.03)/(v*(2.43*v+.59)+.14));
const srgb=(v:number)=>v<=.0031308?12.92*v:1.055*v**(1/2.4)-.055;
const luma=(c:number[])=>c[0]*.2126+c[1]*.7152+c[2]*.0722;
function source(m:ReturnType<typeof material>,ray:number[],distance:number){
 const mu=ray.reduce((s,v,i)=>s+v*sun[i],0),forward=(1-.68**2)/Math.max(1+.68**2-2*.68*mu,.04)**1.5;
 const back=(1-.25**2)/Math.max(1+.25**2+2*.25*mu,.04)**1.5,phase=.45+.55*(.82*forward+.18*back);
 const solar=Math.exp(-m.light[0]),sky=Math.exp(-m.light[2]);
 const direct=lighting.solar.map(v=>v*1.65*solar*phase);
 const ambient=lighting.ambient.map(v=>v*(.18+.82*sky**.35));
 const multiple=[1,.985,.95].map((v,i)=>v*(.27*Math.exp(-m.light[0]*.45)+.10*Math.exp(-m.light[0]*.18))+[.028,.032,.04][i]);
 const total=direct.map((v,i)=>v+ambient[i]+multiple[i]);
 return {direct,ambient,multiple,total,phase,solar,sky,aerial:Math.exp(-.0035*distance)};
}
function stats(values:number[]){const n=values.length,mean=values.reduce((a,b)=>a+b,0)/n;return {n,min:Math.min(...values),max:Math.max(...values),mean,standardDeviation:Math.sqrt(values.reduce((s,v)=>s+(v-mean)**2,0)/n),rangePercentOfMean:(Math.max(...values)-Math.min(...values))/mean*100};}
function integrate(uv:number[],micro=true,adaptive=false,step=.001){
 const ray=norm([(uv[0]*2-1)*aspect*tanFov,(1-uv[1]*2)*tanFov,-1]);
 const sky=skyRadiance(ray,sun,1),rgb=[0,0,0],components={direct:[0,0,0],ambient:[0,0,0],multiple:[0,0,0]};
 const first:any={rho002:null,rho025:null,tau1:null,tau3:null,tau5:null};
 let tau=0,T=1,weight=0,weightedDistance=0,samples=0,weightedRho=0,weightedSunTau=0,weightedSkyTau=0;
 const range={rho:[Infinity,-Infinity],sunTau:[Infinity,-Infinity],skyTau:[Infinity,-Infinity],source:[Infinity,-Infinity]};
 const checkpoints:any[]=[];
 let t=0;
 while(t<2&&T>=.006){
  const ds=Math.min(adaptive?Math.min(7/384,Math.max(.0015,t*.008)):step,2-t),at=adaptive?t:t+ds/2;
  const position=origin.map((v,i)=>v+ray[i]*at),m=material(position,at,micro);samples++;
  if(m.rho>0&&first.rho002===null)first.rho002=t;
  if(m.rho>.025&&first.rho025===null)first.rho025=t;
  const before=tau;const dTau=m.sigma*ds;tau+=dTau;
  for(const level of [1,3,5])if(tau>=level&&first['tau'+level]===null)first['tau'+level]=t+(level-before)/Math.max(1e-15,m.sigma);
  if(m.rho>0){
   const s=source(m,ray,at),w=T*(-Math.expm1(-dTau));weight+=w;weightedDistance+=w*at;
   weightedRho+=w*m.rho;weightedSunTau+=w*m.light[0];weightedSkyTau+=w*m.light[2];
   for(let c=0;c<3;c++){
    rgb[c]+=w*(sky[c]+(s.total[c]-sky[c])*s.aerial);
    for(const kind of ['direct','ambient','multiple'] as const)components[kind][c]+=w*s[kind][c];
   }
   if(w>1e-6){for(const [name,value] of [['rho',m.rho],['sunTau',m.light[0]],['skyTau',m.light[2]],['source',luma(s.total)]] as const){range[name][0]=Math.min(range[name][0],value);range[name][1]=Math.max(range[name][1],value);}}
  }
  T=Math.exp(-tau);t+=ds;
 }
 for(const level of [.1,.2,.3,.4,.5]){const p=origin.map((v,i)=>v+ray[i]*level),m=material(p,level,micro),s=source(m,ray,level);checkpoints.push({distanceKm:level,position:p,...m,source:s});}
 for(let c=0;c<3;c++)rgb[c]+=sky[c]*T;
 const mapped=rgb.map(film),display=mapped.map(srgb);
 return {uv,ray,micro,adaptive,stepKm:adaptive?null:step,first,samples,endKm:t,opacity:1-T,residual:T,rgb,film:mapped,srgb:display,display8:display.map(v=>v*255),luminance:luma(rgb),filmLuminance:luma(mapped),srgbLuminance:luma(display),
  components,weighted:{distanceKm:weightedDistance/weight,rho:weightedRho/weight,sunTau:weightedSunTau/weight,skyTau:weightedSkyTau/weight},range,checkpoints};
}
const started=performance.now();
const uvs=[];for(const v of [.05,.5,.95])for(const u of [.05,.5,.95])uvs.push([u,v]);for(const uv of [[.35,.5],[.65,.5],[.5,.35],[.5,.65]])uvs.push(uv);
const rays=uvs.map(uv=>integrate(uv));
const withoutMicro=uvs.map(uv=>integrate(uv,false));
const adaptive=uvs.map(uv=>integrate(uv,true,true));
const half=integrate([.5,.5],true,false,.0005),center=rays.find(r=>r.uv[0]===.5&&r.uv[1]===.5)!;
const footprintDepths=[.103,center.first.tau1,center.first.tau3,center.weighted.distanceKm].map(depth=>({axialDepthKm:depth,widthKm:2*depth*aspect*tanFov,heightKm:2*depth*tanFov}));
const summary={
 all13:{displayLuminance:stats(rays.map(r=>r.srgbLuminance)),linearLuminance:stats(rays.map(r=>r.luminance)),firstDensityKm:stats(rays.map(r=>r.first.rho002)),tau1Km:stats(rays.map(r=>r.first.tau1)),weightedSunTau:stats(rays.map(r=>r.weighted.sunTau)),weightedSkyTau:stats(rays.map(r=>r.weighted.skyTau)),weightedRho:stats(rays.map(r=>r.weighted.rho))},
 microDifference:stats(rays.map((r,i)=>r.srgbLuminance-withoutMicro[i].srgbLuminance)),
 adaptiveDifference:stats(rays.map((r,i)=>r.srgbLuminance-adaptive[i].srgbLuminance)),
 halfStepCenterLuminanceDifference:center.srgbLuminance-half.srgbLuminance,
 centerComponentLuminance:Object.fromEntries(Object.entries(center.components).map(([name,c])=>[name,luma(c)])),
};
function exactSolarAt(position:number[],step=.002){
 let tau=0;
 for(let distance=0;distance<8;distance+=step){
  const p=position.map((v,i)=>v+sun[i]*(distance+step*.5));
  // Current authored density/flow, without the view-dependent inspection term.
  tau+=material(p,10,false).sigma*step;
 }
 return tau;
}
const solarCheck=rays.map(r=>{
 const distance=r.first.tau1,position=origin.map((v,i)=>v+r.ray[i]*distance),m=material(position,distance,true),exact=exactSolarAt(position);
 const baked=source(m,r.ray,distance),reference=source({...m,light:[exact,m.light[1],m.light[2]]},r.ray,distance);
 return {uv:r.uv,position,viewDistanceKm:distance,density:m.rho,cacheSunTau:m.light[0],currentFieldSunTau:exact,cacheSolarTransmittance:Math.exp(-m.light[0]),currentFieldSolarTransmittance:Math.exp(-exact),cacheSourceLuminance:luma(baked.total),currentSunSourceLuminance:luma(reference.total)};
});
const shadowCenter=solarCheck.find(q=>q.uv[0]===.5&&q.uv[1]===.5)!;
const shadowHalf=exactSolarAt(shadowCenter.position,.001);
const report={git:frozen.git,method:'CPU Float64 density and co-deformed cached lighting on existing verified seed72 inputs;13 sparse rays,1m midpoint continuous integration until T<.006 or2km. Shadow/sky lookup matches normalized linear UNORM8 sampling. Solar/ambient from current atmosphereLighting; analytic skyRadiance per ray instead of uploaded128x128 LUT. Additional point solar check traces8km of the same current displaced/fine material at2m, without view-dependent microerosion, from each view tau1 location; center repeated1m. This is diagnosis, not a new shader/local-tail candidate. No terrain, rain, flashes, GPU, new bake or image. Adaptive comparison approximates shader left-point step schedule but not jitter/empty traversal/GPU arithmetic. Film and assumed standard sRGB output are reported separately; no screenshot-match claim.',dataChecks,state,iceRange,wind,drift,target,origin,surface,aspect,tanFov,verticalFovDegrees:2*Math.atan(tanFov)*180/Math.PI,horizontalFovDegrees:2*Math.atan(tanFov*aspect)*180/Math.PI,lighting,sun,macroVoxelKm:BOUNDS_SIZE.map(v=>v/256),fineRGBFeatureCellKm:1/(.3*32),microFeatureCellKm:1/(8*32),footprintDepths,summary,rays,withoutMicro,adaptive,halfStepCenter:half,solarCheck,solarCheckSummary:{cacheTau:stats(solarCheck.map(q=>q.cacheSunTau)),currentFieldTau:stats(solarCheck.map(q=>q.currentFieldSunTau)),cacheSourceLuminance:stats(solarCheck.map(q=>q.cacheSourceLuminance)),currentSunSourceLuminance:stats(solarCheck.map(q=>q.currentSunSourceLuminance)),centerHalfStepTauDifference:shadowCenter.currentFieldSunTau-shadowHalf},evaluations,durationMs:performance.now()-started};
writeFileSync(dir+'/near-light.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({durationMs:report.durationMs,evaluations,origin,verticalFovDegrees:report.verticalFovDegrees,horizontalFovDegrees:report.horizontalFovDegrees,footprintDepths,summary},null,2));
