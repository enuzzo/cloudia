from pathlib import Path
q=Path(__file__).resolve().parent
old=(q/'input/audit-pixels.mjs').read_text()
pre=r'''import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {gzipSync,gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const qa=dirname(fileURLToPath(import.meta.url));
const sha=b=>createHash('sha256').update(b).digest('hex');
const readJSON=async p=>JSON.parse(await readFile(`${qa}/${p}`,'utf8'));
const readGzip=async p=>JSON.parse(gunzipSync(await readFile(`${qa}/${p}`)));
const stored=await readGzip('input/layout-and-stencils.json.gz');
const traces=await readGzip('input/geometry-traces.json.gz');
const semantics=await readJSON('input/semantic-portability.json');
const previous=await readJSON('input/pixel-attribution.json');
const mod=await import('./input/layout-trace.mjs');
const {clamp,smoothstep,noise,cellularNoise}=mod;
const original=await readFile(`${qa}/input/frozen-source/volume.ts`,'utf8');
assert.equal(sha(original),'a53410c45b04143710cffd098b6a33deade3242c66ecf7eecc6405a214a93b00');
// No generator or RNG call. Reconstruct parent links from the original append
// schedule, then validate every link against the actual instrumented seed74.
function parentLinks(g) {
  let next=g.liquidCount+g.iceCores.length;const out=[];
  for(let core=0;core<g.liquidCount+g.iceCores.length;core++) {
    const liquid=core<g.liquidCount;
    for(let j=0;j<(liquid?18:10);j++) {const billow=next++;out.push([billow,core]);
      if(liquid)for(let k=0;k<4;k++)out.push([next++,billow]);}
  }
  for(const core of g.iceCores)for(let j=0;j<14;j++)out.push([next++,core]);
  return out;
}
const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const normalize=a=>{const n=Math.hypot(...a);assert(n>0);return a.map(v=>v/n);};
const rotate=(R,v)=>R.map(row=>dot(row,v));
function shortestRotation(a,b) {
  a=normalize(a);b=normalize(b);const v=cross(a,b),c=dot(a,b);assert(c>-1+1e-12,'No antiparallel case is part of this frozen model');
  const K=[[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]];
  const R=K.map((row,i)=>row.map((x,j)=>(i===j?1:0)+x+K[i].reduce((s,t,k)=>s+t*K[k][j],0)/(1+c)));
  const det=dot(R[0],cross(R[1],R[2]));
  const err=Math.max(...R.flatMap((row,i)=>R.map((other,j)=>Math.abs(dot(row,other)-(i===j?1:0)))));
  assert(Math.abs(det-1)<2e-14&&err<2e-14);assert(Math.hypot(...rotate(R,a).map((x,i)=>x-b[i]))<2e-14);
  return {matrix:R,determinant:det,orthonormalityMaxError:err,angleRadians:Math.acos(Math.max(-1,Math.min(1,c))),from:a,to:b};
}
const bmin=[-5,-.5,-3.5],extent=[10,8.5,7],size=256;
const indexBounds=(lo,hi)=>({start:lo.map((v,a)=>Math.max(1,Math.floor((v-bmin[a])/extent[a]*size-.5))),end:hi.map((v,a)=>Math.min(size-2,Math.ceil((v-bmin[a])/extent[a]*size-.5)))});
const boxCount=b=>b.end.reduce((p,v,i)=>p*Math.max(0,v-b.start[i]+1),1);
const margins=(lo,hi)=>[lo[0]-bmin[0],bmin[0]+extent[0]-hi[0],lo[1]-bmin[1],bmin[1]+extent[1]-hi[1],lo[2]-bmin[2],bmin[2]+extent[2]-hi[2]];
function originalBounds(l){return indexBounds(l.slice(0,3).map((v,a)=>v-l[a+3]-.35),l.slice(0,3).map((v,a)=>v+l[a+3]+.35));}
const frozenPath=`${qa}/frozen-model.json`;
if(process.argv[2]==='freeze') {
  const models=[];
  for(const seed of [72,73,74,77,80]) {
    const g=traces.traces.find(t=>t.label==='baseline'&&t.seed===seed).geometry;
    const s=semantics.results.find(t=>t.seed===seed),lobes=g.post,parents=parentLinks(g);
    if(seed===74){assert.deepEqual(lobes,stored.layout.lobes);assert.deepEqual(parents,stored.layout.parents);}
    const base={seed,lobeCount:lobes.length,baselineLayoutSHA256:sha(JSON.stringify(lobes)),rngCalls:0,sourceLayoutUnmutated:true,applies:false};
    if(!s.mainShoulders.length){models.push({...base,candidateLayoutSHA256:sha(JSON.stringify(lobes)),selectedCount:0,otherParametersExact:true});continue;}
    const mature=g.summits.reduce((a,b)=>lobes[a][1]>lobes[b][1]?a:b),foot=g.foundations[g.summits.indexOf(mature)],young=g.foundations.filter(i=>i!==foot);
    assert.equal(young.length,1);const m=lobes[mature],f=lobes[foot],yf=lobes[young[0]],inner=normalize([yf[0]-f[0],0,yf[2]-f[2]]);
    const candidates=s.mainShoulders.map(info=>{const core=lobes[info.index],t=(core[1]-f[1])/(m[1]-f[1]),pivot=f.slice(0,3).map((v,a)=>v+(m[a]-v)*t),offset=core.slice(0,3).map((v,a)=>v-pivot[a]);return {semanticRole:'mature.innerFacingShoulder',authoredOrdinal:info.j,index:info.index,pivot,offset,projection:dot(offset,inner)};});
    const selected=candidates.reduce((a,b)=>a.projection>b.projection?a:b);assert(selected.projection>0);
    const parent=new Map(parents),root=i=>{while(parent.has(i))i=parent.get(i);return i;},ids=lobes.map((_,i)=>i).filter(i=>root(i)===selected.index);
    assert.equal(ids.length,91);assert.equal(new Set(ids).size,91);
    const capIndex=g.iceCores.reduce((a,b)=>Math.hypot(lobes[a][0]-m[0],lobes[a][2]-m[2])<Math.hypot(lobes[b][0]-m[0],lobes[b][2]-m[2])?a:b),cap=lobes[capIndex];
    const shoulderStart=f.slice(0,3).map((v,a)=>v+(m[a]-v)*.68),shoulderEnd=[cap[0]+cap[3]*.28,cap[1]-cap[4]*.1,cap[2]],tangent=shoulderEnd.map((v,a)=>v-shoulderStart[a]);
    const rotation=shortestRotation(selected.offset,tangent),R=rotation.matrix,pivot=selected.pivot;
    const prepared=ids.map(index=>{const l=lobes[index],center=pivot.map((v,a)=>v+rotate(R,l.slice(0,3).map((x,b)=>x-pivot[b]))[a]),radius=R.map(row=>Math.hypot(...row.map((v,a)=>v*l[a+3]))),halo=radius.map(v=>v*(1+.35/Math.min(l[3],l[4],l[5])));
      const lo=center.map((v,a)=>v-radius[a]),hi=center.map((v,a)=>v+radius[a]),haloLo=center.map((v,a)=>v-halo[a]),haloHi=center.map((v,a)=>v+halo[a]);
      return {index,center,localRadii:l.slice(3,6),blend:l[6]??.2,positiveBounds:{min:lo,max:hi},fieldMinus035Bounds:{min:haloLo,max:haloHi},raster:indexBounds(haloLo,haloHi)};});
    const positiveLo=[0,1,2].map(a=>Math.min(...prepared.map(v=>v.positiveBounds.min[a]))),positiveHi=[0,1,2].map(a=>Math.max(...prepared.map(v=>v.positiveBounds.max[a]))),haloLo=[0,1,2].map(a=>Math.min(...prepared.map(v=>v.fieldMinus035Bounds.min[a]))),haloHi=[0,1,2].map(a=>Math.max(...prepared.map(v=>v.fieldMinus035Bounds.max[a])));
    const remaining=lobes.filter((_,i)=>!ids.includes(i));
    const positiveGlobalLo=[0,1,2].map(a=>Math.min(positiveLo[a],...remaining.map(l=>l[a]-l[a+3]))),positiveGlobalHi=[0,1,2].map(a=>Math.max(positiveHi[a],...remaining.map(l=>l[a]+l[a+3])));
    const oldCost=lobes.reduce((n,l)=>n+boxCount(originalBounds(l)),0),newCost=lobes.reduce((n,l,i)=>n+boxCount(prepared.find(v=>v.index===i)?.raster??originalBounds(l)),0);
    const groupOldCost=ids.reduce((n,i)=>n+boxCount(originalBounds(lobes[i])),0),groupNewCost=prepared.reduce((n,v)=>n+boxCount(v.raster),0);
    const coreBefore=lobes[selected.index].slice(0,3),coreAfter=prepared.find(v=>v.index===selected.index).center;
    models.push({...base,applies:true,matureSummitIndex:mature,matureFoundationIndex:foot,youngFoundationIndex:young[0],candidates,selection:selected,selectedCount:ids.length,selectedIds:ids,parentLinksSHA256:sha(JSON.stringify(parents)),rotation,pivot,shoulderAnchors:{start:shoulderStart,end:shoulderEnd},prepared,coreDisplacement:{before:coreBefore,after:coreAfter,delta:coreAfter.map((v,a)=>v-coreBefore[a])},
      preservation:{rngCalls:0,lobeCount:true,lobeOrder:true,localRadii:true,localEllipsoidVolume:true,blend:true,otherParametersExact:true,otherMetadataSHA256:sha(JSON.stringify(lobes.map((l,i)=>ids.includes(i)?null:l))),globalRecontraction:false,shoulderMutated:false},
      bounds:{axisOrder:['xmin','xmax','ymin','ymax','zmin','zmax'],selectedPositiveMargins:margins(positiveLo,positiveHi),selectedFieldMinus035Margins:margins(haloLo,haloHi),allPrimitivePositiveMargins:margins(positiveGlobalLo,positiveGlobalHi),onlyRotatedGroupBoundsChanged:true,negativeHaloFormula:'h_i=hypot(R_i0*rx,R_i1*ry,R_i2*rz)*(1+.35/minRadius)',smoothUnionCaveat:'Primitive analytic extents, not a generated density-support or occupancy certificate'},
      theoreticalRaster:{baselineAllLobes:oldCost,candidateAllLobes:newCost,delta:newCost-oldCost,ratio:newCost/oldCost,baselineGroup:groupOldCost,candidateGroup:groupNewCost,ratioGroup:groupNewCost/groupOldCost,scope:'Clamped256 local-box iteration arithmetic; not measured bake/GPU/FPS cost; shoulder unchanged and excluded from both totals'}});
  }
  const frozen={model:'body-bulge-orientation-preflight-r1',baseline:'10493afa7f6d90389c39e17b2cad79397dfdac01',inputSourceSHA256:sha(original),status:'Frozen before any density comparison',selection:'Highest actual summit and matching foundation; positive maximum of mature authored-shoulder offset toward other foundation; actual parent closure; no seed/core/ordinal used to select',transform:'One shortest rigid rotation about axis point at original coreY from radial offset toward promoted14.1 tangent; centers and ellipsoid axes rotate once after original contraction; no RNG or new parameter',gate:{beak:'Both original tau1/tau3 fixed stencil densities strictly decrease',saddle:'Fine density integral and optical-depth integral strictly increase on identical complete original support-box window; fine positive-support length recorded',failure:'If either missing, retire without tuning,32/64,app or image'},camera:{origin:[0,2.7,16],width:2560,height:1440,tanFov:.2867,screenYOffset:-.16,inspection:0,time:60,seed:74,windStrength:.55,dispersion:0},saddle:{pixel:[1408,490],uv:[1408.5/2560,490.5/1440]},models};
  await writeFile(frozenPath,JSON.stringify(frozen,null,2)+'\n');
  const script=await readFile(fileURLToPath(import.meta.url));
  const manifest={modelSHA256:sha(await readFile(frozenPath)),scriptSHA256:sha(script),inputsManifestSHA256:sha(await readFile(`${qa}/inputs-manifest.json`)),noDensityProbeYet:true};
  await writeFile(`${qa}/freeze-manifest.json`,JSON.stringify(manifest,null,2)+'\n');
  console.log(JSON.stringify({freeze:manifest,seeds:models.map(v=>({seed:v.seed,count:v.selectedCount,selection:v.selection,rotation:v.rotation,coreDisplacement:v.coreDisplacement,bounds:v.bounds,theoreticalRaster:v.theoreticalRaster}))},null,2));
  process.exit(0);
}
assert.equal(process.argv[2],'probe','Use freeze or probe');
const freezeManifest=await readJSON('freeze-manifest.json'),modelData=await readFile(frozenPath),frozen=JSON.parse(modelData);
assert.equal(sha(modelData),freezeManifest.modelSHA256);assert.equal(sha(await readFile(fileURLToPath(import.meta.url))),freezeManifest.scriptSHA256);
const layout=stored.layout,lobes=layout.lobes,roles=new Map(layout.roles),parents=new Map(layout.parents),groups=stored.groups;
const groupName=i=>roles.get(i)??`streak-or-other-${i}`;
const model=frozen.models.find(v=>v.seed===74),transformed=new Map(model.prepared.map(v=>[v.index,v])),R=model.rotation.matrix;
let candidate=false;
'''
start=old.index('const size=256,detailSize=128')
end=old.index('const prior=JSON.parse')
sampler=old[start:end]
sampler=sampler.replace('const size=256,detailSize=128,seed=74,bmin=[-5,-.5,-3.5],extent=[10,8.5,7];','const detailSize=128,seed=74;')
sampler=sampler.replace('const key=`${x},${y},${z}`,cacheKey=skip===null?key:`${skip}:${key}`;','const key=`${x},${y},${z}`,cacheKey=`${candidate?"candidate":"baseline"}:${skip===null?key:`${skip}:${key}`}`;')
sampler=sampler.replace('if(skip!==null&&groups[i]===skip)continue;const b=bounds[i];','if(skip!==null&&groups[i]===skip)continue;const transformedLobe=candidate?transformed.get(i):null,b=transformedLobe?.raster??bounds[i];')
needle='const l=lobes[i],sd=(1-Math.sqrt(((p[0]-l[0])/l[3])**2+((p[1]-l[1])/l[4])**2+((p[2]-l[2])/l[5])**2))*Math.min(l[3],l[4],l[5]);sdfEvaluations++;merge(sd,l[6]??.2,i);'
repl='''const l=lobes[i];let sd;
    if(transformedLobe){const d=p.map((v,a)=>v-transformedLobe.center[a]),q=[0,1,2].map(a=>R.reduce((s,row,b)=>s+row[a]*d[b],0));sd=(1-Math.sqrt((q[0]/l[3])**2+(q[1]/l[4])**2+(q[2]/l[5])**2))*Math.min(l[3],l[4],l[5]);}
    else sd=(1-Math.sqrt(((p[0]-l[0])/l[3])**2+((p[1]-l[1])/l[4])**2+((p[2]-l[2])/l[5])**2))*Math.min(l[3],l[4],l[5]);
    sdfEvaluations++;merge(sd,l[6]??.2,i);'''
assert sampler.count(needle)==1
sampler=sampler.replace(needle,repl)
# Keep the original ray/stencil reconstruction verbatim, but do not write old files.
rstart=old.index('const prior=JSON.parse')
rend=old.index('assert(attributions.length<=20);')
rays=old[rstart:rend]
rays=rays.replace('`${qa}/prior-native-support.json`','`${qa}/input/prior-native-support.json`')
rays=rays.replace('  console.log(JSON.stringify({name:req.name,pixel,ray,near,far,finalTau:tau,targets}));','')
post=r'''
assert.deepEqual(rays,previous.rays,'Old baseline rays do not reproduce exactly; stop before saddle/candidate');
assert.deepEqual(attributions,stored.attributions,'Old baseline stencil fields, bytes and contributor prefixes do not reproduce exactly');
const oldStencilBytes=Buffer.from(stored.attributions.flatMap(v=>v.stencil.neighbors.map(n=>Math.round(n.value*255))));
const newStencilBytes=Buffer.from(attributions.flatMap(v=>v.stencil.neighbors.map(n=>Math.round(n.value*255))));
assert.deepEqual(newStencilBytes,oldStencilBytes);
const reproduction={exactAllThreeRays:true,exactAllSixStencils:true,macroR8Bytes:newStencilBytes.length,macroR8SHA256:sha(newStencilBytes),fullStencilJSONSHA256:sha(JSON.stringify(attributions)),originalStencilJSONSHA256:sha(JSON.stringify(stored.attributions)),trigProvenance:'Frozen actual10493 layout, no primitive regeneration; existing Node/Bun sin/cos seed72 diagnosis does not imply seed74 identity; identity here independently checked on exact old ray/stencil objects'};
await writeFile(`${qa}/baseline-reproduction.json`,JSON.stringify(reproduction,null,2)+'\n');
console.log(JSON.stringify({baselineReproduced:reproduction}));
function rayForPixel(name,pixel){const uv=[(pixel[0]+.5)/width,(pixel[1]+.5)/height],screen=[uv[0]*2-1,1-uv[1]*2-.16],un=[screen[0]*(width/height)*.2867,screen[1]*.2867,-1],len=Math.hypot(...un),ray=un.map(v=>v/len),intervals=ray.map((d,a)=>[(box.min[a]+drift[a]-origin[a])/d,(box.max[a]+drift[a]-origin[a])/d].sort((a,b)=>a-b)),near=Math.max(0,...intervals.map(v=>v[0])),far=Math.min(...intervals.map(v=>v[1])),fract=x=>x-Math.floor(x),jitter=fract(52.9829189*fract(pixel[0]*.06711056+pixel[1]*.00583715));return {name,pixel,uv,screen,origin,ray,near,far,jitter,step};}
const completeRequests=[...rays.map(({name,pixel,uv,screen,origin,ray,near,far,jitter,step})=>({name,pixel,uv,screen,origin,ray,near,far,jitter,step})),rayForPixel('sella',frozen.saddle.pixel)];
function integrate(req,isCandidate){candidate=isCandidate;let t=req.near+step*req.jitter,tau=0,densityIntegral=0,positiveSupportLength=0,firstPositive=null,lastPositive=null,maxDensity=0;const targets=[],samples=[];
  while(t<req.far){const world=origin.map((v,a)=>v+req.ray[a]*t),d=densityAt(world),ds=Math.min(step,req.far-t),before=tau;densityIntegral+=d.density*ds;tau+=d.sigma*ds;
    if(d.density>=.002){positiveSupportLength+=ds;if(firstPositive===null)firstPositive=t;lastPositive=t;}
    maxDensity=Math.max(maxDensity,d.density);
    for(const target of [1,3])if(before<target&&tau>=target)targets.push({target,sampleT:t,hitT:t+ds*(target-before)/(d.sigma*ds),density:d.density});
    samples.push({t,density:d.density,sigma:d.sigma,tau,raw:d.raw,ice:d.ice});t+=ds;
  }
  return {tau,densityIntegral,positiveSupportLength,firstPositive,lastPositive,maxDensity,targets,samples};
}
const comparisons=[];
for(const req of completeRequests){const baseline=integrate(req,false),changed=integrate(req,true);comparisons.push({ray:req,baseline,candidate:changed,delta:{tau:changed.tau-baseline.tau,densityIntegral:changed.densityIntegral-baseline.densityIntegral,positiveSupportLength:changed.positiveSupportLength-baseline.positiveSupportLength,firstPositive:changed.firstPositive===null||baseline.firstPositive===null?null:changed.firstPositive-baseline.firstPositive}});}
const stencils=[];
for(const old of stored.attributions){candidate=true;const now=densityAt(old.stencil.world,null,true);stencils.push({name:old.name,targetTau:old.targetTau,world:old.stencil.world,baselineDensity:old.stencil.density,candidateDensity:now.density,deltaDensity:now.density-old.stencil.density,baselineRaw:old.stencil.raw,candidateRaw:now.raw,candidateStencil:now});}
const beak=stencils.filter(v=>v.name==='becco'),saddle=comparisons.find(v=>v.ray.name==='sella');
const gate={bothBeakStencilDensitiesDecrease:beak.every(v=>v.deltaDensity<0),saddleFineDensityIntegralIncreases:saddle.delta.densityIntegral>0,saddleTauIncreases:saddle.delta.tau>0,saddlePositiveSupportLengthDelta:saddle.delta.positiveSupportLength};
gate.pass=gate.bothBeakStencilDensitiesDecrease&&gate.saddleFineDensityIntegralIncreases&&gate.saddleTauIncreases;
const report={model:frozen.model,modelSHA256:freezeManifest.modelSHA256,sourceSHA256:sha(original),runtime:{node:process.version,platform:process.platform,arch:process.arch},reproduction,gate,decision:gate.pass?'Necessary local preflight conditions passed; no automatic32/64/app/visual followup authorized':'Retired: necessary preflight condition missing; no tuning32/64/app/image',frozenSelection:model.selection,reliefDisplacement:model.coreDisplacement,runtimeState:{state,wind,drift,iceRange,origin,box,ordinaryStep:step},comparisons,stencils,work:{originalRays:3,additionalFixedRays:1,detailedOldStencils:attributions.length,detailedCandidateStencils:stencils.length,completeWindowRaySamples:comparisons.reduce((n,v)=>n+v.baseline.samples.length+v.candidate.samples.length,0),...counts,sdfEvaluations,rawCacheEntries:rawCache.size,detail128Texels:detailCache.size,flow16Texels:flowCache.size,noFullVolume:true,noRNG:true,noGPU:true},limitations:['Only four fixed rays and twelve detailed stencils, not an image or whole-field density/support certificate.','Exact reproduction of the oldCPU reference is not bit-exactGPU equivalence: WGSL arithmetic/jitter can differ.','Complete-window optical depth deliberately has no T<.006 stop; baseline/candidate share the same sampling window and phase.','No RGB/light cache reconstructed; material/extinction/detail/flow parameters retained identically.','Analytic boxes and raster iteration arithmetic are not GPU cost or measured bake timing.','No claim that preserved ellipsoid volumes preserve union density or optical mass.']};
await writeFile(`${qa}/probe-results.json.gz`,gzipSync(JSON.stringify(report)));
await writeFile(`${qa}/result-summary.json`,JSON.stringify({...report,comparisons:comparisons.map(v=>({...v,baseline:{...v.baseline,samples:undefined},candidate:{...v.candidate,samples:undefined}})),stencils:stencils.map(({candidateStencil,...v})=>v)},null,2)+'\n');
console.log(JSON.stringify({gate,decision:report.decision,comparisons:comparisons.map(v=>({name:v.ray.name,baseTau:v.baseline.tau,newTau:v.candidate.tau,baseFine:v.baseline.densityIntegral,newFine:v.candidate.densityIntegral,baseSupport:v.baseline.positiveSupportLength,newSupport:v.candidate.positiveSupportLength,delta:v.delta})),stencils:stencils.map(({candidateStencil,...v})=>v),work:report.work},null,2));
'''
(q/'preflight.mjs').write_text(pre+sampler+rays+post)
print('prepared script',len((q/'preflight.mjs').read_bytes()))
