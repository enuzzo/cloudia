# Riorientamento del rigonfiamento interno: preflight respinto

**Esito: FAIL del gate necessario, modello ritirato.** Il rigonfiamento lascia i due stencil del becco ma non alimenta il raggio della sella fissato prima del calcolo. Non si procede a taratura, volumi 32³/64³, build, app o immagine. Nessun file del repository, documento prodotto o stato Git è stato modificato da questo audit.

## Modello unico congelato prima del campo

Baseline geometrica `10493afa7f6d90389c39e17b2cad79397dfdac01`, volume.ts SHA-256 `a53410c45b04143710cffd098b6a33deade3242c66ecf7eecc6405a214a93b00`. La spalla inclinata 14.1/10493 rimane esattamente quella della baseline.

Selezione: summit realmente più alto e relativa fondazione; fra le spalle autoriali del maturo, massimo offset positivo verso l'altra fondazione rispetto all'asse anatomico alla quota del core. Chiusura dei riferimenti parent effettivi: 1 core, 18 billows, 72 figli, 91 riferimenti distinti. Nessun seed, indice diagnostico o ordinale j sceglie il gruppo. Il parent schedule dell'originale è ricostruito senza RNG e coincide integralmente con il trace strumentato 74 già congelato. I metadata degli altri seed sono quelli già archiviati, senza rigenerarne le coordinate.

Una sola rotazione rigida minima porta l'offset radiale alla tangente della spalla 14.1, intorno al punto dell'asse alla quota iniziale del core. Centri e assi ellissoidali ruotano dopo decorazione e contrazione originali; raggi locali, blend, volume dei primitivi e ordine dell'unione rimangono. Nessun nuovo parametro o coefficiente. Gli altri primitivi e gli ancoraggi/campo della spalla non vengono mutati. Questo è diverso dai generatori PLUME ritirati e dalla rotazione del ghiaccio CAP ROOT; rimane un'ipotesi artistica ispirata alla morfologia osservata in WMO Plate5, non una legge dedotta dalla foto.

SHA modello congelato: `cc944b63af781d05316fbb323aea3d0919fad78e9d079fdab7712529915d0838`. SHA campionatore congelato: `787e2bd1f72c5369095fcddbb5c18b456e5e1b8da8b0b4b8347d0494296979ea`. `freeze-manifest.json` è stato scritto prima di qualsiasi confronto di densità. Nessuna modifica successiva al modello o al campionatore.

| Seed | Ruolo selezionato | Primitive | Angolo minimo, rad | Iterazioni box totali lobes |
|---|---|---:|---:|---:|
| 72 | identità, nessuna selezione | 0 | — | — |
| 73 | identità, nessuna selezione | 0 | — | — |
| 74 | maturo interno, j0 / core diagnostico 5 | 91 | 0.983264280 | +1.302165% |
| 77 | maturo interno, j1 / core diagnostico 6 | 91 | 0.784155418 | +0.587092% |
| 80 | maturo interno, j1 / core diagnostico 6 | 91 | 0.889187467 | +1.597420% |

Per 72/73 l'hash dell'array candidato coincide con quello baseline perché la selezione è vuota. Il modello conserva le stesse primitive e sequenze RNG; **non rigenera l'anatomia**. Nei JSON `rngCalls:0`/`noRNG:true` indicano questa assenza di RNG autoriale: il campionatore fine ricostituisce le tabelle cellulari seeded originali, come faceva il campionatore precedente.

## Riproduzione esatta obbligatoria, riuscita

Prima del nuovo raggio o del modello modificato sono stati riprodotti e confrontati con deepEqual tutti i campioni dei tre raggi originali, i sei stencil completi, field Float32, contributor prefix e i 48 byte R8 delle loro otto celle. Nessuna discrepanza.

- SHA-256 dei 48 byte R8: `ce0d40239eecafeeb382342742c8db247d81afd9b1e0ff823b0c156ea831091b`.
- SHA-256 JSON dei sei stencil, originale e riprodotto: `721c903e6d6a89b347fc3ce506220af09ada9aae3d918cda63e6b58c48212ebd`.
- Input primitivi: layout effettivo 10493 congelato. Nessun nuovo confronto o ricostruzione trigonometrica.

La provenienza sin/cos Node 26.11.0/Bun 1.3.11 era già stata chiarita sul seed72 nel pacchetto `cycle16/near-provenance-diff` e nel documento copiato `input/trig-provenance-note.md`. Quella prova non implica automaticamente l'identità seed74: qui l'identità dei vecchi raggi/stencil è verificata direttamente usando il suo layout effettivo.

## Quattro raggi, camera effettiva dell'attribuzione

Origine `[0,2.7,16]`, yaw/pitch0, ispezione0, 2560×1440, tanFov0.2867, offset schermoY−0.16. t60, wind0.55, dispersione0, flow completo e campo fine/materiale/estinzione identici. Non viene usata la camera della scena ordinaria.

| Raggio | Pixel nativo | UV al centro pixel |
|---|---|---|
| Becco | [1369,437] | [1369.5/2560,437.5/1440] |
| Polso | [1351,370] | [1351.5/2560,370.5/1440] |
| Esterno | [1128,462] | [1128.5/2560,462.5/1440] |
| Sella, fissata da root prima del calcolo | [1408,490] | [1408.5/2560,490.5/1440] = [0.5501953125,0.340625] |

Il support box originale renderer è min `[-4.86640625,-0.1680859374999999,-3.052421875]`, max `[5.56953125,6.4063671875,2.943046875]`, poi drift identico. Ordinary step7/384km, empty step3×ordinary; jitter/phase originali. Per il nuovo confronto l'intero intervallo comune near→far è integrato senza lo stop T<0.006, così τ baseline/candidato è comparabile. La riproduzione precedente mantiene invece lo stop originale esatto. Nessuna nuova occupancy o luce baked viene generata.

## Gate fissato prima dei risultati

Condizioni necessarie congiunte: **entrambi** i vecchi stencil τ1/τ3 del becco perdono densità; sul raggio sella crescono integrale di densità fine e τ. La lunghezza del supporto positivo è registrata separatamente. Polso, esterno e posizione del rilievo servono a interpretare, non a salvare un FAIL.

Becco, densità agli stessi punti:

- vecchio τ1: `0.7702510287952485` → **0**;
- vecchio τ3: `0.4747173506057149` → **0**.

La sella peggiora: τ **0.666904039 → 0.654876223**, variazione -1.803530%; integrale fine **0.037050224391 → 0.036382012376**. Il supporto con densità≥0.002 passa da 7 a6 passi, ossia **0.127604167 →0.109375km**. Non supera τ1 in nessuno dei due casi.

| Raggio, finestra completa | τ baseline | τ modello | Δτ | Supporto positivo, km |
|---|---:|---:|---:|---|
| becco | 11.374658898 | 2.657278054 | -8.717380844 | 1.130208333 → 0.309895833 |
| polso | 19.705129866 | 19.680914235 | -0.024215630 | 1.385416667 → 1.367187500 |
| spalla-esterna | 12.190671087 | 12.190671087 | 0.000000000 | 1.075520833 → 1.075520833 |
| sella | 0.666904039 | 0.654876223 | -0.012027816 | 0.127604167 → 0.109375000 |

Ai due vecchi stencil del polso la densità è esattamente invariata, benché sul raggio completo si perda un passo all'ingresso e τ cali leggermente. Esterno: tutti i campioni, integrali e supporto esattamente invariati.

Il core74 si sposta da `[0.1627321101,3.5844864041,0.1434988400]` a `[0.1587717904,4.0563836870,-0.2848637434]`: sale0.471897km e arretra lungoZ0.428363km. Questo dato mostra dove la massa primitiva viene spostata, senza dimostrare un nuovo rilievo visibile. Conservare volume ellissoidale non conserva densità unita né opacità dopo carving, sovrapposizioni e fase ice. Non sono stati cercati altri pixel per reinterpretare o salvare il fallimento.

## Bounds corretti e costo soltanto teorico

Il field ruotato usa q=Rᵀ(p−centro) e la stessa distanza normalizzata×minRadius. Rotazione ortonormale, det+1: errori massimi nell'ortogonalità≤2.23×10⁻¹⁶ per tutti e tre i layout. Conserva quindi il limite1-Lipschitz del singolo field. Nessuna ricontrazione globale.

Per ogni primitiva ruotata il semiasse AABB positivo lungo i è `hypot(R_i0*rx,R_i1*ry,R_i2*rz)`; per includere sd≥−0.35 si moltiplica per `1+0.35/minRadius`. Questi sono i bounds usati dal pre-filtro candidato. Sono diversi dalla semplice traslazione dei centri o dall'uso dei vecchi assi AABB.

I margini analitici alle sei facce sono in `frozen-model.json`, ordine xmin/xmax/ymin/ymax/zmin/zmax. Per il gruppo74, margini positivi `[4.383690,4.197489,3.800537,3.139435,2.401071,3.044424]`km; includendo sd≥−0.35 `[3.981261,3.795059,3.375131,2.714030,1.984169,2.615387]`km. Tutti positivi, nessun box del gruppo viene troncato. I margini del resto dei lobes rimangono quelli della baseline. Questi sono bound dei primitivi, **non** una misura dell'intero supporto di densità/luce o una prova nuova della skip mask.

Conteggio aritmetico dei voxel visitabili dai box256, con stessa conversione floor/ceil/clamp del raster, esclusa la spalla identica da entrambi i totali:

- 74:83,735,916→84,826,296, **+1.302165%** totali; gruppo +36.829585%;
- 77:77,443,348→77,898,012, **+0.587092%** totali; gruppo +18.904358%;
- 80:78,114,440→79,362,256, **+1.597420%** totali; gruppo +46.390402%.

Non sono tempi bake o GPU/FPS e non vengono usati per promuovere il modello.

## Perimetro e riproduzione

Un'unica esecuzione del probe. Tre raggi riprodotti prima, quattro finestre complete×due modelli, 2,640 campioni nella comparazione, dodici stencil dettagliati complessivi. In cache:8,768 chiavi macro richieste baseline/candidato, 4,059 texel dettaglio128 e200 flow16. Nessun array macro256³, volume32/64, bake, test, build, renderer, browser o GPU. Luce/RGB non ricostruiti; il limite CPUdouble/WGSL e gli arrotondamenti jitter restano espliciti.

`probe-results.json.gz` conserva i campioni e gli stencil completi; `result-summary.json` i confronti leggibili; `baseline-reproduction.json` l'uguaglianza esatta; `frozen-model.json` matrici, centri, selettore, indici solo diagnostici, bounds e costi; `input/` gli input copiati byte per byte. `inputs-manifest.json` ne registra origine, dimensioni e hash. Le foto originali non sono annotate o alterate; questo preflight non produce immagini.

Replay offline, soltanto se autorizzato come nuova esecuzione: Node26.11.0 arm64, `node preflight.mjs probe` in questa directory. Non necessita installazioni o dipendenze esterne: il modulo originale del campionatore è già congelato. Verifica prima SHA del modello/script; il comando riscrive esclusivamente gli output locali esterni. Il comando `node preflight.mjs freeze` ricava soltanto layout/metadati algebrici dagli input e deve riprodurre il modello deterministico; non eseguirlo per cercare nuove varianti.

**Decisione finale: ipotesi falsificata dal raggio della sella richiesto. Nessun seguito automatico.**
