import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {gzipSync,gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const qa=dirname(fileURLToPath(import.meta.url));
const sha=b=>createHash('sha256').update(b).digest('hex');
const readJSON=async p=>JSON.parse(await readFile(`${qa}/${p}`,'utf8'));
const readGzip=async p=>JSON.parse(gunzipSync(await readFile(`${qa}/${p}`)));
const stored=await readGzip('input/layout-and-stencils.json.gz');
const traces=await readGzip('input/geometry-traces.json.gz');
const semantics=await readJSON('input/semantic-portability.json');
const previous=await readJSON('input/pixel-attribution.json');
const mod=await import('./input/layout-trace.mjs');
const {clamp,smoothstep,noise,cellularNoise}=mod;
const original=await readFile(`${qa}/input/frozen-source/volume.ts`,'utf8');
assert.equal(sha(original),'a53410c45b04143710cffd098b6a33deade3242c66ecf7eecc6405a214a93b00');
// No generator or RNG call. Reconstruct parent links from the original append
// schedule, then validate every link against the actual instrumented seed74.
function parentLinks(g) {
  let next=g.liquidCount+g.iceCores.length;const out=[];
  for(let core=0;core<g.liquidCount+g.iceCores.length;core++) {
    const liquid=core<g.liquidCount;
    for(let j=0;j<(liquid?18:10);j++) {const billow=next++;out.push([billow,core]);
      if(liquid)for(let k=0;k<4;k++)out.push([next++,billow]);}
  }
  for(const core of g.iceCores)for(let j=0;j<14;j++)out.push([next++,core]);
  return out;
}
const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const normalize=a=>{const n=Math.hypot(...a);assert(n>0);return a.map(v=>v/n);};
const rotate=(R,v)=>R.map(row=>dot(row,v));
function shortestRotation(a,b) {
  a=normalize(a);b=normalize(b);const v=cross(a,b),c=dot(a,b);assert(c>-1+1e-12,'No antiparallel case is part of this frozen model');
  const K=[[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]];
  const R=K.map((row,i)=>row.map((x,j)=>(i===j?1:0)+x+K[i].reduce((s,t,k)=>s+t*K[k][j],0)/(1+c)));
  const det=dot(R[0],cross(R[1],R[2]));
  const err=Math.max(...R.flatMap((row,i)=>R.map((other,j)=>Math.abs(dot(row,other)-(i===j?1:0)))));
  assert(Math.abs(det-1)<2e-14&&err<2e-14);assert(Math.hypot(...rotate(R,a).map((x,i)=>x-b[i]))<2e-14);
  return {matrix:R,determinant:det,orthonormalityMaxError:err,angleRadians:Math.acos(Math.max(-1,Math.min(1,c))),from:a,to:b};
}
const bmin=[-5,-.5,-3.5],extent=[10,8.5,7],size=256;
const indexBounds=(lo,hi)=>({start:lo.map((v,a)=>Math.max(1,Math.floor((v-bmin[a])/extent[a]*size-.5))),end:hi.map((v,a)=>Math.min(size-2,Math.ceil((v-bmin[a])/extent[a]*size-.5)))});
const boxCount=b=>b.end.reduce((p,v,i)=>p*Math.max(0,v-b.start[i]+1),1);
const margins=(lo,hi)=>[lo[0]-bmin[0],bmin[0]+extent[0]-hi[0],lo[1]-bmin[1],bmin[1]+extent[1]-hi[1],lo[2]-bmin[2],bmin[2]+extent[2]-hi[2]];
function originalBounds(l){return indexBounds(l.slice(0,3).map((v,a)=>v-l[a+3]-.35),l.slice(0,3).map((v,a)=>v+l[a+3]+.35));}
const frozenPath=`${qa}/frozen-model.json`;
if(process.argv[2]==='freeze') {
  const models=[];
  for(const seed of [72,73,74,77,80]) {
    const g=traces.traces.find(t=>t.label==='baseline'&&t.seed===seed).geometry;
    const s=semantics.results.find(t=>t.seed===seed),lobes=g.post,parents=parentLinks(g);
    if(seed===74){assert.deepEqual(lobes,stored.layout.lobes);assert.deepEqual(parents,stored.layout.parents);}
    const base={seed,lobeCount:lobes.length,baselineLayoutSHA256:sha(JSON.stringify(lobes)),rngCalls:0,sourceLayoutUnmutated:true,applies:false};
    if(!s.mainShoulders.length){models.push({...base,candidateLayoutSHA256:sha(JSON.stringify(lobes)),selectedCount:0,otherParametersExact:true});continue;}
    const mature=g.summits.reduce((a,b)=>lobes[a][1]>lobes[b][1]?a:b),foot=g.foundations[g.summits.indexOf(mature)],young=g.foundations.filter(i=>i!==foot);
    assert.equal(young.length,1);const m=lobes[mature],f=lobes[foot],yf=lobes[young[0]],inner=normalize([yf[0]-f[0],0,yf[2]-f[2]]);
    const candidates=s.mainShoulders.map(info=>{const core=lobes[info.index],t=(core[1]-f[1])/(m[1]-f[1]),pivot=f.slice(0,3).map((v,a)=>v+(m[a]-v)*t),offset=core.slice(0,3).map((v,a)=>v-pivot[a]);return {semanticRole:'mature.innerFacingShoulder',authoredOrdinal:info.j,index:info.index,pivot,offset,projection:dot(offset,inner)};});
    const selected=candidates.reduce((a,b)=>a.projection>b.projection?a:b);assert(selected.projection>0);
    const parent=new Map(parents),root=i=>{while(parent.has(i))i=parent.get(i);return i;},ids=lobes.map((_,i)=>i).filter(i=>root(i)===selected.index);
    assert.equal(ids.length,91);assert.equal(new Set(ids).size,91);
    const capIndex=g.iceCores.reduce((a,b)=>Math.hypot(lobes[a][0]-m[0],lobes[a][2]-m[2])<Math.hypot(lobes[b][0]-m[0],lobes[b][2]-m[2])?a:b),cap=lobes[capIndex];
    const shoulderStart=f.slice(0,3).map((v,a)=>v+(m[a]-v)*.68),shoulderEnd=[cap[0]+cap[3]*.28,cap[1]-cap[4]*.1,cap[2]],tangent=shoulderEnd.map((v,a)=>v-shoulderStart[a]);
    const rotation=shortestRotation(selected.offset,tangent),R=rotation.matrix,pivot=selected.pivot;
    const prepared=ids.map(index=>{const l=lobes[index],center=pivot.map((v,a)=>v+rotate(R,l.slice(0,3).map((x,b)=>x-pivot[b]))[a]),radius=R.map(row=>Math.hypot(...row.map((v,a)=>v*l[a+3]))),halo=radius.map(v=>v*(1+.35/Math.min(l[3],l[4],l[5])));
      const lo=center.map((v,a)=>v-radius[a]),hi=center.map((v,a)=>v+radius[a]),haloLo=center.map((v,a)=>v-halo[a]),haloHi=center.map((v,a)=>v+halo[a]);
      return {index,center,localRadii:l.slice(3,6),blend:l[6]??.2,positiveBounds:{min:lo,max:hi},fieldMinus035Bounds:{min:haloLo,max:haloHi},raster:indexBounds(haloLo,haloHi)};});
    const positiveLo=[0,1,2].map(a=>Math.min(...prepared.map(v=>v.positiveBounds.min[a]))),positiveHi=[0,1,2].map(a=>Math.max(...prepared.map(v=>v.positiveBounds.max[a]))),haloLo=[0,1,2].map(a=>Math.min(...prepared.map(v=>v.fieldMinus035Bounds.min[a]))),haloHi=[0,1,2].map(a=>Math.max(...prepared.map(v=>v.fieldMinus035Bounds.max[a])));
    const remaining=lobes.filter((_,i)=>!ids.includes(i));
    const positiveGlobalLo=[0,1,2].map(a=>Math.min(positiveLo[a],...remaining.map(l=>l[a]-l[a+3]))),positiveGlobalHi=[0,1,2].map(a=>Math.max(positiveHi[a],...remaining.map(l=>l[a]+l[a+3])));
    const oldCost=lobes.reduce((n,l)=>n+boxCount(originalBounds(l)),0),newCost=lobes.reduce((n,l,i)=>n+boxCount(prepared.find(v=>v.index===i)?.raster??originalBounds(l)),0);
    const groupOldCost=ids.reduce((n,i)=>n+boxCount(originalBounds(lobes[i])),0),groupNewCost=prepared.reduce((n,v)=>n+boxCount(v.raster),0);
    const coreBefore=lobes[selected.index].slice(0,3),coreAfter=prepared.find(v=>v.index===selected.index).center;
    models.push({...base,applies:true,matureSummitIndex:mature,matureFoundationIndex:foot,youngFoundationIndex:young[0],candidates,selection:selected,selectedCount:ids.length,selectedIds:ids,parentLinksSHA256:sha(JSON.stringify(parents)),rotation,pivot,shoulderAnchors:{start:shoulderStart,end:shoulderEnd},prepared,coreDisplacement:{before:coreBefore,after:coreAfter,delta:coreAfter.map((v,a)=>v-coreBefore[a])},
      preservation:{rngCalls:0,lobeCount:true,lobeOrder:true,localRadii:true,localEllipsoidVolume:true,blend:true,otherParametersExact:true,otherMetadataSHA256:sha(JSON.stringify(lobes.map((l,i)=>ids.includes(i)?null:l))),globalRecontraction:false,shoulderMutated:false},
      bounds:{axisOrder:['xmin','xmax','ymin','ymax','zmin','zmax'],selectedPositiveMargins:margins(positiveLo,positiveHi),selectedFieldMinus035Margins:margins(haloLo,haloHi),allPrimitivePositiveMargins:margins(positiveGlobalLo,positiveGlobalHi),onlyRotatedGroupBoundsChanged:true,negativeHaloFormula:'h_i=hypot(R_i0*rx,R_i1*ry,R_i2*rz)*(1+.35/minRadius)',smoothUnionCaveat:'Primitive analytic extents, not a generated density-support or occupancy certificate'},
      theoreticalRaster:{baselineAllLobes:oldCost,candidateAllLobes:newCost,delta:newCost-oldCost,ratio:newCost/oldCost,baselineGroup:groupOldCost,candidateGroup:groupNewCost,ratioGroup:groupNewCost/groupOldCost,scope:'Clamped256 local-box iteration arithmetic; not measured bake/GPU/FPS cost; shoulder unchanged and excluded from both totals'}});
  }
  const frozen={model:'body-bulge-orientation-preflight-r1',baseline:'10493afa7f6d90389c39e17b2cad79397dfdac01',inputSourceSHA256:sha(original),status:'Frozen before any density comparison',selection:'Highest actual summit and matching foundation; positive maximum of mature authored-shoulder offset toward other foundation; actual parent closure; no seed/core/ordinal used to select',transform:'One shortest rigid rotation about axis point at original coreY from radial offset toward promoted14.1 tangent; centers and ellipsoid axes rotate once after original contraction; no RNG or new parameter',gate:{beak:'Both original tau1/tau3 fixed stencil densities strictly decrease',saddle:'Fine density integral and optical-depth integral strictly increase on identical complete original support-box window; fine positive-support length recorded',failure:'If either missing, retire without tuning,32/64,app or image'},camera:{origin:[0,2.7,16],width:2560,height:1440,tanFov:.2867,screenYOffset:-.16,inspection:0,time:60,seed:74,windStrength:.55,dispersion:0},saddle:{pixel:[1408,490],uv:[1408.5/2560,490.5/1440]},models};
  await writeFile(frozenPath,JSON.stringify(frozen,null,2)+'\n');
  const script=await readFile(fileURLToPath(import.meta.url));
  const manifest={modelSHA256:sha(await readFile(frozenPath)),scriptSHA256:sha(script),inputsManifestSHA256:sha(await readFile(`${qa}/inputs-manifest.json`)),noDensityProbeYet:true};
  await writeFile(`${qa}/freeze-manifest.json`,JSON.stringify(manifest,null,2)+'\n');
  console.log(JSON.stringify({freeze:manifest,seeds:models.map(v=>({seed:v.seed,count:v.selectedCount,selection:v.selection,rotation:v.rotation,coreDisplacement:v.coreDisplacement,bounds:v.bounds,theoreticalRaster:v.theoreticalRaster}))},null,2));
  process.exit(0);
}
assert.equal(process.argv[2],'probe','Use freeze or probe');
const freezeManifest=await readJSON('freeze-manifest.json'),modelData=await readFile(frozenPath),frozen=JSON.parse(modelData);
assert.equal(sha(modelData),freezeManifest.modelSHA256);assert.equal(sha(await readFile(fileURLToPath(import.meta.url))),freezeManifest.scriptSHA256);
const layout=stored.layout,lobes=layout.lobes,roles=new Map(layout.roles),parents=new Map(layout.parents),groups=stored.groups;
const groupName=i=>roles.get(i)??`streak-or-other-${i}`;
const model=frozen.models.find(v=>v.seed===74),transformed=new Map(model.prepared.map(v=>[v.index,v])),R=model.rotation.matrix;
let candidate=false;
const detailSize=128,seed=74;
const center=(i,a,n=size)=>bmin[a]+(i+.5)/n*extent[a];
const bounds=lobes.map(l=>({start:l.slice(0,3).map((c,a)=>Math.max(1,Math.floor((c-l[a+3]-.35-bmin[a])/extent[a]*size-.5))),end:l.slice(0,3).map((c,a)=>Math.min(size-2,Math.ceil((c+l[a+3]+.35-bmin[a])/extent[a]*size-.5)))}));
const mature=layout.summits.reduce((a,b)=>lobes[a][1]>lobes[b][1]?a:b),m=lobes[mature],foot=lobes[layout.foundations[layout.summits.indexOf(mature)]],cap=layout.iceCores.map(i=>lobes[i]).reduce((a,b)=>Math.hypot(a[0]-m[0],a[2]-m[2])<Math.hypot(b[0]-m[0],b[2]-m[2])?a:b);
const shoulder=mod.prepareInclinedShoulder([0,1,2].map(a=>foot[a]+(m[a]-foot[a])*.68),[cap[0]+cap[3]*.28,cap[1]-cap[4]*.1,cap[2]],Math.max(m[3]*.95,foot[3]*.62),Math.max(m[5]*.95,cap[5]*.68));
const shoulderBounds={start:shoulder.min.map((v,a)=>Math.max(1,Math.floor((v-.35-bmin[a])/extent[a]*size-.5))),end:shoulder.max.map((v,a)=>Math.min(size-2,Math.ceil((v+.35-bmin[a])/extent[a]*size-.5)))};
const iceRange=mod.iceHeights(seed),cellular=cellularNoise(seed+137),detailCellular=cellularNoise(seed+513);
const rawCache=new Map(),detailCache=new Map(),flowCache=new Map();let sdfEvaluations=0;
const counts={rawHits:0,rawMisses:0,detailHits:0,detailMisses:0,flowMisses:0};
function rawVoxel(x,y,z,skip=null,trace=false) {
  x=Math.max(0,Math.min(size-1,x));y=Math.max(0,Math.min(size-1,y));z=Math.max(0,Math.min(size-1,z));
  const key=`${x},${y},${z}`,cacheKey=`${candidate?"candidate":"baseline"}:${skip===null?key:`${skip}:${key}`}`;
  if(!trace&&rawCache.has(cacheKey)){counts.rawHits++;return rawCache.get(cacheKey);}
  counts.rawMisses++;if(x===0||y===0||z===0||x===size-1||y===size-1||z===size-1)return {value:0,field:-10};
  const p=[center(x,0),center(y,1),center(z,2)];let field=-10,weights=new Map(),prefix=[];
  const merge=(sd,blend,id)=>{const old=field,h=clamp(.5+.5*(old-sd)/blend);field=Math.fround(sd+(old-sd)*h+blend*h*(1-h));
    if(trace&&h<1){for(const [key,w]of weights){const nw=w*h;if(nw<1e-12)weights.delete(key);else weights.set(key,nw);}weights.set(id,(weights.get(id)??0)+1-h);prefix.push({id,sd,h,before:old,after:field});}};
  for(let i=0;i<lobes.length;i++) {
    if(skip!==null&&groups[i]===skip)continue;const transformedLobe=candidate?transformed.get(i):null,b=transformedLobe?.raster??bounds[i];if(x<b.start[0]||x>b.end[0]||y<b.start[1]||y>b.end[1]||z<b.start[2]||z>b.end[2])continue;
    const l=lobes[i];let sd;
    if(transformedLobe){const d=p.map((v,a)=>v-transformedLobe.center[a]),q=[0,1,2].map(a=>R.reduce((s,row,b)=>s+row[a]*d[b],0));sd=(1-Math.sqrt((q[0]/l[3])**2+(q[1]/l[4])**2+(q[2]/l[5])**2))*Math.min(l[3],l[4],l[5]);}
    else sd=(1-Math.sqrt(((p[0]-l[0])/l[3])**2+((p[1]-l[1])/l[4])**2+((p[2]-l[2])/l[5])**2))*Math.min(l[3],l[4],l[5]);
    sdfEvaluations++;merge(sd,l[6]??.2,i);
  }
  const b=shoulderBounds;
  if(skip!=='shoulder'&&x>=b.start[0]&&x<=b.end[0]&&y>=b.start[1]&&y<=b.end[1]&&z>=b.start[2]&&z<=b.end[2])merge(shoulder.sample(...p),.16,'shoulder');
  let value=0,carving=null;
  if(field>=-.3){const px=p[0]-bmin[0],py=p[1]-bmin[1],pz=p[2]-bmin[2];
    const n1=noise(px*1.25,py*1.25,pz*1.25,seed),n2=noise(px*3.6,py*3.6,pz*3.6,seed+12),n3=noise(px*9,py*9,pz*9,seed+42),c1=cellular(px*1.8,py*1.8,pz*1.8),c2=cellular(px*4.5,py*4.5,pz*4.5);
    const erosion=Math.min(0,(n1-.5)*.2-(1-c1)*.52-(1-c2)*.2+(n3-.5)*.1),ice=smoothstep(...iceRange,p[1]),fibers=noise(px*.3+py*.17,py*5,pz,seed+81),interior=1-.6*smoothstep(.04,.28,field);
    carving=erosion*mod.heightErosionScale(p[1])*interior*(1-ice)-(.012+(1-fibers)*.045+(1-n1)*.07+(1-n2)*.025)*ice;
    value=Math.round(Math.fround(clamp((field+carving-(.025-.017*ice))*(10+ice*4))*(.65+.35*n2)*(1-ice*(1-fibers)*.5)*clamp((p[1]-.72)/.24))*255)/255;
  }
  const result={value,field};if(trace)Object.assign(result,{index:[x,y,z],point:p,carving,weights:[...weights].map(([id,weight])=>({id,weight,group:id==='shoulder'?'shoulder':groups[id],role:id==='shoulder'?'inclinedShoulder10493':groupName(groups[id]),lobe:id==='shoulder'?null:lobes[id]})),prefix});
  if(!trace)rawCache.set(cacheKey,result);return result;
}
function detailVoxel(x,y,z){x=(x+detailSize)%detailSize;y=(y+detailSize)%detailSize;z=(z+detailSize)%detailSize;const key=`${x},${y},${z}`;
  if(detailCache.has(key)){counts.detailHits++;return detailCache.get(key);}counts.detailMisses++;
  const p=[(x+.5)/detailSize,(y+.5)/detailSize,(z+.5)/detailSize];
  const v=[Math.round((detailCellular(p[0]*32,p[1]*32,p[2]*32)*.65+noise(p[0]*8,p[1]*8,p[2]*8,seed,8)*.35)*255)/255,
    Math.round(noise(p[0]*16,p[1]*16,p[2]*16,seed+21,16)*255)/255,Math.round(noise(p[0]*32,p[1]*32,p[2]*32,seed+39,32)*255)/255];detailCache.set(key,v);return v;}
function linearDetail(p){const v=p.map(x=>(x-Math.floor(x))*detailSize-.5),i=v.map(Math.floor),f=v.map((x,a)=>x-i[a]),sum=[0,0,0];
  for(let z=0;z<2;z++)for(let y=0;y<2;y++)for(let x=0;x<2;x++){const q=detailVoxel(i[0]+x,i[1]+y,i[2]+z),w=(x?f[0]:1-f[0])*(y?f[1]:1-f[1])*(z?f[2]:1-f[2]);for(let c=0;c<3;c++)sum[c]+=q[c]*w;}return sum;}
function macro(p,skip=null,trace=false){const v=p.map((x,a)=>clamp((x-bmin[a])/extent[a])*size-.5),i=v.map(Math.floor),f=v.map((x,a)=>x-i[a]);let sum=0;const neighbors=[];
  for(let z=0;z<2;z++)for(let y=0;y<2;y++)for(let x=0;x<2;x++){const q=rawVoxel(i[0]+x,i[1]+y,i[2]+z,skip,trace),w=(x?f[0]:1-f[0])*(y?f[1]:1-f[1])*(z?f[2]:1-f[2]);sum+=q.value*w;if(trace)neighbors.push({...q,trilinearWeight:w});}return{value:sum,neighbors};}
const state=mod.motionState(60,seed);state.dispersion=0;
const wind=[.55*(.52+.23*Math.sin(60*.055+state.seedPhase*3)),.55*.26*Math.sin(60*.031+.6)],drift=[.55*(.32*Math.sin(60*.027)+.11*Math.sin(60*.071)),Math.sin(60*.04)*.015,0];
function flow(p){const v=p.map((x,a)=>(x-bmin[a])/extent[a]*16-.5),i=v.map(Math.floor),f=v.map((x,a)=>x-i[a]),out=[0,0,0,0];
  for(let z=0;z<2;z++)for(let y=0;y<2;y++)for(let x=0;x<2;x++){const k=[i[0]+x,i[1]+y,i[2]+z].map(a=>Math.max(0,Math.min(15,a))),key=k.join(',');let q=flowCache.get(key);
    if(!q){q=[0,0,0,0];mod.writeDisplacement(center(k[0],0,16),center(k[1],1,16),center(k[2],2,16),state,iceRange,q);q=q.map(c=>mod.DataUtils.fromHalfFloat(mod.DataUtils.toHalfFloat(c)));flowCache.set(key,q);counts.flowMisses++;}
    const w=(x?f[0]:1-f[0])*(y?f[1]:1-f[1])*(z?f[2]:1-f[2]);for(let c=0;c<4;c++)out[c]+=q[c]*w;}return out;}
function densityAt(world,skip=null,trace=false){const reference=mod.referencePosition(world.map((v,a)=>v-drift[a]),state,iceRange,wind),flowValue=flow(reference),local=reference.map((v,a)=>v-flowValue[a]),ice=smoothstep(...iceRange,local[1]),fine=linearDetail(local.map(v=>v*.3));
  const warpedPoint=local.map((v,a)=>v+([fine[1],fine[2],fine[0]][a]-.5)*([.16,.12,.16][a]+([.08,.02,.1][a]-[.16,.12,.16][a])*ice)),raw=macro(warpedPoint,skip,trace);
  let erosion=(1-fine[0])*.38+(1-fine[2])*.08+flowValue[3],material=1;
  if(ice>0){const bend=linearDetail([local[0]*.12,local[1]*.10,local[2]*.06])[1],iceDetail=linearDetail([local[0]*.055+bend*.08,local[1]*.34+local[0]*.022+(bend-.5)*.06,local[2]*.08+(bend-.5)*.025]),wisps=iceDetail[0];
    erosion=erosion*(1-ice)+(.08+(1-wisps)*.5+flowValue[3])*ice;const strand=smoothstep(.3,.7,wisps);material=1-ice+(.012+.56*strand**1.7)*(.65+.35*smoothstep(.25,.75,iceDetail[2]))*(1-.7*smoothstep(.4,3.8,local[0]))*ice;}
  erosion=Math.min(.92,erosion);let density=raw.value>=.002?clamp((raw.value-erosion)/(1-erosion))*material:0;if(density<.002)density=0;
  const result={density,sigma:mod.materialExtinction(ice)*density,world,reference,local,warpedPoint,ice,flow:flowValue,raw:raw.value,erosion,material};if(trace)result.neighbors=raw.neighbors;return result;}
const prior=JSON.parse(await readFile(`${qa}/input/prior-native-support.json`,'utf8')),box=prior.rendererSupportBounds,origin=[0,2.7,16],width=2560,height=1440,step=7/384;
const requests=[{name:'becco',uv:[.535,.304]},{name:'polso',uv:[.528,.257]},{name:'spalla-esterna',uv:[.441,.321]}],rays=[],attributions=[];
for(const req of requests){const pixel=[Math.floor(req.uv[0]*width),Math.floor(req.uv[1]*height)],uv=[(pixel[0]+.5)/width,(pixel[1]+.5)/height],screen=[uv[0]*2-1,1-uv[1]*2-.16],un=[screen[0]*(width/height)*.2867,screen[1]*.2867,-1],len=Math.hypot(...un),ray=un.map(v=>v/len);
  const intervals=ray.map((d,a)=>[(box.min[a]+drift[a]-origin[a])/d,(box.max[a]+drift[a]-origin[a])/d].sort((a,b)=>a-b)),near=Math.max(0,...intervals.map(v=>v[0])),far=Math.min(...intervals.map(v=>v[1]));
  const fract=x=>x-Math.floor(x),jitter=fract(52.9829189*fract(pixel[0]*.06711056+pixel[1]*.00583715));
  let t=near+step*jitter,tau=0;const samples=[],targets=[];
  while(t<far&&tau< -Math.log(.006)){const p=origin.map((v,a)=>v+ray[a]*t),d=densityAt(p),ds=Math.min(step,far-t),increment=d.sigma*ds,previous=tau;tau+=increment;
    samples.push({t,world:p,density:d.density,sigma:d.sigma,tau});
    for(const target of [1,3])if(previous<target&&tau>=target){const hitT=t+ds*(target-previous)/increment,interpolatedWorld=origin.map((v,a)=>v+ray[a]*hitT),world=p,stencil=densityAt(world,null,true),weights=new Map();
      for(const n of stencil.neighbors)for(const w of n.weights??[]){const signal=w.weight*n.value*n.trilinearWeight;weights.set(w.group,(weights.get(w.group)??0)+signal);}
      const total=[...weights.values()].reduce((a,b)=>a+b,0),ranking=[...weights].map(([group,weight])=>({group,role:group==='shoulder'?'inclinedShoulder10493':groupName(group),supportWeight:weight,normalizedWeight:total?weight/total:0,core:group==='shoulder'?null:lobes[group]})).sort((a,b)=>b.supportWeight-a.supportWeight);
      const item={name:req.name,targetTau:target,sampleT:t,hitT,interpolatedWorld,tauBefore:previous,tauAfter:tau,stencil,ranking};attributions.push(item);targets.push({targetTau:target,sampleT:t,hitT,interpolatedWorld,tauBefore:previous,tauAfter:tau,world,local:stencil.local,density:stencil.density,ranking:ranking.slice(0,5)});
    }t+=ds;
  }
  rays.push({name:req.name,requestedUV:req.uv,pixel,uv,screen,origin,ray,near,far,jitter,step,finalTau:tau,targets,samples});

}

assert.deepEqual(rays,previous.rays,'Old baseline rays do not reproduce exactly; stop before saddle/candidate');
assert.deepEqual(attributions,stored.attributions,'Old baseline stencil fields, bytes and contributor prefixes do not reproduce exactly');
const oldStencilBytes=Buffer.from(stored.attributions.flatMap(v=>v.stencil.neighbors.map(n=>Math.round(n.value*255))));
const newStencilBytes=Buffer.from(attributions.flatMap(v=>v.stencil.neighbors.map(n=>Math.round(n.value*255))));
assert.deepEqual(newStencilBytes,oldStencilBytes);
const reproduction={exactAllThreeRays:true,exactAllSixStencils:true,macroR8Bytes:newStencilBytes.length,macroR8SHA256:sha(newStencilBytes),fullStencilJSONSHA256:sha(JSON.stringify(attributions)),originalStencilJSONSHA256:sha(JSON.stringify(stored.attributions)),trigProvenance:'Frozen actual10493 layout, no primitive regeneration; existing Node/Bun sin/cos seed72 diagnosis does not imply seed74 identity; identity here independently checked on exact old ray/stencil objects'};
await writeFile(`${qa}/baseline-reproduction.json`,JSON.stringify(reproduction,null,2)+'\n');
console.log(JSON.stringify({baselineReproduced:reproduction}));
function rayForPixel(name,pixel){const uv=[(pixel[0]+.5)/width,(pixel[1]+.5)/height],screen=[uv[0]*2-1,1-uv[1]*2-.16],un=[screen[0]*(width/height)*.2867,screen[1]*.2867,-1],len=Math.hypot(...un),ray=un.map(v=>v/len),intervals=ray.map((d,a)=>[(box.min[a]+drift[a]-origin[a])/d,(box.max[a]+drift[a]-origin[a])/d].sort((a,b)=>a-b)),near=Math.max(0,...intervals.map(v=>v[0])),far=Math.min(...intervals.map(v=>v[1])),fract=x=>x-Math.floor(x),jitter=fract(52.9829189*fract(pixel[0]*.06711056+pixel[1]*.00583715));return {name,pixel,uv,screen,origin,ray,near,far,jitter,step};}
const completeRequests=[...rays.map(({name,pixel,uv,screen,origin,ray,near,far,jitter,step})=>({name,pixel,uv,screen,origin,ray,near,far,jitter,step})),rayForPixel('sella',frozen.saddle.pixel)];
function integrate(req,isCandidate){candidate=isCandidate;let t=req.near+step*req.jitter,tau=0,densityIntegral=0,positiveSupportLength=0,firstPositive=null,lastPositive=null,maxDensity=0;const targets=[],samples=[];
  while(t<req.far){const world=origin.map((v,a)=>v+req.ray[a]*t),d=densityAt(world),ds=Math.min(step,req.far-t),before=tau;densityIntegral+=d.density*ds;tau+=d.sigma*ds;
    if(d.density>=.002){positiveSupportLength+=ds;if(firstPositive===null)firstPositive=t;lastPositive=t;}
    maxDensity=Math.max(maxDensity,d.density);
    for(const target of [1,3])if(before<target&&tau>=target)targets.push({target,sampleT:t,hitT:t+ds*(target-before)/(d.sigma*ds),density:d.density});
    samples.push({t,density:d.density,sigma:d.sigma,tau,raw:d.raw,ice:d.ice});t+=ds;
  }
  return {tau,densityIntegral,positiveSupportLength,firstPositive,lastPositive,maxDensity,targets,samples};
}
const comparisons=[];
for(const req of completeRequests){const baseline=integrate(req,false),changed=integrate(req,true);comparisons.push({ray:req,baseline,candidate:changed,delta:{tau:changed.tau-baseline.tau,densityIntegral:changed.densityIntegral-baseline.densityIntegral,positiveSupportLength:changed.positiveSupportLength-baseline.positiveSupportLength,firstPositive:changed.firstPositive===null||baseline.firstPositive===null?null:changed.firstPositive-baseline.firstPositive}});}
const stencils=[];
for(const old of stored.attributions){candidate=true;const now=densityAt(old.stencil.world,null,true);stencils.push({name:old.name,targetTau:old.targetTau,world:old.stencil.world,baselineDensity:old.stencil.density,candidateDensity:now.density,deltaDensity:now.density-old.stencil.density,baselineRaw:old.stencil.raw,candidateRaw:now.raw,candidateStencil:now});}
const beak=stencils.filter(v=>v.name==='becco'),saddle=comparisons.find(v=>v.ray.name==='sella');
const gate={bothBeakStencilDensitiesDecrease:beak.every(v=>v.deltaDensity<0),saddleFineDensityIntegralIncreases:saddle.delta.densityIntegral>0,saddleTauIncreases:saddle.delta.tau>0,saddlePositiveSupportLengthDelta:saddle.delta.positiveSupportLength};
gate.pass=gate.bothBeakStencilDensitiesDecrease&&gate.saddleFineDensityIntegralIncreases&&gate.saddleTauIncreases;
const report={model:frozen.model,modelSHA256:freezeManifest.modelSHA256,sourceSHA256:sha(original),runtime:{node:process.version,platform:process.platform,arch:process.arch},reproduction,gate,decision:gate.pass?'Necessary local preflight conditions passed; no automatic32/64/app/visual followup authorized':'Retired: necessary preflight condition missing; no tuning32/64/app/image',frozenSelection:model.selection,reliefDisplacement:model.coreDisplacement,runtimeState:{state,wind,drift,iceRange,origin,box,ordinaryStep:step},comparisons,stencils,work:{originalRays:3,additionalFixedRays:1,detailedOldStencils:attributions.length,detailedCandidateStencils:stencils.length,completeWindowRaySamples:comparisons.reduce((n,v)=>n+v.baseline.samples.length+v.candidate.samples.length,0),...counts,sdfEvaluations,rawCacheEntries:rawCache.size,detail128Texels:detailCache.size,flow16Texels:flowCache.size,noFullVolume:true,noRNG:true,noGPU:true},limitations:['Only four fixed rays and twelve detailed stencils, not an image or whole-field density/support certificate.','Exact reproduction of the oldCPU reference is not bit-exactGPU equivalence: WGSL arithmetic/jitter can differ.','Complete-window optical depth deliberately has no T<.006 stop; baseline/candidate share the same sampling window and phase.','No RGB/light cache reconstructed; material/extinction/detail/flow parameters retained identically.','Analytic boxes and raster iteration arithmetic are not GPU cost or measured bake timing.','No claim that preserved ellipsoid volumes preserve union density or optical mass.']};
await writeFile(`${qa}/probe-results.json.gz`,gzipSync(JSON.stringify(report)));
await writeFile(`${qa}/result-summary.json`,JSON.stringify({...report,comparisons:comparisons.map(v=>({...v,baseline:{...v.baseline,samples:undefined},candidate:{...v.candidate,samples:undefined}})),stencils:stencils.map(({candidateStencil,...v})=>v)},null,2)+'\n');
console.log(JSON.stringify({gate,decision:report.decision,comparisons:comparisons.map(v=>({name:v.ray.name,baseTau:v.baseline.tau,newTau:v.candidate.tau,baseFine:v.baseline.densityIntegral,newFine:v.candidate.densityIntegral,baseSupport:v.baseline.positiveSupportLength,newSupport:v.candidate.positiveSupportLength,delta:v.delta})),stencils:stencils.map(({candidateStencil,...v})=>v),work:report.work},null,2));
