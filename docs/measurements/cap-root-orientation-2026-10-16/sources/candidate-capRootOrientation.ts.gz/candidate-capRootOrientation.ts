type Point3 = readonly [number, number, number];
type Lobe = readonly [number, number, number, number, number, number, number?];

/** The shortest rigid rotation from the authored X axis toward the actual
 * mature-tower-to-incus direction. Local radii/volume are unchanged; both the
 * center offsets and ellipsoid axes rotate about the cap's own center.
 */
export function prepareCapRootOrientation(source: Point3, pivotInput: Point3) {
  if (![...source, ...pivotInput].every(Number.isFinite)) throw new RangeError('Cap root anchors must be finite');
  const pivot = [...pivotInput];
  const delta = pivot.map((v, i) => v - source[i]), length = Math.hypot(...delta);
  if (length < 1e-9) throw new RangeError('Cap root anchors must be distinct');
  const [c, y, z] = delta.map(v => v / length);
  const k = 1 / (1 + c);
  // Rodrigues rotation with cross([1,0,0], direction). The antiparallel
  // case chooses one fixed half-turn; no current sheared source needs it.
  const matrix = c > -1 + 1e-12 ? [
    [c, -y, -z],
    [y, 1 - y * y * k, -y * z * k],
    [z, -y * z * k, 1 - z * z * k],
  ] : [[-1, 0, 0], [0, -1, 0], [0, 0, 1]];
  return {
    pivot, direction: [c, y, z], matrix,
    prepare(lobe: Lobe, fieldMargin = .35) {
      const radii = [lobe[3], lobe[4], lobe[5]], slope = Math.min(...radii);
      if (![...lobe.slice(0, 6), fieldMargin].every(Number.isFinite) || slope <= 0 || fieldMargin < 0) {
        throw new RangeError('An oriented cap lobe needs positive radii and a finite nonnegative field margin');
      }
      const offset = pivot.map((v, i) => lobe[i]! - v);
      const center = matrix.map((row, axis) => pivot[axis] + row.reduce((sum, v, i) => sum + v * offset[i], 0));
      const radius = matrix.map(row => Math.hypot(...row.map((v, i) => v * radii[i])));
      // Exact AABB of the rotated ellipsoid's sd >= -fieldMargin region.
      // This includes the negative field halo used by the smooth union, rather
      // than bounding only rotated centers or leaving the old axis-aligned box.
      const factor = 1 + fieldMargin / slope;
      return {
        center, radii, matrix, slope,
        min: center.map((v, i) => v - radius[i] * factor),
        max: center.map((v, i) => v + radius[i] * factor),
        sample(x: number, y: number, z: number) {
          const dx = x - center[0], dy = y - center[1], dz = z - center[2];
          // R transpose maps world offsets back to the original local axes.
          // An orthonormal rotation preserves the original 1-Lipschitz bound.
          return (1 - Math.hypot(
            (dx * matrix[0][0] + dy * matrix[1][0] + dz * matrix[2][0]) / radii[0],
            (dx * matrix[0][1] + dy * matrix[1][1] + dz * matrix[2][1]) / radii[1],
            (dx * matrix[0][2] + dy * matrix[1][2] + dz * matrix[2][2]) / radii[2],
          )) * slope;
        },
      };
    },
  };
}
