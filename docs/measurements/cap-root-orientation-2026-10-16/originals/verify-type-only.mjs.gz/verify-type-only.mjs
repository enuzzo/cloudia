import {readFile,writeFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const qa=dirname(fileURLToPath(import.meta.url)),require=createRequire(`${qa}/candidate-source/package.json`),{transform}=require('esbuild');
const sha=b=>createHash('sha256').update(b).digest('hex');
const before=await readFile(`${qa}/r1-before-type-fix/capRootOrientation.ts`,'utf8');
const after=await readFile(`${qa}/candidate-source/src/cumulonimbus/capRootOrientation.ts`,'utf8');
const options={loader:'ts',format:'esm',sourcefile:'capRootOrientation.ts'};
const a=await transform(before,options),b=await transform(after,options);assert.equal(a.code,b.code);
await writeFile(`${qa}/diagnostics/helper-r1-r2-identical.mjs`,a.code);
const result={pass:true,beforeSourceSha256:sha(before),afterSourceSha256:sha(after),emittedJavaScriptSha256:sha(a.code),emittedBytes:Buffer.byteLength(a.code),
  exactJavaScriptEquality:true,change:'Only the non-null TypeScript assertion on the first three required tuple coordinates; erased during emission.',
  probeReuse:'Existing r1 CPU32/64 results retained because r1/r2 helper JavaScript is byte-identical; volume.ts unchanged.'};
await writeFile(`${qa}/type-only-equivalence.json`,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
