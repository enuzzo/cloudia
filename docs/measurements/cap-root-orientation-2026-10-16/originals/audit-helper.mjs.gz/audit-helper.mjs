import {readFile,writeFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const qa=dirname(fileURLToPath(import.meta.url)),require=createRequire(`${qa}/candidate-source/package.json`),{build}=require('esbuild');
const input=`${qa}/candidate-source/src/cumulonimbus/capRootOrientation.ts`,output=`${qa}/diagnostics/helper-audit.mjs`;
await build({entryPoints:[input],outfile:output,bundle:true,platform:'node',format:'esm',logLevel:'silent'});
const {prepareCapRootOrientation}=await import(output);
const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const near=(a,b)=>assert(Math.abs(a-b)<1e-10,`${a} != ${b}`);
const cases=[{name:'aligned',source:[0,0,0],pivot:[1,0,0]},
  {name:'oblique',source:[-1.3,.4,-.2],pivot:[.8,2.7,.9]},
  {name:'vertical',source:[.2,-1,.1],pivot:[.2,2,.1]},
  {name:'antiparallel',source:[2,1,-.5],pivot:[-1,1,-.5]}];
const results=[];
for(const c of cases) {
  const rotation=prepareCapRootOrientation(c.source,c.pivot),r=rotation.matrix;
  const det=dot(r[0],cross(r[1],r[2]));near(det,1);
  for(let a=0;a<3;a++)for(let b=0;b<3;b++)near(dot(r[a],r[b]),a===b?1:0);
  for(let a=0;a<3;a++)near(r[a][0],rotation.direction[a]);
  const lobe=[c.pivot[0]+.6,c.pivot[1]-.3,c.pivot[2]+.2,1.2,.07,.65,.045],p=rotation.prepare(lobe);
  near(Math.hypot(...p.center.map((v,i)=>v-c.pivot[i])),Math.hypot(.6,-.3,.2));
  assert.deepEqual(p.radii,lobe.slice(3,6));
  const oldVolume=4*Math.PI/3*lobe[3]*lobe[4]*lobe[5];near(oldVolume,oldVolume*det);
  for(let a=0;a<3;a++)near(Math.hypot(r[0][a],r[1][a],r[2][a])*p.radii[a],p.radii[a]);
  const factor=1+.35/p.slope;let maxBoundsViolation=0,maxFieldError=0;
  for(let j=0;j<256;j++) {
    const zz=1-2*(j+.5)/256,angle=j*Math.PI*(3-Math.sqrt(5)),rr=Math.sqrt(1-zz*zz);
    const u=[rr*Math.cos(angle),rr*Math.sin(angle),zz],local=u.map((v,i)=>v*p.radii[i]*factor),world=p.center.map((v,i)=>v+dot(r[i],local));
    const field=p.sample(...world);maxFieldError=Math.max(maxFieldError,Math.abs(field+.35));near(field,-.35);
    for(let a=0;a<3;a++){const violation=Math.max(p.min[a]-world[a],world[a]-p.max[a],0);maxBoundsViolation=Math.max(maxBoundsViolation,violation);assert(violation<1e-10);}
  }
  results.push({name:c.name,source:c.source,pivot:c.pivot,direction:rotation.direction,matrix:r,det,localAxesVolume:oldVolume,
    sampleCount:256,maxBoundsViolation,maxFieldError,centerDistancePreserved:true,radiiPreserved:true});
}
const badAnchors=[[[0,0,0],[0,0,0]],[[NaN,0,0],[1,0,0]],[[0,0,0],[Infinity,0,0]]];
for(const [a,b] of badAnchors)assert.throws(()=>prepareCapRootOrientation(a,b),RangeError);
const rotation=prepareCapRootOrientation([0,0,0],[1,1,.1]);
for(const lobe of [[0,0,0,0,1,1],[0,0,0,1,-1,1],[0,0,0,1,1,Infinity],[NaN,0,0,1,1,1]])assert.throws(()=>rotation.prepare(lobe),RangeError);
for(const margin of [-.1,NaN,Infinity])assert.throws(()=>rotation.prepare([0,0,0,1,1,1],margin),RangeError);
const report={pass:true,scope:'External helper audit only: aligned/oblique/vertical/antiparallel, determinant, orthonormality, lengths, local volume and negative-field halo bounds. No volume/grid/GPU generation.',
  helperSha256:createHash('sha256').update(await readFile(input)).digest('hex'),invalidCasesRejected:10,results};
await writeFile(`${qa}/helper-audit.json`,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({pass:true,cases:results.length,samples:1024,invalidCasesRejected:10}));
