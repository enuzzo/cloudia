import {createRequire} from 'node:module';
import {dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const qa=dirname(fileURLToPath(import.meta.url));
const require=createRequire(`${qa}/candidate-source/package.json`);
const {build}=await import(pathToFileURL(require.resolve('vite')));
await build({root:`${qa}/candidate-source`,cacheDir:`${qa}/vite-cache`,build:{outDir:`${qa}/trial-dist`,emptyOutDir:false}});
