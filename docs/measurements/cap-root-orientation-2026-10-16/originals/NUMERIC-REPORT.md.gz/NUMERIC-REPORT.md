# Radice dell’incus: variante esterna orientata

Stato: sorgenti r2 congelati, verifiche CPU mirate PASS, app pronta per QA visiva di root. Nessun PASS artistico. La variante di abbassamento della torre giovane è stata ritirata: qui entrambe le torri sono quelle di baseline10493.

## Fotografia e ipotesi

La fotografia di F.W.Baker (Farnborough,14aprile1923), Plate5 dell’International Atlas1930 ospitato da WMO, è stata realmente letta nel render completo della pagina PDF63 (indice62): `../anatomy-reference/WMO-Plate5-pdf63.png`. Fonte: https://cloudatlas.wmo.int/docs/ICA1930-optimized-for-web.pdf. La fotografia mostra un incus a ventaglio, con una massa spessa raccordata al corpo, striature che proseguono verso la nube e margini distali sfrangiati distinti dalle forme convettive arrotondate.

Questo sostiene l’interesse artistico di una prova sulla radice torre→incus; non convalida una rotazione particolare, né la nostra parametrizzazione. Il PDF, render e SHA sono conservati esternamente in anatomy-reference. Le definizioni attuali WMO di incus e cumulonimbus orientano la lettura morfologica, non forniscono questa formula: https://cloudatlas.wmo.int/en/clouds-supplementary-features-incus.html e https://cloudatlas.wmo.int/en/cumulonimbus-cb.html.

Nelle frontali74 del candidato precedente la cima destra perdeva competizione con la cella matura, ma diventava larga e piatta; nella laterale74 diventava un rigonfiamento quasi sferico sul fianco. U e uncino restavano forti. Nessun ulteriore tuning della seconda torre è incluso qui.

## Una sola trasformazione

Il primo core dell’incus, i suoi10billow ice e i14puff generati dal capRng sono identificati da riferimenti parent semantici: 25 primitive distinte. Dopo la contrazione X/Z, una rotazione rigida minima porta il loro asse locale X nella direzione centro testa matura→centro cap0. Il pivot è il centro invariato di cap0. Si ruotano anche gli assi degli ellissoidi; non soltanto i loro centri. Nessun fattore artistico aggiuntivo, nuova popolazione o estrazione casuale.

Tutte le Lobe sorgenti restano esattamente identiche alla baseline. I field delle sole25primitive target sono valutati nella base ruotata; il resto del raster mantiene lo stesso ordine di smooth union. Le torri, il cap distale, gli streaks, tutte le altre primitive, il codice e i parametri della spalla10493 conservano gli stessi input. Questa invarianza delle primitive non implica invarianza del campo finale di densità o luce nelle zone sovrapposte.

I limiti di raster dei target sono l’AABB esatto della regione `sd≥−.35`, comprendendo l’alone negativo utile all’unione liscia. La rotazione ortonormale mantiene il limite1-Lipschitz del field ellissoidale. Il test numerico verifica matrice, assi e bound, mentre la conservatività del pre-filtro è verificata alle risoluzioni CPU dichiarate.

## Integrità e controlli

- Baseline:108file/612.911byte. Candidato r2:109file/616.725byte. Unici due sorgenti diversi: volume.ts e il nuovo capRootOrientation.ts.
- Volume SHA-256: `27a225f0b81a9d194844349cc4ed195f2e1099f1910548f75a8d8abd330617b2`.
- Helper r2 SHA-256: `e7a09cd38b0bd75a258f21beec1c8386402463ed393dde6391c3712319a0b327`.
- R1 è preservata in r1-before-type-fix. Un errore TS sul settimo elemento opzionale della tupla è stato corretto esclusivamente con `lobe[i]! - v`; JavaScript r1/r2 byte-identico, SHA `267b9bab2900b10d304a15b04371c21ccba241f32da481bb2526d4f0a0cf43fc`. Il riuso dei probe r1 è documentato in type-only-equivalence.json.
- Typecheck r2 PASS. Test esistenti volume+inclinedShoulder31/31PASS; emissione runtime identica tra r1/r2.
- Helper audit esterno:4casi (allineato,obliquo,verticale,antiparallelo), determinante+1/ortogonalità/lunghezze/volume geometrico;1.024punti sull’alone negativo entroAABB;10input nonvalidi nel dominio numerico respinti. Nessuna nuova suite nel progetto.
-20volumi CPU32³/64³ con dettaglio32³/64³:2.037.238voxel scartati rivalutati con campionatore fine, zero omissioni di densità positiva. Nessuna generazione256³.
-72/73 byte-identici su densità/RGBA/sunset/dettaglioRGBA. Su74/77/80 i25field target vengono preparati una sola volta; tutte le Lobe sorgenti, RNG e fattori di contrazione sono esatti. RumoreRGB identico.
- Una generazione aggiuntiva64³ seed74 del candidato r2 non strumentato conferma ogni hash del probe e i supportBounds.

| Seed | Massa R/255: variazione a64³ | R aumentati/diminuiti | Margine Y+ baseline→candidato |
|---|---:|---:|---:|
| 74 | +0.223% | 160/150 | 2.589844→2.457031 |
| 77 | +0.386% | 185/138 | 2.855469→2.589844 |
| 80 | +0.447% | 184/149 | 2.722656→2.324219 |

I restanti cinque margini alle facce restano identici a64³. Tutti i margini misurati sono positivi. I JSON riportano i sei valori anche a32³ e i supportBounds, che possono alzarsi insieme alla radice. La somma R/255 è densità quantizzata, non massa meteorologica; il volume geometrico locale di ciascun ellissoide resta invariato.

## Costo e rischio

Il bound dell’alone usa `1+.35/minRadius`: per i billow molto sottili aumenta sensibilmente il volume di raster. Conteggio esatto aritmetico delle scatole, senza generazione256³:

| Seed | Raster lobi totale teorico a256³ | Variazione | Gruppo target |
|---|---:|---:|---:|
| 74 | 83,735,916→119,708,915 | +43.0% | ×13.48 |
| 77 | 77,443,348→120,779,471 | +56.0% | ×16.22 |
| 80 | 78,114,440→110,576,287 | +41.6% | ×12.72 |

I conteggi escludono il pass della spalla invariato, rumore/dettaglio e luce. Sono lavoro del raster nella generazione iniziale; non una misura del tempo di bake o degli FPS. Non è stato stretto il bound né introdotto tuning per ridurre questo costo.

Il rischio visivo resta concreto: ruotare la radice può alzare/bombare il cap0 e accentuare l’uncino. La parte distale rimane appiattita e fibrosa; la QA deve verificare se il raccordo migliora senza un tetto a cupola o massa liscia. La fotografia WMO sostiene l’ipotesi del raccordo, non prova che questa variante lo ottenga.

## Riproduzione e app

Da questa directory, con le dipendenze locali originali accessibili dal symlink node_modules:

```sh
node verify-type-only.mjs
node audit-helper.mjs
node --expose-gc probe-cap-root.mjs
node --expose-gc confirm-uninstrumented.mjs
cd candidate-source
npm run typecheck
npm test -- src/cumulonimbus/volume.test.ts src/cumulonimbus/inclinedShoulder.test.ts --maxWorkers=1
cd ..
node build-app.mjs
```

Il probe salva sorgenti strumentati solo in diagnostics. Le esecuzioni di riproduzione sovrascrivono gli output esterni numerici. Il manifest delle sorgenti enumerate consente di verificare ogni file prima di eseguire. Build APP r2 passata, output trial-dist; nessuna build hero. Restante avviso usuale sui chunk oltre500kB.

Sorgenti congelati e riverificati dopo tutte le esecuzioni. Nessun prodotto/docs/Git modificato. Nessun browser/GPU/FPS gestito da questo sottoaudit.
