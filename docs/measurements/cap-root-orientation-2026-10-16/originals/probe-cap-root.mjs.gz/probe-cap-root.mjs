import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {gzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const qa=dirname(fileURLToPath(import.meta.url)),require=createRequire(`${qa}/candidate-source/package.json`),{build}=require('esbuild');
const sha=b=>createHash('sha256').update(b).digest('hex');
const exact=(text,target,replacement)=>{assert.equal(text.split(target).length,2,`Expected one target: ${target.slice(0,100)}`);return text.replace(target,replacement);};
const sizes=[32,64],seeds=[72,73,74,77,80],results=[],traces=[],reference=new Map(),sources={};
await mkdir(`${qa}/diagnostics`,{recursive:true});
const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),near=(a,b,tol=1e-10)=>assert(Math.abs(a-b)<=tol,`${a} != ${b}`);

function checkOriented(g) {
  let maxOrthogonalityError=0,maxBoundsError=0,maxRotationSampleError=0,maxObservedSlope=0;
  for(const o of g.oriented) {
    const {matrix:r,radii,center,slope,sample}=o,source=g.post[o.index],pivot=g.pivot;
    assert.deepEqual(radii,source.slice(3,6));
    for(let a=0;a<3;a++)for(let b=0;b<3;b++) {
      const error=Math.abs(dot(r[a],r[b])-(a===b?1:0));maxOrthogonalityError=Math.max(maxOrthogonalityError,error);assert(error<1e-12);
    }
    for(let a=0;a<3;a++)near(center[a],pivot[a]+dot(r[a],source.slice(0,3).map((v,i)=>v-pivot[i])));
    const factor=1+.35/slope;
    for(let a=0;a<3;a++)for(const sign of [-1,1]) {
      const extent=Math.hypot(...r[a].map((v,i)=>v*radii[i]));
      const local=radii.map((v,i)=>sign*r[a][i]*v*v*factor/extent);
      const world=center.map((v,i)=>v+dot(r[i],local));
      const error=Math.abs(world[a]-(sign<0?o.min[a]:o.max[a]));maxBoundsError=Math.max(maxBoundsError,error);assert(error<1e-10);
      near(sample(...world),-.35,1e-10);
      for(let b=0;b<3;b++)assert(world[b]>=o.min[b]-1e-10&&world[b]<=o.max[b]+1e-10);
    }
    for(let j=0;j<32;j++) {
      const local=[Math.sin(j*1.7),Math.cos(j*2.3),Math.sin(j*.9+.4)].map((v,i)=>v*radii[i]*1.6);
      const world=center.map((v,i)=>v+dot(r[i],local));
      const expected=(1-Math.hypot(...local.map((v,i)=>v/radii[i])))*slope;
      const error=Math.abs(sample(...world)-expected);maxRotationSampleError=Math.max(maxRotationSampleError,error);assert(error<1e-10);
      const offset=[.013,.021,-.017],other=world.map((v,i)=>v+offset[i]);
      const ratio=Math.abs(sample(...world)-sample(...other))/Math.hypot(...offset);maxObservedSlope=Math.max(maxObservedSlope,ratio);assert(ratio<=1+1e-10);
    }
  }
  return {primitives:g.oriented.length,axisBoundsChecks:g.oriented.length*6,sampleChecks:g.oriented.length*32,
    maxOrthogonalityError,maxBoundsError,maxRotationSampleError,maxObservedSlope};
}

for(const label of ['baseline','candidate']) {
  const root=`${qa}/${label}-source`,source=await readFile(`${root}/src/cumulonimbus/volume.ts`,'utf8');
  let code=exact(source,'function random(seed: number) {',`let __rngAudit:any[]=[];
function random(seed: number) {const audit={initialSeed:seed,words:[] as number[]};__rngAudit.push(audit);`);
  code=exact(code,'return ((t ^ t >>> 14) >>> 0) / 4294967296;',
    'const word=(t ^ t >>> 14) >>> 0;audit.words.push(word);return word/4294967296;');
  code=exact(code,'const shape=cloudParameters(seed);','const shape=cloudParameters(seed);const __contractions:any[]=[],__parents:any[]=[],__oriented:any[]=[];');
  code=exact(code,'const scale=Math.min(1,limit/extent);','const scale=Math.min(1,limit/extent);__contractions.push({axis,radius,limit,extent,scale});');
  const oldRaster='  // Rasterize lobes into their local bounds instead of testing every lobe at every voxel.';
  const newRaster='  // Rasterize in the original lobe order: smooth union is not associative.';
  const raster=label==='candidate'?newRaster:oldRaster;
  if(label==='candidate') {
    code=exact(code,'    lobes.push(lobe);\n    if(capRootLobes.has(parent)) capRootLobes.add(lobe);',
      '    lobes.push(lobe);__parents.push([lobe,parent]);\n    if(capRootLobes.has(parent)) capRootLobes.add(lobe);');
    code=exact(code,'    const oriented=capRootLobes.has(lobe)?capOrientation!.prepare(lobe):undefined;',
      '    const oriented=capRootLobes.has(lobe)?capOrientation!.prepare(lobe):undefined;if(oriented)__oriented.push({index:lobes.indexOf(lobe),...oriented});');
  }
  const geometry=`const __geometry={post:lobes.map(c=>[...c]),lobeCount:lobes.length,uniqueLobes:new Set(lobes).size,
    summits:summits.map(c=>lobes.indexOf(c)),foundations:foundations.map(c=>lobes.indexOf(c)),iceCores:iceCores.map(c=>lobes.indexOf(c)),
    contractions:__contractions,parents:__parents.map(([child,parent])=>[lobes.indexOf(child),lobes.indexOf(parent)]),oriented:__oriented,
    tagged:${label==='candidate'?'[...capRootLobes].map(c=>lobes.indexOf(c))':'[]'},
    core:${label==='candidate'?'capRoot?lobes.indexOf(capRoot):null':'null'},
    pivot:${label==='candidate'?'capOrientation?.pivot??null':'null'},direction:${label==='candidate'?'capOrientation?.direction??null':'null'},matrix:${label==='candidate'?'capOrientation?.matrix??null':'null'}};`;
  code=exact(code,raster,`${geometry}\n${raster}`);
  code=exact(code,'const supportMargin=.13+Math.hypot(...BOUNDS_SIZE)/size;',
    'const supportMargin=.13+Math.hypot(...BOUNDS_SIZE)/size;const __support={skipped:0,missed:0,maxMissed:0};');
  code=exact(code,'if(field[i]<-supportMargin) {density[i]=0;continue;}',`if(field[i]<-supportMargin) {
    const py=voxelCenter(y,1,size),ice=smoothstep(iceStart,iceEnd,py);
    const exact=sampleCloudDensity(envelope,detail,voxelCenter(x,0,size),py,voxelCenter(z,2,size),ice);
    __support.skipped++;if(exact>0){__support.missed++;__support.maxMissed=Math.max(__support.maxMissed,exact);}
    density[i]=0;continue;
  }`);
  code=exact(code,'return {size, data, sunsetLight, detail, supportBounds:',
    'return {size, data, sunsetLight, detail,diagnostics:{geometry:__geometry,support:__support,rng:__rngAudit},supportBounds:');
  code+='\nexport function __resetAudit(){__rngAudit=[];}\n';
  const stem=`${qa}/diagnostics/${label}`;await writeFile(`${stem}.ts`,code);
  await build({stdin:{contents:code,loader:'ts',sourcefile:'volume.ts',resolveDir:`${root}/src/cumulonimbus`},bundle:true,platform:'node',format:'esm',outfile:`${stem}.mjs`,logLevel:'silent'});
  sources[label]={runtimeSourceSha256:sha(source),instrumentedSourceSha256:sha(code),bundleSha256:sha(await readFile(`${stem}.mjs`))};
  const mod=await import(`${stem}.mjs`);
  for(const size of sizes)for(const seed of seeds) {
    mod.__resetAudit();const start=performance.now();let v=mod.generateVolume(size,seed),density=new Uint8Array(size**3),rgb=new Uint8Array(v.detail.size**3*3);
    const g=v.diagnostics.geometry,rng=v.diagnostics.rng.map(({initialSeed,words})=>({initialSeed,count:words.length,sha256:sha(new Uint32Array(words))}));
    const faces=[Infinity,Infinity,Infinity,Infinity,Infinity,Infinity];let mass=0,occupied=0;
    for(let z=0;z<size;z++)for(let y=0;y<size;y++)for(let x=0;x<size;x++) {
      const i=(z*size+y)*size+x,d=v.data[i*4];density[i]=d;mass+=d/255;if(!d)continue;occupied++;
      for(let a=0;a<3;a++){const p=mod.voxelCenter([x,y,z][a],a,size);faces[a*2]=Math.min(faces[a*2],p-mod.BOUNDS_MIN[a]);faces[a*2+1]=Math.min(faces[a*2+1],mod.BOUNDS_MIN[a]+mod.BOUNDS_SIZE[a]-p);}
    }
    for(let i=0;i<v.detail.size**3;i++)for(let c=0;c<3;c++)rgb[i*3+c]=v.detail.data[i*4+c];
    const hashes={density:sha(density),rgba:sha(v.data),sunset:sha(v.sunsetLight),detailRGBA:sha(v.detail.data),detailRGB:sha(rgb)};
    const item={label,size,seed,elapsedMs:performance.now()-start,hashes,occupied,mass,faceClearance:faces,supportBounds:v.supportBounds,support:v.diagnostics.support,rng,
      geometrySummary:{lobeCount:g.lobeCount,uniqueLobes:g.uniqueLobes,taggedCount:g.tagged.length,coreIndex:g.core,pivot:g.pivot,direction:g.direction,matrix:g.matrix,contractions:g.contractions}};
    assert.equal(item.support.missed,0,`${label}/${size}/${seed} skipped nonzero`);assert.equal(g.uniqueLobes,g.lobeCount);assert(faces.every(v=>v>0));
    const key=`${size}-${seed}`;
    if(label==='baseline')reference.set(key,{density,g,rng,hashes,faces,mass,supportBounds:v.supportBounds});
    else {
      const old=reference.get(key),sheared=mod.morphologyFamily(seed)==='sheared',tagged=new Set(g.tagged);
      assert.deepEqual(g.post,old.g.post,`${key} source primitive changed`);assert.deepEqual(rng,old.rng,`${key} RNG changed`);assert.deepEqual(g.contractions,old.g.contractions);
      assert.equal(tagged.size,sheared?25:0);assert.equal(g.oriented.length,tagged.size);assert.equal(new Set(g.oriented.map(o=>o.index)).size,tagged.size);assert(g.oriented.every(o=>tagged.has(o.index)));
      if(sheared) {const children=g.parents.filter(([a,b])=>b===g.core).map(([a])=>a);assert.equal(children.length,24);assert.deepEqual(new Set([g.core,...children]),tagged);}
      const math=checkOriented(g);let increased=0,decreased=0,equal=0,maxIncrease=0,maxDecrease=0;
      const changedMin=[Infinity,Infinity,Infinity],changedMax=[-Infinity,-Infinity,-Infinity];
      for(let i=0;i<density.length;i++){const d=density[i]-old.density[i];if(!d){equal++;continue;}if(d>0){increased++;maxIncrease=Math.max(maxIncrease,d);}else{decreased++;maxDecrease=Math.max(maxDecrease,-d);}
        const coords=[i%size,Math.floor(i/size)%size,Math.floor(i/(size*size))];for(let a=0;a<3;a++){const p=mod.voxelCenter(coords[a],a,size);changedMin[a]=Math.min(changedMin[a],p);changedMax[a]=Math.max(changedMax[a],p);}}
      item.comparison={allSourcePrimitiveExact:true,rngExact:true,contractionExact:true,orientedOnce:g.oriented.length,unorientedPrimitiveCount:g.lobeCount-g.oriented.length,math,
        channelEqual:Object.fromEntries(Object.entries(hashes).map(([k,h])=>[k,old.hashes[k]===h])),massChangePercent:(mass/old.mass-1)*100,
        density:{increased,decreased,equal,maxIncrease,maxDecrease,changedMin:increased+decreased?changedMin:null,changedMax:increased+decreased?changedMax:null},
        faceClearanceDelta:faces.map((v,i)=>v-old.faces[i]),supportBoundsExact:JSON.stringify(v.supportBounds)===JSON.stringify(old.supportBounds)};
      if(!sheared)assert(Object.values(item.comparison.channelEqual).every(Boolean),`${key} non-sheared output changed`);
      reference.delete(key);
    }
    if(size===32)traces.push({label,seed,geometry:g});results.push(item);
    await writeFile(`${qa}/comparison-32-64.partial.json`,JSON.stringify({sources,results},null,2)+'\n');
    console.log(JSON.stringify({label,size,seed,elapsedMs:Math.round(item.elapsedMs),tagged:g.tagged.length,mass,faces,support:item.support,
      comparison:item.comparison?{orientedOnce:item.comparison.orientedOnce,density:item.comparison.density,massChangePercent:item.comparison.massChangePercent}:null}));
    v=null;density=null;rgb=null;globalThis.gc?.();await new Promise(r=>setImmediate(r));
  }
}
await writeFile(`${qa}/geometry-traces.json.gz`,gzipSync(JSON.stringify({sources,traces})));
await writeFile(`${qa}/comparison-32-64.json`,JSON.stringify({description:'One source-cap group rigidly rotated toward mature-head-to-cap direction, baseline10493 towers retained. CPU32³/64³ with detail32³/64³, no native256/GPU/visual claim.',
  faceOrder:['x-','x+','y-','y+','z-','z+'],sizes,seeds,sources,results},null,2)+'\n');
console.log(JSON.stringify({pass:true,volumes:results.length,totalSkippedReevaluated:results.reduce((s,v)=>s+v.support.skipped,0),missed:results.reduce((s,v)=>s+v.support.missed,0)}));
