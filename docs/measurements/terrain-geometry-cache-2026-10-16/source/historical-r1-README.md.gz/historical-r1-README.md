# Trial esterno: cache della geometria del terreno

Base prodotto: `10493afa7f6d90389c39e17b2cad79397dfdac01`. La candidata rimane esterna; non modifica il prodotto, i documenti del repository o Git. Il flag `terrainCache=1` attiva il percorso sperimentale con etichetta `observatory-v50-terrain-geometry-cache-trial`.

## Implementazione congelata R1

Un target RGBA32F contiene `[distanza, slope.x, slope.z, altezza]`. La camera nuova usa prima il rendering diretto; la prima ripetizione della chiave ricostruisce il target prima di usarlo nello stesso frame. La chiave include i valori f32 caricati di origine, base della camera, aspect, tanFov, inspection, dimensioni interne, terreno e versione geometrica. Le modifiche di luce, cielo, nube e pioggia continuano a essere calcolate nel fragment shader.

Il prepass usa lo stesso QuadMesh e la stessa UV interpolata del rendering. La lettura usa `textureLoad(floor(uv*resolution),0)`, senza filtro. Il target ha FloatType/RGBAFormat, NoColorSpace, nearest, zero MSAA, nessun depth/stencil, mipmap o tone mapping. La fabbrica diretta conserva il codice WGSL e le sei librerie precedenti in tutte le 24 combinazioni verificate. Passi 384, volume 256³, dettaglio 128³, R8 della pioggia e resto dell'integrazione rimangono invariati.

La cache non corregge il solver del paesaggio né i suoi casi di correttezza ancora aperti. Un frame di ricostruzione contiene prepass + film; il ledger esistente conta entrambi i draw. I contatori della cache hanno invece durata pari alla vita dell'engine e includono il riscaldamento.

## Verifica esplicita e stato effettivo

Con il flag attivo: Regola → Misure → **Verifica record e rendering nativi**. Il JSON compatto è in `[data-testid="terrain-cache-witness-json"]`. La verifica non parte al caricamento; nessun benchmark parte automaticamente.

Il pulsante sospende i frame, conserva la cache valida della vista e confronta ogni componente dei buffer Float32 sulla griglia interna completa. Prima di ogni draw verifica il priming completo con una sentinella finita. Registra SHA256, lunghezze, NaN/Inf/sentinelle, tutte le differenze bit e nove record scelti prima della lettura. Un cambio scena o chiusura annulla il risultato. Target e materiali temporanei vengono rilasciati senza disporre la geometria condivisa di QuadMesh.

La prova geometrica confronta il prepass appena calcolato con quello conservato e consumato tramite textureLoad: qualifica indirizzo UV, storage e ripetibilità. Non legge gli intermedi del solver dentro il fragment shader diretto. La prova colore confronta i due fragment shader completi dopo cloudFilm, su target lineare Float32. Non misura il compositore o la presentazione del canvas.

R1 reale, eseguita dal root sul main thread a **2112×1844**: geometria **PASS**, 15.578.112 componenti bit-identiche, 3.857.434 hit e 37.094 miss, zero NaN/Inf/sentinelle/errori di validazione. SHA geometria `6e8c172a12ebce2da08dc9141a76b976f25085460cf390f0044506a3aba88b66`. Il render è **FAIL**: 95.690 componenti e 69.186 pixel differenti. I primi otto esempi hanno 1–3 ULP, ma R1 non registra il massimo e non consente di estendere questo limite a tutto il buffer. Il rapporto originale è `../browser/terrain-witness-r1-main.json`.

Il target residente misura 62.312.448 byte (circa 59,426 MiB) su questa griglia. La verifica aggiunge un target uguale e copie CPU per confronti e hash; il picco di memoria complessivo non è misurato. Nessun pixel t=0 è apparso: quel caso reale rimane aperto, sebbene il contratto dello shader conservi il confronto `>=0`. Worker reale, altre pose, resize, lifecycle e prestazioni attendono QA. Nessuna misura FPS è stata eseguita per questa candidata; nessuna promozione o promessa di 60 FPS.

## Prove CPU e build

`validation.json` conserva gli output delle verifiche: **115 test mirati PASS in 8 file**, typecheck PASS e build Vite PASS. I test dei due host sono test CPU dell'API condivisa e non provano l'esecuzione GPU nel worker. I test esterni importano intenzionalmente la copia baseline e non sono trasferibili automaticamente al prodotto.

Sono conservati anche gli errori iniziali corretti: un locale inutilizzato nel typecheck e un selettore del fixture UI che incontrava ID duplicati. Le verifiche finali passano. Vite segnala i chunk grandi e l'outDir esterno non svuotato; non sono prove di compilazione WGSL o di console GPU pulita.

`baseline-manifest.json` documenta i 108 file uguali alla base Git. `candidate-manifest.json` elenca 116 file e gli 11 percorsi aggiunti/modificati. `emitted-template-witnesses.json` e `emitted/` conservano i contratti WGSL emessi. `dist-manifest.json` identifica i 20 file della build. `node_modules` è solo un link alle dipendenze locali già disponibili, escluse da Git e con attributo File Provider ignore=1 ricontrollato dopo la build. Nessuna installazione o modifica del lockfile.

Il freeze R1 lossless comprende sorgenti candidati, build e prove disponibili; i payload sono archiviati byte per byte, senza normalizzare spazi o fine file. Eventuali revisioni successive della sola strumentazione devono mantenere il FAIL bit di R1 visibile e non modificare gli shader per forzare la parità.
