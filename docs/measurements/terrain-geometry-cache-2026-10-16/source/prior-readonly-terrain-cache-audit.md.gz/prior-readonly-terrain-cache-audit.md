# Cache per pixel della geometria del terreno — audit, 16 ottobre 2026

**Scelta: una sola candidata esterna, RGBA32F con `[distanza, slope.x, slope.z, altezza]`, valida soltanto per gli stessi raggi della camera.** È un modo concreto di riusare il risultato del terreno attuale mentre luce, cielo, nube, pioggia e flusso continuano ad aggiornarsi. Non è una correzione del terreno né un guadagno FPS già dimostrato. Prima dell'implementazione conviene una misura diagnostica ground on/off nella stessa posa; qui non è stata eseguita.

Audit in sola lettura del checkpoint `10493afa7f6d90389c39e17b2cad79397dfdac01`. Unico file scritto: questo rapporto esterno. Nessun test, build, bake, GPU, browser, fetch dell'app o modifica del prodotto/documentazione/Git.

## Percorso reale e lavoro riutilizzabile

`cloudShader.ts:31–45` costruisce il raggio da UV, origin, forward/right/up, aspect, tanFov e **inspection**. Calcola il cielo live e `earthDistance`; quando la sfera marina è intersecata e `ground>0.001`, chiama `landscapeDistance` e poi `landscapeColor`. La distanza risultante limita sia `far` della nube sia `rainFar`: non serve soltanto a dipingere lo sfondo.

`landscapeDistance`, da `landscape.ts:108`, esegue sei valutazioni di `terrainHeight` nel solver vicino, quando il relief non è già sfumato a zero. `landscapeColor`, da riga121, ne esegue altre cinque: altezza centrale e quattro differenze finite per la pendenza. Ogni height contiene quattro noise delle ottave, uno della costa e uno del range. Restano inoltre quattro noise diretti per costa/canopy/roccia. Nel ramo vicino questo dà, a livello di sorgente, **11 height + 4 noise diretti**, cioè 70 chiamate noise prima di eventuali ottimizzazioni del compilatore. È un conteggio di espressioni, non di istruzioni o millisecondi GPU. Al mare lontano il solver può già saltare i sei height; dove il raggio non interseca il mare questo lavoro non viene chiamato.

Il terreno non dipende da seed della nube, tempo, vento, pioggia o cielo. Il clamp CPU della camera resta attivo: `GPUSceneEngine.ts:438–444` alza origin sopra il paesaggio e ricostruisce la base della vista dopo il clamp. Una nuova nube cambia però il focus tramite `installVolume`, quindi può cambiare i raggi pur senza cambiare il terreno.

La geometria e le pendenze possono essere riusate; colore finale e atmosfera devono restare live. Conservare il backdrop RGB finale congelerebbe invece sole, ambient, transizioni del cielo e haze.

## Record selezionato ed esattezza richiesta

Il prepass usa le **stesse funzioni WGSL attuali**, alla risoluzione interna piena. Per ogni pixel calcola prima il sea hit, quindi lo stesso solver e le stesse differenze finite, e scrive:

```text
RGBA32F = [tTerrain, slope.x, slope.z, terrainHeight(point.xz)]
miss della sfera marina = [-1, 0, 0, 0]
```

Nel pass principale, `point=origin+ray*tTerrain` resta calcolato con lo stesso raggio. `normal=normalize(vec3(-slope.x,1,-slope.z))` e `length(slope)` usano i valori memorizzati. Rimangono live le formule di albedo, costa, mare, solar/ambient, dot con sun, atmosfera e mix con sky; i quattro noise diretti del colore possono inizialmente rimanere calcolati ogni frame. Nessuna ricostruzione della pendenza dalla normale e nessun modello di illuminazione nuovo.

**Perché non `[t,normal.xyz]`:** la normale da sola perde la pendenza originaria che serve anche a `exposed`. Ricavarla come rapporto con `normal.y` introdurrebbe nuove operazioni e arrotondamenti; ricomputarla manterrebbe i quattro height più costosi. Due pendenze e altezza usano gli stessi quattro canali della distanza più normale, ma conservano gli input delle formule esistenti.

La sentinella deve distinguere il sea miss dal risultato `tTerrain=0`: il solver attuale può clampare a zero dopo un sea hit positivo. Una cache che trattasse `t<=0` come miss cambierebbe il comportamento. Il ramo `ground=0` continua a usare backdrop sky e `groundDistance=10000`, come ora. Anche normalizzazione e relief attuali restano identici, comprese le loro approssimazioni.

Lettura con `textureLoad` al texel intero corrispondente, senza sampler, interpolazione, mipmap, reproiezione, downsampling o TAA. `rgba32float`, NoColorSpace, nessun tone mapping/film/blending nel prepass, niente MSAA né depth/stencil. Non usare i default di una StorageTexture o RenderTarget senza impostarli esplicitamente. La [specifica WGSL per textureLoad](https://www.w3.org/TR/WGSL/#textureload) distingue questa lettura dal campionamento filtrato; la [tabella dei formati](https://www.w3.org/TR/WGSL/#texel-formats) definisce i canali 32float. Three r186 locale mappa RGBAFormat+FloatType a RGBA32Float e tratta FloatType come unfilterable quando manca float32-filterable.

Un prepass raster con lo stesso QuadMesh, gli stessi UV interpolati dai vertici e lo stesso viewport origin è preferibile come prima prova per condividere UV e pixel center. **Non assumere** che UV del target offscreen e del canvas abbiano la stessa orientazione: flip Y, viewport, scissor e indice di textureLoad devono essere qualificati sul percorso Three realmente compilato. Un compute che inventa UV da `(pixel+.5)/resolution` non è automaticamente identico all'interpolazione attuale.

Il formato non aggiunge quantizzazione rispetto a f32, ma spostare espressioni in un altro pass può cambiare le scelte di compilazione. Riassociazione e fusione sono consentite dalla [specifica WGSL §15.7.5](https://www.w3.org/TR/WGSL/#reassociation-and-fusion). Identità dei risultati va quindi verificata nel backend reale, non dedotta dalla sola algebra.

## Chiave completa e invalidazione

La chiave viene costruita **dopo** applySize, frame della camera e clamp, dai bit f32 effettivamente caricati nelle uniform, senza tolleranze geometriche o soglie epsilon.

| Dato | Regola |
|---|---|
| Origin clamped + forward/right/up | Tutti i componenti; un bit diverso invalida. Target/yaw/pitch sono cause indirette, non una chiave sufficiente. |
| Aspect, tanFov, inspection | Tutti necessari. Inspection modifica direttamente l'offset verticale del raggio di `0.16*(1-inspection)`. TanFov è oggi fisso a 0,2867 ma deve essere comunque parte del contratto. |
| Risoluzione interna W/H e convenzione pixel | Deve coincidere esattamente con il pass principale; resize, DPR/output e quality scale possono cambiarla. Nessun riuso per un'altra griglia. |
| Ground | A zero nessuna costruzione o lettura; alla riattivazione rebuild prima del percorso cached. Oggi è un controllo binario. |
| Versione della geometria | Hash/versione di height, sfera, relief, solver, passi e formula della pendenza. Non basta TERRAIN_HASH_ID se cambia il solver mantenendo lo stesso hash del rumore. |
| Device/risorsa/generazione del renderer | Nuovo device, perdita GPU, nuova allocazione o dimensione invalidano tutto. Una chiave uguale non rende validi byte di un texture appena riallocato. |
| Sole, solar/ambient, sky/haze, rain, cloud motion | Non invalidano il record geometrico; continuano a entrare nello shading e nell'integrazione. Se un loro effetto sposta davvero la camera, lo rileva la chiave dei raggi. |

Il normale `invalidate(reason)` dell'engine, riga 679, annulla le misure: **non è oggi un invalidatore di cache**. Non collegare indistintamente a quello ogni evento, altrimenti un cambio di luce ricostruirebbe dati statici e confonderebbe la prova.

Politica iniziale concreta: alla prima chiave nuova render diretto originale; se la chiave si ripete nel frame seguente, costruire il record e renderizzare la variante cached soltanto dopo quel pass nella stessa coda. Ogni mismatch torna subito al diretto; mai usare il vecchio risultato per una camera vicina. Durante drag/orbit continuo il percorso diretto evita un rebuild per frame. Il caso di camera che cambia a intermittenza può comunque rendere la politica poco conveniente: conteggiare miss, rebuild, frame di riuso e costo del rebuild; non promuovere se la navigazione peggiora. Nessun cooldown è una licenza per mantenere una cache stale.

La vista ordinaria con orbit disattivato e approach zero ha raggi statici anche con la nube animata. A approach positivo il probe può aggiornare la distanza ogni circa 150 ms; drift/deformazione possono muovere il fronte anche senza input dell'utente. La chiave deve seguire origin reale, non soltanto gli eventi pointer. La diagnosi fissa con comparisonSurface salta quel probe, quindi da sola non copre la navigazione ordinaria.

## Memoria e costo: perché questa variante prima della cache completa

| Variante | Contenuto | Memoria nominale a 2560×1440 |
|---|---|---:|
| Solo distanza R32F | Toglie il solver; lascia cinque height del materiale | 14.745.600 B, 14,0625 MiB |
| **Selezionata, un RGBA32F** | Distanza + due pendenze + altezza; riusa gli undici height nel ramo vicino | **58.982.400 B, 56,25 MiB** |
| Completa, due RGBA32F | `[t,normal.xyz]` + `[albedo.rgb,coast]`; colore base statico, shading e atmosfera live | 117.964.800 B, 112,5 MiB |

La completa evita anche i quattro noise diretti, ma raddoppia la memoria nominale e le letture. Non è la prima candidata scelta. Memorizzare direttamente il colore illuminato sarebbe un'altra soluzione e avrebbe invalidazione dipendente da sole/cielo: esclusa da questo audit.

Un RGBA32F richiede 14,0625 MiB a720p, 31,640625 MiB a1080p e 126,5625 MiB a4K. Sono payload nominali; layout, allineamenti, residenza, target vecchio ancora in volo e compilazioni non sono misurati. A resize un picco con vecchia e nuova texture vive contemporaneamente va contabilizzato; niente doppio buffer persistente introdotto senza motivo.

**Niente half:** a16 km la spaziatura f16 è 15,625 m, già maggiore del passo pioggia di6 m; a180 km è125 m. R32F mantiene invece il valore f32 del solver. Anche pendenze/normali/albedo half modificherebbero lo shading senza un budget di errore autorizzato. Non proporre compressione delle normali in questa prima prova.

Sul riuso caldo spariscono le valutazioni statiche selezionate, ma entrano un textureLoad per pixel e memoria residente. Il primo prepass scrive l'intero target, compresi i miss; i frame mobili usano ancora il diretto. Nessuna di queste osservazioni fornisce la quota temporale del terreno o uno speedup. Nei profili esistenti render e flusso sono separati; il terreno non ha un suo stage. Le misure native main del ciclo15 A2/A3 sono19,621/19,144 invii/s, ma non isolano il terreno né sono frame presentati. I profili v50 main/worker con target diverso non vanno sottratti a questi.

Ricerca storica limitata a docs/benchmarks e agli archivi rain-terrain, quality-v50, shared-aerial, aerial-consistency e reconstruction: nessun report con ground=0 e nessuna coppia affidabile0/1 trovata. I sedici record con ground esplicito, inclusi riepiloghi duplicati, sono tutti1; anche i due raw candidati rain-terrain sono1. I nomi delle browser storiche cycle* non individuano un ulteriore controllo ground-off. Non è una ricerca di ogni file sul Mac.

Una futura coppia diagnostica ground on/off nella stessa posa è utile, ma **non equivale al tempo del solo solver**: ground off elimina anche il limite terreno di far/rainFar, cambia lo sfondo e può aumentare il lavoro nube/pioggia. L'ablation `cache` già presente significa lettura delle vecchie cache ottiche al posto dello shading della nube, non cache del terreno. Flow congelato, R8 e narrowCloud sono altre leve già esistenti e non sostituiscono questa prova. Nessuna cache geometrica del terreno è già presente nel runtime.

## Correttezza del terreno e gate di una futura prova

Il solver attuale mantiene sei iterazioni non bracketed, derivata radiale senza gradiente del rilievo e gate preliminare sulla sfera marina. Il witness CPU archiviato trova un punto restituito2,837 km oltre la prima crossing rilevata, con clearance−1,580 km; non è una misura GPU. Ho verificato per confronto testuale che prefisso CPU e funzioni di intersezione del paesaggio attuale coincidono con il sorgente storico dopo aver rimosso le sole inclusioni aerial. L'audit della cache non risolve quell'errore, la montagna sopra l'orizzonte marino, il relief dipendente dal raggio90–180 km o la normale sul piano tangente.

La cache proposta è **per raggio/pixel**, quindi può conservare anche il relief dipendente da seaDistance; non assume una singola mesh world-space equivalente. Una nuova camera non può riusare quei dati mediante reproiezione. Un futuro solver corretto dovrà cambiare la versione della cache e rigenerarla. I prototipi bounds/gradient/pages restano esterni; il paging666→660 unresolved contro gate≤333 non è un'implementazione alternativa qualificata da riattivare per questa cache.

Prima di qualsiasi promozione: witness **cache0/cache1 con record raw e immagini native**, non soltanto JPEG, nel reale pass Three; confronto cold/hot inclusi hit/miss, t=0, costa, silhouette/horizon e witness difficile. Geometria/clipping devono restare identici alla baseline, senza spacciare tale identità per correttezza del solver. Poi cambi luce/cielo/pioggia e nube animata a camera ferma, verifica di ogni invalidazione, resize/DPR, reset/nuova nube, drag/orbit/approach e device loss/chiusura. Infine A/B/A ripetuto a qualità piena, separando cold/rebuild/hot e percorso mobile. Nessun valore atteso di FPS, nessuna soglia abbassata, nessun gate fotografico chiuso in anticipo.

## Risorse main/worker e integrazione circoscritta

Un solo oggetto di cache appartiene a GPUSceneEngine e al suo GPUDevice. CumulonimbusApp crea alternativamente main engine o render worker; il worker importa lo stesso engine. Non trasferire texture fra i due e non costruire i record nel worker dei volumi o sulla CPU. Nessun nuovo messaggio di protocollo o readback per il percorso ordinario.

Prepass/materiale/texture vengono creati e dimensionati dentro il lifecycle dell'engine. La variante cached aggiunge una texture senza sampler; la factory diretta e i suoi default devono rimanere disponibili come controllo byte-identico. Sul primo compile in start, prima di ready, usare il diretto o preparare esplicitamente il target: mai leggere una texture appena allocata come valida. installVolume ricrea il materiale e può cambiare focus: ricablare la risorsa e invalidare conservativamente. applySize ricrea griglia/validità. Visibilità può conservare una cache ancora valida ma al ritorno la chiave va ricalcolata.

I pass di rebuild devono entrare nei contatori/timestamp dello stesso draw e nella coda prima della lettura; niente submit GPU laterale non contabilizzato e niente attesa CPU per ogni frame. releaseGPU, che già attende inizializzazione, misure e completamenti registrati prima del dispose, deve rilasciare anche target, materiale e quad della cache in modo idempotente. Perdita del device e stop worker non possono pubblicare una cache pronta dopo destroy. Main e worker richiedono prova reale separata; il solo test del controller non basta.

## Provenienza consultata

| File sul checkpoint10493af | SHA256 |
|---|---|
| src/cumulonimbus/landscape.ts | `037a5bfcc60e0c342a85d32c5b50f25982e9366806b4f95ef4b28c5842b605c8` |
| src/cumulonimbus/cloudShader.ts | `652c9514b7dfcee1456d15e9966087b3ff9c6a6ce9741970208cfca3750a248c` |
| src/cumulonimbus/GPUSceneEngine.ts | `b829772a51d6e342adfd5e5e2fbb807037ae74d3ba8413ea7078e6962b4334a0` |
| src/cumulonimbus/camera.ts | `a7f7b113ee4251454e4f31fd8fa470f131dae3a9bc41ec5cf1d2480871066a69` |

Consultati inoltre renderProtocol/render.worker/CumulonimbusApp, Three r186 locale (WebGPUTextureUtils, WebGPUBindingUtils, StorageTexture e WGSLNodeBuilder), TERRAIN-INTERSECTION-AUDIT-2026-10-15, TERRAIN-BOUNDS-REFERENCE-2026-10-16, TERRAIN-PAGES-2026-10-16 e archivi di misura sopra elencati. Fonti primarie normative consultate16 ottobre2026: WGSL CRD21 settembre2026 e WebGPU capacità texture; nessun codice esterno copiato.
