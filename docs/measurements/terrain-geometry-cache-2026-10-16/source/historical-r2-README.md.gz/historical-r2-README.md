# R2: sola strumentazione numerica

La directory attuale `../candidate-source` contiene R2. Il riferimento lossless R1 è `../r1-immutable.tar.gz`; la sua build `../trial-dist` rimane byte-identica. R2 viene servita separatamente da `../trial-dist-r2`. Prodotto e Git non sono modificati.

Soltanto `terrainCacheWitness.ts` e il relativo test differiscono da R1. Engine, shader, prepass geometrico, UI e controller hanno gli stessi byte. Le 24 righe di prove sulle fabbriche WGSL e i 12 sorgenti emessi gzip sono identici. `candidate-manifest.json` e `dist-manifest.json` identificano i 116 file sorgente e i 20 file di build. `validation.json` conserva i risultati reali: **127 test mirati PASS in 8 file**, typecheck PASS, build Vite PASS (57 moduli, 2,41 s). I test dei due host sono CPU, non una verifica GPU nel worker.

Il pulsante e il percorso DOM del witness rimangono quelli di R1: Regola → Misure → **Verifica record e rendering nativi**, `[data-testid="terrain-cache-witness-json"]`. La verifica richiede un'azione esplicita; non parte un benchmark automatico.

Campi aggiunti al confronto completo dei buffer:

- `referenceRole`, `candidateRole`, `scopeLimit`: il confronto geometrico riguarda prepass fresco contro prepass conservato consumato con textureLoad. Non osserva il solver dentro il renderer diretto.
- `numeric.rgba`, `.rgb`, `.perChannel`: massimo assoluto, RMSE sul numero dichiarato di coppie finite, massimo della distanza ULP ordinata, posizioni dei massimi, istogramma ULP e conteggi dei bit. Alpha è incluso in RGBA e separato da RGB. I due zeri hanno distanza numerica zero ma restano distinguibili nei bit. I valori non finiti sono conteggiati ed esclusi dal denominatore RMSE; le sentinelle finite restano nelle statistiche numeriche e causano comunque FAIL.
- `quantization.linear8`, `.srgb8`: tutti i pixel RGB, dopo clamp [0,1] e arrotondamento al livello più vicino su 255. sRGB usa il trasferimento IEC con soglia 0,0031308 ed esponente 1/2,4. Alpha è escluso. Sono riportati canali/pixel differenti, massimo delta, posizioni, distribuzione dei delta e conteggi per canale. Un pixel RGB con NaN/Inf/sentinella viene escluso interamente da queste due elaborazioni e conteggiato separatamente.

Queste quantizzazioni CPU sono metriche derivate, non immagini lette dal compositore o una prova del display. Nessuna soglia converte un render diverso in PASS: uguaglianza dei bit, controlli dei dati invalidi e risultato originale rimangono invariati. Il report esplicita che il rounding è una possibile spiegazione, senza attribuzione causale al compilatore.

R1 reale rimane geometria PASS / render FAIL e non contiene pixel t=0. R2 richiede ancora l'esecuzione GPU del root sulla posa e sulla griglia effettivamente registrate nel nuovo JSON; non si presume pitch 0,36 o risoluzione 2560×1440. Nessun FPS è stato misurato dall'agente e nessuna promozione o accettazione artistica è implicita. La scansione e la conversione di tutti i valori avvengono solo nel witness sospeso, non nel percorso di rendering da misurare.
