import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {join,dirname} from 'node:path';
import {afterAll,afterEach,describe,expect,it,vi} from 'vitest';

vi.mock('three/tsl',async importOriginal=>{
  const actual=await importOriginal<typeof import('three/tsl')>();
  return {...actual,wgslFn:vi.fn(actual.wgslFn)};
});
import {wgslFn} from 'three/tsl';
import {createCloudIntegrator,createTerrainCachedCloudIntegrator} from './cloudShader';
import {createCloudIntegrator as original10493} from '../../../baseline-source/src/cumulonimbus/cloudShader';
import {createTerrainGeometryPass,createTerrainRecordReadPass,terrainCachedColor,TERRAIN_CACHE_LOAD,TERRAIN_CACHED_COLOR_WGSL,TERRAIN_SLOPE,TERRAIN_VIEW_RAY} from './terrainGeometry';

const hash=(source:string)=>createHash('sha256').update(source).digest('hex');
function nodeCode(node:unknown):string {
  if(typeof node!=='object'||node===null)throw new Error('Missing actual include node');
  const code=Reflect.get(node,'code');
  if(typeof code!=='string')throw new Error('Missing actual include WGSL');
  return code;
}
function capture(factory:()=>unknown){
  factory();
  const call=vi.mocked(wgslFn).mock.calls.at(-1);
  if(!call||typeof call[0]!=='string')throw new Error('Missing actual wgslFn source');
  const nodes=call[1]??[];
  return {code:call[0],nodes,libraries:nodes.map(nodeCode)};
}
function exactlyOnce(source:string,needle:string):void {expect(source.split(needle)).toHaveLength(2);}
function baseline(){return capture(()=>original10493());}
function originalColor(){
  const landscape=baseline().libraries[3],start=landscape.indexOf('fn landscapeColor(');
  expect(start).toBeGreaterThan(0);
  return landscape.slice(start);
}
function originalColorLine(prefix:string):string {
  const line=originalColor().split('\n').find(value=>value.trim().startsWith(prefix));
  if(!line)throw new Error(`Missing original landscapeColor line: ${prefix}`);
  return line.trim();
}
const directGround='var groundDistance=earthDistance(origin,ray);';
const cachedGround=`let geometry=${TERRAIN_CACHE_LOAD};\n  var groundDistance=geometry.x;`;
const directCondition='if(groundDistance>0.0 && groundAmount>0.001){';
const cachedCondition='if(groundDistance>=0.0 && groundAmount>0.001){';
const refinement='    groundDistance=landscapeDistance(origin,ray,groundDistance);\n';
const directColorCall='landscapeColor(origin+ray*groundDistance,groundDistance,sun,solarColor,ambientColor,sky,weather.x)';
const cachedColorCall='landscapeColorCached(origin+ray*groundDistance,groundDistance,sun,solarColor,ambientColor,sky,weather.x,geometry.yzw)';

/** Undo only the declared cache edits; everything else must remain original. */
function restoreDirect(source:string):string {
  for(const replacement of ['inspection:f32, ground:f32, terrainGeometry:texture_2d<f32>,',cachedGround,cachedCondition,cachedColorCall])exactlyOnce(source,replacement);
  expect(source).not.toContain(refinement);
  return source
    .replace('inspection:f32, ground:f32, terrainGeometry:texture_2d<f32>,','inspection:f32, ground:f32,')
    .replace(cachedGround,directGround)
    .replace(cachedCondition,directCondition)
    .replace(`${directCondition}\n`,`${directCondition}\n${refinement}`)
    .replace(cachedColorCall,directColorCall);
}
afterEach(()=>vi.clearAllMocks());

describe('terrain cache actual WGSL against frozen 10493',()=>{
  it('pins the original factory file and the untouched default direct FunctionNode',()=>{
    const originalFile=readFileSync(join(process.cwd(),'../baseline-source/src/cumulonimbus/cloudShader.ts'),'utf8');
    expect(hash(originalFile)).toBe('652c9514b7dfcee1456d15e9966087b3ff9c6a6ce9741970208cfca3750a248c');
    const fixedDefault='59523937da9df384aa57345fb99c758cee70bc83c5ada8d3084038dfa416f546';
    expect(hash(baseline().code)).toBe(fixedDefault);
    expect(hash(capture(()=>createCloudIntegrator()).code)).toBe(fixedDefault);
  });
  it('preserves all 24 direct sources and their six actual include libraries byte for byte',()=>{
    let variants=0;
    for(let mode=0;mode<=5;mode++)for(const narrow of [false,true])for(const r8 of [false,true]){
      const original=capture(()=>original10493(mode,narrow,r8));
      const direct=capture(()=>createCloudIntegrator(mode,narrow,r8));
      expect(original.libraries).toHaveLength(6);expect(direct.libraries).toHaveLength(6);
      expect(direct.code).toBe(original.code);expect(direct.libraries).toEqual(original.libraries);
      expect(direct.code).not.toContain('terrainGeometry');variants++;
    }
    expect(variants).toBe(24);
  });
  it('recovers every original source by undoing only the five declared cached-path edits',()=>{
    let variants=0;
    for(let mode=0;mode<=5;mode++)for(const narrow of [false,true])for(const r8 of [false,true]){
      const original=capture(()=>original10493(mode,narrow,r8));
      const cached=capture(()=>createTerrainCachedCloudIntegrator(mode,narrow,r8));
      expect(cached.code).not.toBe(original.code);expect(restoreDirect(cached.code)).toBe(original.code);
      expect(cached.libraries).toHaveLength(7);expect(cached.libraries.slice(0,6)).toEqual(original.libraries);
      expect(cached.nodes[6]).toBe(terrainCachedColor);expect(cached.libraries[6]).toBe(TERRAIN_CACHED_COLOR_WGSL);
      expect(cached.libraries.filter(code=>code.includes('fn landscapeColorCached('))).toHaveLength(1);
      variants++;
    }
    expect(variants).toBe(24);
  });
  it('keeps invalid diagnostic modes equivalent to mode zero in both factories',()=>{
    for(const factory of [createCloudIntegrator,createTerrainCachedCloudIntegrator])for(const narrow of [false,true])for(const r8 of [false,true]){
      const zero=capture(()=>factory(0,narrow,r8));
      for(const mode of [-1,6,.5,NaN])expect(capture(()=>factory(mode,narrow,r8))).toMatchObject({code:zero.code,libraries:zero.libraries});
    }
  });
  it('starts the actual geometry prepass with the exact original fragment ray operations',()=>{
    const original=baseline(),prepass=capture(()=>createTerrainGeometryPass());
    const ray=original.code.match(/^  let screen = [^\n]+\n  let ray = [^\n]+/m)?.[0];
    expect(ray).toBeDefined();expect(TERRAIN_VIEW_RAY).toBe(ray);
    const body=prepass.code.slice(prepass.code.indexOf('{\n')+2);
    expect(body.split('\n').slice(0,2).join('\n')).toBe(ray);
    expect(prepass.libraries).toEqual([original.libraries[3]]);
  });
  it('stores the original slope and height expressions in full f32 geometry without changing the solver library',()=>{
    const prepass=capture(()=>createTerrainGeometryPass());
    const slope=originalColorLine('let slope='),height=originalColorLine('let h=');
    expect(TERRAIN_SLOPE).toBe(slope);exactlyOnce(prepass.code,slope);exactlyOnce(prepass.code,height);
    expect(prepass.code).toContain('let distance=landscapeDistance(origin,ray,seaDistance);');
    expect(prepass.code).toContain('return vec4<f32>(distance,slope,h);');
    expect(prepass.code).not.toMatch(/\bf16\b/);
    // Miss and t=0 must remain distinct when the refined solver clamps to zero.
    expect(prepass.code).toContain('if(seaDistance<=0.0){return vec4<f32>(-1.0,0.0,0.0,0.0);}');
    expect(capture(()=>createTerrainCachedCloudIntegrator()).code).toContain(cachedCondition);
  });
  it('recovers the entire original landscapeColor from the actual extra include with only name/signature/height/slope restored',()=>{
    const cached=capture(()=>createTerrainCachedCloudIntegrator()).libraries[6];
    for(const fragment of ['fn landscapeColorCached(', 'haze:f32,geometry:vec3<f32>)->vec3<f32>{','let h=geometry.z;','let slope=geometry.xy;'])exactlyOnce(cached,fragment);
    const restored=cached
      .replace('fn landscapeColorCached(','fn landscapeColor(')
      .replace('haze:f32,geometry:vec3<f32>)->vec3<f32>{','haze:f32)->vec3<f32>{')
      .replace('let h=geometry.z;',originalColorLine('let h='))
      .replace('let slope=geometry.xy;',originalColorLine('let slope='));
    expect(restored).toBe(originalColor());
  });
  it('uses one identical integer textureLoad in the cached integrator and record-read helper, without filtered or half-float reads',()=>{
    const cached=capture(()=>createTerrainCachedCloudIntegrator()),record=capture(()=>createTerrainRecordReadPass());
    exactlyOnce(cached.code,TERRAIN_CACHE_LOAD);exactlyOnce(record.code,TERRAIN_CACHE_LOAD);
    expect(TERRAIN_CACHE_LOAD).toBe('textureLoad(terrainGeometry,vec2<i32>(floor(uv*resolution)),0)');
    expect(record.libraries).toEqual([]);
    expect(record.code).toContain(`return ${TERRAIN_CACHE_LOAD};`);
    expect(record.code).not.toMatch(/\b(?:sampler|f16|textureSample\w*|mix|interpolate)\b/);
    expect(TERRAIN_CACHE_LOAD).not.toMatch(/\b(?:sampler|f16|textureSample\w*|mix|interpolate)\b/);
  });
});

// External-only evidence export. It is never included in the app or enabled by default.
afterAll(()=>{
  const output=process.env.CLOUDIA_TERRAIN_TEMPLATE_WITNESS;
  if(!output)return;
  mkdirSync(dirname(output),{recursive:true});
  const rows=[];
  for(let mode=0;mode<=5;mode++)for(const narrow of [false,true])for(const r8 of [false,true]){
    const baselineSource=capture(()=>original10493(mode,narrow,r8));
    const direct=capture(()=>createCloudIntegrator(mode,narrow,r8));
    const cached=capture(()=>createTerrainCachedCloudIntegrator(mode,narrow,r8));
    rows.push({mode,narrow,r8,baselineSha256:hash(baselineSource.code),directSha256:hash(direct.code),cachedSha256:hash(cached.code),restoredCachedSha256:hash(restoreDirect(cached.code)),baselineLibrarySha256:baselineSource.libraries.map(hash),directLibrarySha256:direct.libraries.map(hash),cachedLibrarySha256:cached.libraries.map(hash)});
    if(mode===0)for(const [kind,value] of [['baseline',baselineSource],['direct',direct],['cached',cached]] as const){
      const folder=join(dirname(output),'emitted');mkdirSync(folder,{recursive:true});
      writeFileSync(join(folder,`${kind}-n${+narrow}-r${+r8}.wgsl.gz`),gzipSync(value.code));
    }
  }
  const prepass=capture(()=>createTerrainGeometryPass()),reader=capture(()=>createTerrainRecordReadPass());
  writeFileSync(output,JSON.stringify({baselineCommit:'10493afa7f6d90389c39e17b2cad79397dfdac01',scope:'CPU actual Three FunctionNode source/includes; not driver WGSL, GPU compilation or pixels',rows,prepass:{sha256:hash(prepass.code),libraries:prepass.libraries.map(hash)},recordReader:{sha256:hash(reader.code),libraries:reader.libraries.map(hash)},cachedColorSha256:hash(TERRAIN_CACHED_COLOR_WGSL)},null,2)+'\n');
});
