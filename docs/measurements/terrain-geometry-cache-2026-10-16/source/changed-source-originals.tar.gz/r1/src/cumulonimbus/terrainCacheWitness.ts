export const TERRAIN_WITNESS_SENTINEL=-987654.25;
/** Chosen before capture: corners, centre, then quarter/three-quarter samples. */
export const SELECTED_TERRAIN_PIXEL_COORDINATES=Object.freeze([
  [0,0],[1,0],[0,1],[1,1],[.5,.5],[.25,.25],[.75,.25],[.25,.75],[.75,.75],
] as const);

export interface TerrainWitnessPixel {readonly x:number;readonly y:number;readonly pixelIndex:number}
type WitnessFloat=number|'NaN'|'+Infinity'|'-Infinity'|'-0';
interface RawChannel {readonly uintHex:string;readonly float:WitnessFloat}
interface TerrainVariantStats {
  readonly sha256:string;readonly finiteChannels:number;readonly nanChannels:number;readonly infiniteChannels:number;
  readonly sentinelChannels:number;readonly sentinelPixels:number;
  readonly geometry:{readonly hitPixels:number;readonly missPixels:number;readonly tZeroPixels:number;readonly invalidDistancePixels:number}|null;
}
interface TerrainWitnessDiff extends TerrainWitnessPixel {
  readonly index:number;readonly channel:number;readonly reference:RawChannel;readonly candidate:RawChannel;
}
interface TerrainWitnessRecord extends TerrainWitnessPixel {
  readonly reference:readonly RawChannel[];readonly candidate:readonly RawChannel[];
}
export interface TerrainBufferComparison {
  readonly scope:string;readonly width:number;readonly height:number;readonly channelsPerPixel:4;
  readonly pixelCount:number;readonly channelCount:number;readonly byteLength:number;
  readonly bitEqual:boolean;readonly status:'pass'|'fail';
  readonly reference:TerrainVariantStats;readonly candidate:TerrainVariantStats;
  readonly mismatchedChannels:number;readonly mismatchedPixels:number;
  readonly firstDiffs:readonly TerrainWitnessDiff[];
  readonly selectedCoordinates:typeof SELECTED_TERRAIN_PIXEL_COORDINATES;
  readonly selectedRecords:readonly TerrainWitnessRecord[];
}

function dimensions(width:number,height:number):number {
  const pixels=width*height;
  if(!Number.isSafeInteger(width)||width<=0||!Number.isSafeInteger(height)||height<=0||!Number.isSafeInteger(pixels*4))throw new RangeError('Terrain witness dimensions must be positive safe integers');
  return pixels;
}

export function selectedTerrainPixels(width:number,height:number):TerrainWitnessPixel[] {
  dimensions(width,height);
  const seen=new Set<number>(),selected:TerrainWitnessPixel[]=[];
  for(const [u,v] of SELECTED_TERRAIN_PIXEL_COORDINATES){
    const x=Math.floor(u*(width-1)),y=Math.floor(v*(height-1)),pixelIndex=y*width+x;
    if(!seen.has(pixelIndex)){seen.add(pixelIndex);selected.push({x,y,pixelIndex});}
  }
  return selected;
}

function snapshot(input:Float32Array){
  // Freeze the same bytes for both comparison and asynchronous hashing. Copy
  // bytes, not float values, so NaN payloads and signed zero remain intact.
  const bytes=new Uint8Array(input.byteLength);
  bytes.set(new Uint8Array(input.buffer,input.byteOffset,input.byteLength));
  return {bytes,bits:new Uint32Array(bytes.buffer),values:new Float32Array(bytes.buffer)};
}
function raw(bits:number,value:number):RawChannel {
  const float=Number.isNaN(value)?'NaN':value===Infinity?'+Infinity':value===-Infinity?'-Infinity':Object.is(value,-0)?'-0':value;
  return {uintHex:`0x${bits.toString(16).padStart(8,'0')}`,float};
}
async function stats(buffer:ReturnType<typeof snapshot>,geometry:boolean):Promise<TerrainVariantStats> {
  let finiteChannels=0,nanChannels=0,infiniteChannels=0,sentinelChannels=0,sentinelPixels=0,lastSentinelPixel=-1;
  let hitPixels=0,missPixels=0,tZeroPixels=0,invalidDistancePixels=0;
  for(let index=0;index<buffer.values.length;index++){
    const value=buffer.values[index];
    if(Number.isFinite(value))finiteChannels++;
    else if(Number.isNaN(value))nanChannels++;
    else infiniteChannels++;
    if(value===TERRAIN_WITNESS_SENTINEL){
      sentinelChannels++;const pixel=Math.floor(index/4);
      if(pixel!==lastSentinelPixel){sentinelPixels++;lastSentinelPixel=pixel;}
    }
    if(geometry&&index%4===0){
      if(Number.isFinite(value)&&value>=0){hitPixels++;if(value===0)tZeroPixels++;}
      else if(value===-1)missPixels++;
      else invalidDistancePixels++;
    }
  }
  const digest=new Uint8Array(await crypto.subtle.digest('SHA-256',buffer.bytes));
  const sha256=Array.from(digest,value=>value.toString(16).padStart(2,'0')).join('');
  return {sha256,finiteChannels,nanChannels,infiniteChannels,sentinelChannels,sentinelPixels,geometry:geometry?{hitPixels,missPixels,tZeroPixels,invalidDistancePixels}:null};
}

/** Compares every RGBA f32 bit. Selected records are an inspection aid only.
 * Scope "geometry" additionally classifies component 0 as t: -1 miss, >=0 hit.
 * Equality alone cannot pass a buffer containing NaN, infinity or sentinel.
 */
export async function compareTerrainBuffers(reference:Float32Array,candidate:Float32Array,width:number,height:number,scope:string):Promise<TerrainBufferComparison> {
  const pixelCount=dimensions(width,height),channelCount=pixelCount*4;
  if(reference.length!==channelCount||candidate.length!==channelCount)throw new RangeError('Terrain witness buffer length must equal 4 * width * height');
  if(!scope.trim())throw new RangeError('Terrain witness scope must be named');
  const a=snapshot(reference),b=snapshot(candidate),firstDiffs:TerrainWitnessDiff[]=[];
  let mismatchedChannels=0,mismatchedPixels=0,lastMismatchPixel=-1;
  for(let index=0;index<channelCount;index++){
    if(a.bits[index]===b.bits[index])continue;
    mismatchedChannels++;const pixelIndex=Math.floor(index/4);
    if(pixelIndex!==lastMismatchPixel){mismatchedPixels++;lastMismatchPixel=pixelIndex;}
    if(firstDiffs.length<8)firstDiffs.push({index,pixelIndex,x:pixelIndex%width,y:Math.floor(pixelIndex/width),channel:index%4,reference:raw(a.bits[index],a.values[index]),candidate:raw(b.bits[index],b.values[index])});
  }
  const selectedRecords=selectedTerrainPixels(width,height).map(pixel=>{
    const record=(buffer:ReturnType<typeof snapshot>)=>Array.from({length:4},(_,channel)=>{
      const index=pixel.pixelIndex*4+channel;return raw(buffer.bits[index],buffer.values[index]);
    });
    return {...pixel,reference:record(a),candidate:record(b)};
  });
  const [referenceStats,candidateStats]=await Promise.all([stats(a,scope==='geometry'),stats(b,scope==='geometry')]);
  const invalid=(variant:TerrainVariantStats)=>variant.nanChannels+variant.infiniteChannels+variant.sentinelChannels+(variant.geometry?.invalidDistancePixels??0)>0;
  const bitEqual=mismatchedChannels===0;
  return {scope,width,height,channelsPerPixel:4,pixelCount,channelCount,byteLength:reference.byteLength,bitEqual,status:bitEqual&&!invalid(referenceStats)&&!invalid(candidateStats)?'pass':'fail',reference:referenceStats,candidate:candidateStats,mismatchedChannels,mismatchedPixels,firstDiffs,selectedCoordinates:SELECTED_TERRAIN_PIXEL_COORDINATES,selectedRecords};
}
