import {afterEach,describe,expect,it,vi} from 'vitest';
import {CumulonimbusApp} from './CumulonimbusApp';
const apps:CumulonimbusApp[]=[];
afterEach(()=>{for(const app of apps.splice(0))app.destroy();document.body.innerHTML='';history.replaceState(null,'','/');vi.restoreAllMocks();});
function fixture(search:string){
  history.replaceState(null,'','/'+search);const root=document.createElement('div');document.body.append(root);
  const app=new CumulonimbusApp(root);apps.push(app);
  const engine={action:vi.fn(),destroy:vi.fn(async()=>{})};Reflect.set(app,'engine',engine);
  return {app,root,engine};
}
describe('external terrain cache witness UI',()=>{
  it('exposes no witness in the default UI and submits nothing until the opt-in button is pressed',()=>{
    const direct=fixture('?profile=1');expect(direct.root.querySelector('[data-action="terrain-cache-witness"]')).toBeNull();
    const trial=fixture('?profile=1&terrainCache=1');
    expect(trial.engine.action).not.toHaveBeenCalled();
    const button=trial.root.querySelector<HTMLButtonElement>('[data-action="terrain-cache-witness"]')!;
    expect(button.closest('[role="tabpanel"]')?.id).toBe('panel-measure');button.click();
    expect(trial.engine.action).toHaveBeenCalledExactlyOnceWith('terrain-cache-witness');
  });
  it('keeps the compact witness result separate from the benchmark JSON and export state',()=>{
    const {app,root}=fixture('?profile=1&terrainCache=1');
    const receive=Reflect.get(app,'onEvent') as (event:unknown)=>void;
    const benchmark={submissionFps:19,scope:'benchmark'};receive({type:'report',report:benchmark});
    const witness={kind:'terrain-cache-witness',status:'running'};receive({type:'report',report:witness});
    expect(JSON.parse(root.querySelector('[data-testid="benchmark-json"]')!.textContent!)).toEqual(benchmark);
    expect(JSON.parse(root.querySelector('[data-testid="terrain-cache-witness-json"]')!.textContent!)).toEqual(witness);
    expect(Reflect.get(app,'report')).toEqual(benchmark);
  });
});
