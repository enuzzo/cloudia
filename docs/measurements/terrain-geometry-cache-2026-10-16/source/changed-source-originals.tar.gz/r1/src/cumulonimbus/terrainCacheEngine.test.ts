import {afterEach,beforeEach,describe,expect,it,vi} from 'vitest';
import type {Vector3} from 'three/webgpu';
import {GPUSceneEngine} from './GPUSceneEngine';
import type {TerrainCacheState} from './terrainCacheState';

const engines:GPUSceneEngine[]=[];
beforeEach(()=>vi.stubGlobal('cancelAnimationFrame',vi.fn()));
afterEach(async()=>{
  try{await Promise.all(engines.splice(0).map(engine=>engine.destroy()));}
  finally{vi.restoreAllMocks();vi.unstubAllGlobals();}
});
function invoke<T>(engine:GPUSceneEngine,name:string,...args:unknown[]):T {
  return (Reflect.get(engine,name) as (...values:unknown[])=>T).apply(engine,args);
}
function uniform<T>(engine:GPUSceneEngine,name:string):{value:T} {return Reflect.get(engine,name) as {value:T};}
async function flush(){for(let turn=0;turn<8;turn++)await Promise.resolve();}

function fixture(thread:'main'|'worker'='main',enabled=true){
  const emit=vi.fn(),engine=new GPUSceneEngine({canvas:document.createElement('canvas'),search:enabled?'?terrainCache=1':'',viewport:{width:17,height:2,dpr:1},visible:true,thread,emit});
  engines.push(engine);
  const calls:string[]=[],directMaterial={name:'direct',dispose:vi.fn()},cachedMaterial={name:'cached',dispose:vi.fn()},prepassMaterial={dispose:vi.fn()};
  const previousTarget={name:'previous'},terrainTarget={name:'terrain',width:17,height:2,dispose:vi.fn()};
  let currentTarget:object|null=previousTarget;
  const targetName=(target:object|null)=>target===terrainTarget?'terrain':target===previousTarget?'previous':'screen';
  const renderer={
    getRenderTarget:vi.fn(()=>currentTarget),
    setRenderTarget:vi.fn((target:object|null)=>{currentTarget=target;calls.push(`target:${targetName(target)}`);}),
    readRenderTargetPixelsAsync:vi.fn(async():Promise<ArrayBufferView>=>new Float32Array(0)),
    dispose:vi.fn(()=>calls.push('renderer:dispose')),
  };
  const quad={material:directMaterial,render:vi.fn<()=>number>()};
  quad.render.mockImplementation(()=>calls.push(`cloud:${quad.material.name}@${targetName(currentTarget)}`));
  const terrainQuad={render:vi.fn(()=>{calls.push(`prepass@${targetName(currentTarget)}`);})};
  const device={destroy:vi.fn(()=>calls.push('device:destroy'))};
  for(const [key,value] of Object.entries({renderer,device,quad,material:directMaterial,terrainTarget,terrainMaterial:prepassMaterial,terrainQuad,terrainCachedMaterial:cachedMaterial,internalWidth:17,internalHeight:2}))Reflect.set(engine,key,value);
  const state=Reflect.get(engine,'terrainCacheState') as TerrainCacheState;
  const render=()=>invoke<void>(engine,'renderTerrainAwareFrame');
  return {engine,emit,calls,renderer,quad,terrainQuad,terrainTarget,previousTarget,directMaterial,cachedMaterial,prepassMaterial,device,state,render};
}

describe.each(['main','worker'] as const)('terrain cache integration on %s render host',thread=>{
  it('does not start a benchmark while the explicit witness owns the render loop',()=>{
    const f=fixture(thread);Reflect.set(f.engine,'ready',true);Reflect.set(f.engine,'terrainWitnessBusy',true);
    invoke<void>(f.engine,'startBenchmark',30000);
    expect(Reflect.get(f.engine,'measurement')).toBeNull();expect(f.calls).toEqual([]);
  });
  it('uses direct on the cold frame, then submits prepass and cached draw in order and reuses warm geometry',()=>{
    const f=fixture(thread);
    f.render();expect(f.calls).toEqual(['cloud:direct@previous']);
    expect(f.terrainQuad.render).not.toHaveBeenCalled();expect(f.state.snapshot().phase).toBe('settling');
    f.calls.length=0;f.render();
    expect(f.calls).toEqual(['target:terrain','prepass@terrain','target:previous','cloud:cached@previous']);
    expect(f.renderer.getRenderTarget()).toBe(f.previousTarget);expect(f.state.snapshot().phase).toBe('valid');
    f.calls.length=0;f.render();f.render();
    expect(f.calls).toEqual(['cloud:cached@previous','cloud:cached@previous']);
    expect(f.terrainQuad.render).toHaveBeenCalledTimes(1);
  });
  it.each(['origin','inspection'] as const)('renders directly on an actual %s change before rebuilding geometry',field=>{
    const f=fixture(thread);f.render();f.render();f.calls.length=0;
    if(field==='origin')uniform<Vector3>(f.engine,'origin').value.x+=1;
    else uniform<number>(f.engine,'inspection').value=.5;
    f.render();expect(f.calls).toEqual(['cloud:direct@previous']);
    expect(f.quad.material).toBe(f.directMaterial);expect(f.terrainQuad.render).toHaveBeenCalledTimes(1);
    f.calls.length=0;f.render();
    expect(f.calls).toEqual(['target:terrain','prepass@terrain','target:previous','cloud:cached@previous']);
    expect(f.terrainQuad.render).toHaveBeenCalledTimes(2);
  });
  it('keeps geometry warm when sun, lighting and weather uniforms change',()=>{
    const f=fixture(thread);f.render();f.render();f.calls.length=0;
    uniform<Vector3>(f.engine,'sun').value.set(.2,.4,-.7);
    uniform<Vector3>(f.engine,'solarColor').value.set(.9,.6,.3);
    uniform<Vector3>(f.engine,'ambientColor').value.set(.1,.2,.4);
    uniform<Vector3>(f.engine,'weather').value.set(2,.5,.8);
    f.render();expect(f.calls).toEqual(['cloud:cached@previous']);
    expect(f.terrainQuad.render).toHaveBeenCalledTimes(1);
  });
  it('renders directly with ground off and starts cold when ground returns',()=>{
    const f=fixture(thread);f.render();f.render();f.calls.length=0;
    uniform<number>(f.engine,'ground').value=0;f.render();f.render();
    expect(f.calls).toEqual(['cloud:direct@previous','cloud:direct@previous']);
    expect(f.terrainQuad.render).toHaveBeenCalledTimes(1);
    f.calls.length=0;uniform<number>(f.engine,'ground').value=1;f.render();
    expect(f.calls).toEqual(['cloud:direct@previous']);
    f.calls.length=0;f.render();
    expect(f.calls).toEqual(['target:terrain','prepass@terrain','target:previous','cloud:cached@previous']);
    expect(f.terrainQuad.render).toHaveBeenCalledTimes(2);
  });
  it('restores the prior target after a synchronous prepass failure and stays direct without a rebuild loop',()=>{
    const f=fixture(thread);f.render();f.calls.length=0;
    f.terrainQuad.render.mockImplementationOnce(()=>{f.calls.push('prepass:failed@terrain');throw new Error('synthetic prepass failure');});
    f.render();
    expect(f.calls).toEqual(['target:terrain','prepass:failed@terrain','target:previous','cloud:direct@previous']);
    expect(f.renderer.getRenderTarget()).toBe(f.previousTarget);expect(f.state.snapshot().phase).toBe('failed');
    expect(f.emit).toHaveBeenCalledWith(expect.objectContaining({type:'text',field:'status',text:expect.stringContaining('synthetic prepass failure')}));
    f.calls.length=0;for(let frame=0;frame<4;frame++)f.render();
    expect(f.calls).toEqual(Array(4).fill('cloud:direct@previous'));
    expect(f.terrainQuad.render).toHaveBeenCalledTimes(1);
    expect(f.state.snapshot()).toMatchObject({builds:1,hits:0,failures:1});
  });
  it('keeps the direct path when the opt-in flag is absent',()=>{
    const f=fixture(thread,false);f.render();f.render();f.render();
    expect(f.calls).toEqual(Array(3).fill('cloud:direct@previous'));
    expect(f.terrainQuad.render).not.toHaveBeenCalled();expect(f.renderer.setRenderTarget).not.toHaveBeenCalled();
  });
});

describe('terrain RGBA32F readback layout',()=>{
  it('strips padding aligned to 256 bytes from a 17-pixel, two-row readback',async()=>{
    const f=fixture(),channels=17*4,stride=128;
    // Row bytes = 272; the next 256-byte boundary is 512 bytes / 128 floats.
    // Three returns no trailing padding after the final row.
    const padded=new Float32Array(stride+channels).fill(-987654.25),expected=new Float32Array(channels*2);
    for(let x=0;x<channels;x++){padded[x]=x+.25;padded[stride+x]=2000+x+.5;expected[x]=x+.25;expected[channels+x]=2000+x+.5;}
    f.renderer.readRenderTargetPixelsAsync.mockResolvedValueOnce(padded);
    const packed=await invoke<Promise<Float32Array>>(f.engine,'readTerrainTarget',f.terrainTarget);
    expect(f.renderer.readRenderTargetPixelsAsync).toHaveBeenCalledWith(f.terrainTarget,0,0,17,2);
    expect(packed).toEqual(expected);expect(packed).toHaveLength(136);expect(packed).not.toBe(padded);
  });
  it('accepts an already tightly packed Float32Array unchanged',async()=>{
    const f=fixture(),packed=new Float32Array(17*2*4);
    f.renderer.readRenderTargetPixelsAsync.mockResolvedValueOnce(packed);
    expect(await invoke<Promise<Float32Array>>(f.engine,'readTerrainTarget',f.terrainTarget)).toBe(packed);
  });
  it('rejects a different element type and an invalid padded length',async()=>{
    const f=fixture();
    f.renderer.readRenderTargetPixelsAsync.mockResolvedValueOnce(new Uint8Array(17*2*4));
    await expect(invoke<Promise<Float32Array>>(f.engine,'readTerrainTarget',f.terrainTarget)).rejects.toThrow('Readback cache non Float32Array');
    f.renderer.readRenderTargetPixelsAsync.mockResolvedValueOnce(new Float32Array(197));
    await expect(invoke<Promise<Float32Array>>(f.engine,'readTerrainTarget',f.terrainTarget)).rejects.toThrow('Readback cache con lunghezza inattesa');
  });
});

describe('terrain cache GPU resource lifecycle',()=>{
  it('waits for the witness before releasing resources and disposes each resource exactly once across repeated destroy calls',async()=>{
    const f=fixture();f.render();f.render();f.calls.length=0;
    let finishWitness!:()=>void;
    const pendingWitness=new Promise<void>(resolve=>{finishWitness=resolve;}).then(()=>{f.calls.push('witness:settled');});
    Reflect.set(f.engine,'terrainWitnessPromise',pendingWitness);
    for(const name of ['benchmarkCompletion','initialization','timestampPromise','queuePromise'])Reflect.set(f.engine,name,Promise.resolve());
    (Reflect.get(f.engine,'frameCompletions') as Set<Promise<void>>).add(Promise.resolve());
    const stateDispose=vi.spyOn(f.state,'dispose');
    const first=f.engine.destroy(),second=f.engine.destroy();
    try{
      expect(second).toBe(first);expect(Reflect.get(f.engine,'destroyed')).toBe(true);
      await flush();
      for(const resource of [f.terrainTarget,f.prepassMaterial,f.cachedMaterial,f.directMaterial,f.renderer])expect(resource.dispose).not.toHaveBeenCalled();
      expect(f.device.destroy).not.toHaveBeenCalled();expect(stateDispose).not.toHaveBeenCalled();
    }finally{finishWitness();await first;}
    await f.engine.destroy();
    for(const resource of [f.terrainTarget,f.prepassMaterial,f.cachedMaterial,f.directMaterial,f.renderer])expect(resource.dispose).toHaveBeenCalledTimes(1);
    expect(f.device.destroy).toHaveBeenCalledTimes(1);expect(stateDispose).toHaveBeenCalledTimes(1);
    expect(f.state.snapshot().phase).toBe('disposed');expect(Reflect.get(f.engine,'terrainTarget')).toBeNull();
    expect(f.calls).toEqual(['witness:settled','renderer:dispose','device:destroy']);
  });
});
