import {describe,expect,it} from 'vitest';
import {TerrainCacheState,terrainCacheKey} from './terrainCacheState';
import type {TerrainCacheView} from './terrainCacheState';

function view(overrides:Partial<TerrainCacheView>={}):TerrainCacheView {
  return {origin:{x:0,y:2,z:16},forward:{x:0,y:0,z:-1},right:{x:1,y:0,z:0},up:{x:0,y:1,z:0},aspect:16/9,tanFov:.2867,inspection:0,width:2560,height:1440,ground:true,...overrides};
}
function begin(state:TerrainCacheState,key='A'):number {
  expect(state.update(key)).toBe('direct');expect(state.update(key)).toBe('build');
  return state.generation;
}

describe('terrain geometry raster key',()=>{
  it('uses the clamped shader origin and every camera basis/projection/inspection uniform',()=>{
    const original=view(),key=terrainCacheKey(original);
    for(const field of ['origin','forward','right','up'] as const)for(const component of ['x','y','z'] as const){
      const changed={...original[field],[component]:original[field][component]+.01};
      expect(terrainCacheKey(view({[field]:changed}))).not.toBe(key);
    }
    for(const field of ['aspect','tanFov','inspection'] as const)expect(terrainCacheKey(view({[field]:original[field]+.01}))).not.toBe(key);
    // The controller must receive the post-clearance origin, not the UI camera.
    expect(terrainCacheKey(view({origin:{x:0,y:2.001,z:16}}))).not.toBe(key);
  });
  it('compares exact f32 bits, retaining signed zero but sharing equivalent uploads',()=>{
    expect(terrainCacheKey(view({inspection:1+2**-25}))).toBe(terrainCacheKey(view({inspection:1})));
    expect(terrainCacheKey(view({inspection:1+2**-23}))).not.toBe(terrainCacheKey(view({inspection:1})));
    expect(terrainCacheKey(view({origin:{x:-0,y:2,z:16}}))).not.toBe(terrainCacheKey(view()));
  });
  it('keys exact raster dimensions and geometry version, and disables caching with ground off',()=>{
    const key=terrainCacheKey(view());
    expect(terrainCacheKey(view({width:2559}))).not.toBe(key);
    expect(terrainCacheKey(view({height:1439}))).not.toBe(key);
    expect(terrainCacheKey(view(),2)).not.toBe(key);
    expect(terrainCacheKey(view({ground:false}))).toBeNull();
    // Width is not f32-rounded, even above f32's consecutive-integer range.
    expect(terrainCacheKey(view({width:16777216}))).not.toBe(terrainCacheKey(view({width:16777217})));
  });
  it.each([NaN,Infinity,-Infinity,Number.MAX_VALUE])('rejects a non-finite f32 uniform: %s',value=>{
    expect(()=>terrainCacheKey(view({inspection:value}))).toThrow(RangeError);
    expect(()=>terrainCacheKey(view({origin:{x:value,y:2,z:16}}))).toThrow(RangeError);
  });
  it.each([NaN,Infinity,-Infinity,0,-1,1.5,2**32])('rejects invalid raster dimensions even with ground off: %s',value=>{
    expect(()=>terrainCacheKey(view({width:value}))).toThrow(RangeError);
    expect(()=>terrainCacheKey(view({height:value,ground:false}))).toThrow(RangeError);
  });
  it.each([NaN,Infinity,-1,1.5,2**32])('rejects invalid geometry versions: %s',value=>{
    expect(()=>terrainCacheKey(view(),value)).toThrow(RangeError);
  });
});

describe('terrain geometry cache publication',()=>{
  it('renders directly, requests one build, and waits for explicit submission before caching',()=>{
    const state=new TerrainCacheState(),generation=begin(state);
    expect(state.update('A')).toBe('direct');expect(state.update('A')).toBe('direct');
    expect(state.commit('A',generation)).toBe(true);
    expect(state.update('A')).toBe('cached');expect(state.update('A')).toBe('cached');
    expect(state.commit('A',generation)).toBe(false);
    expect(state.snapshot()).toEqual({key:'A',generation,phase:'valid',builds:1,hits:2,direct:3,invalidations:0,failures:0});
  });
  it('never commits an unbuilt or mismatching key/generation',()=>{
    const state=new TerrainCacheState();
    expect(state.commit('A',state.generation)).toBe(false);
    expect(state.update('A')).toBe('direct');expect(state.commit('A',state.generation)).toBe(false);
    expect(state.update('A')).toBe('build');
    expect(state.commit('B',state.generation)).toBe(false);
    expect(state.commit('A',state.generation-1)).toBe(false);
    expect(state.commit('A',state.generation)).toBe(true);
  });
  it('invalidates valid geometry immediately while the camera changes',()=>{
    const state=new TerrainCacheState(),first=begin(state);
    expect(state.commit('A',first)).toBe(true);expect(state.update('A')).toBe('cached');
    expect(state.update('B')).toBe('direct');expect(state.update('C')).toBe('direct');
    expect(state.commit('A',first)).toBe(false);expect(state.update('C')).toBe('build');
    expect(state.commit('C',state.generation)).toBe(true);expect(state.update('C')).toBe('cached');
    expect(state.snapshot().invalidations).toBe(2);
  });
  it('rejects pending commits after a key changes and reverses to its original value',()=>{
    const state=new TerrainCacheState(),old=begin(state);
    expect(state.update('B')).toBe('direct');expect(state.update('A')).toBe('direct');
    expect(state.update('A')).toBe('build');const current=state.generation;
    expect(current).toBeGreaterThan(old);expect(state.commit('A',old)).toBe(false);
    expect(state.fail('A',old)).toBe(false);expect(state.commit('A',current)).toBe(true);
  });
  it('stays direct after a failed build, allowing an explicit retry without accepting old work',()=>{
    const state=new TerrainCacheState(),failed=begin(state);
    expect(state.fail('A',failed)).toBe(true);
    for(let frame=0;frame<8;frame++)expect(state.update('A')).toBe('direct');
    expect(state.commit('A',failed)).toBe(false);expect(state.snapshot().builds).toBe(1);
    expect(state.retry()).toBe(true);expect(state.update('A')).toBe('build');
    expect(state.commit('A',failed)).toBe(false);
    expect(state.commit('A',state.generation)).toBe(true);expect(state.update('A')).toBe('cached');
    expect(state.retry()).toBe(false);expect(state.snapshot().failures).toBe(1);
  });
  it('permits a fresh build after a failed key changes',()=>{
    const state=new TerrainCacheState(),failed=begin(state);
    expect(state.fail('B',failed)).toBe(false);expect(state.fail('A',failed+1)).toBe(false);
    expect(state.fail('A',failed)).toBe(true);
    expect(state.update('B')).toBe('direct');expect(state.update('B')).toBe('build');
    expect(state.commit('B',state.generation)).toBe(true);
  });
  it.each(['invalidate','release'] as const)('rejects a pre-%s commit, even when the same dimensions return',operation=>{
    const state=new TerrainCacheState(),old=begin(state);
    state[operation]();expect(state.update('A')).toBe('direct');expect(state.update('A')).toBe('build');
    expect(state.commit('A',old)).toBe(false);expect(state.commit('A',state.generation)).toBe(true);
  });
  it('stays direct with ground disabled and requires a new stable frame when it returns',()=>{
    const state=new TerrainCacheState(),old=begin(state);
    expect(state.update(null)).toBe('direct');expect(state.update(null)).toBe('direct');
    expect(state.commit('A',old)).toBe(false);expect(state.retry()).toBe(false);
    expect(state.update('A')).toBe('direct');expect(state.update('A')).toBe('build');
  });
  it('disposes permanently and cannot publish pending or later work',()=>{
    const state=new TerrainCacheState(),old=begin(state);state.dispose();
    const generation=state.generation;
    expect(state.commit('A',old)).toBe(false);expect(state.fail('A',old)).toBe(false);
    expect(state.update('A')).toBe('direct');expect(state.update('A')).toBe('direct');
    expect(state.commit('A',generation)).toBe(false);expect(state.retry()).toBe(false);
    state.release();state.invalidate();state.dispose();expect(state.generation).toBe(generation);
    expect(state.snapshot().phase).toBe('disposed');
  });
});
