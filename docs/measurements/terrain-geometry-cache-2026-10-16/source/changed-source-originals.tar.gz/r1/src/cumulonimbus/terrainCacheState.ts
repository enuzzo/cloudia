interface CacheVector {readonly x:number;readonly y:number;readonly z:number}

/** Pass the actual shader uniforms, including the already clamped origin. */
export interface TerrainCacheView {
  readonly origin:CacheVector;readonly forward:CacheVector;readonly right:CacheVector;readonly up:CacheVector;
  readonly aspect:number;readonly tanFov:number;readonly inspection:number;
  readonly width:number;readonly height:number;readonly ground:boolean;
}

export const TERRAIN_GEOMETRY_VERSION=1;
const word=new DataView(new ArrayBuffer(4));
function f32Bits(value:number):string {
  const rounded=Math.fround(value);
  if(!Number.isFinite(value)||!Number.isFinite(rounded))throw new RangeError('Terrain cache uniforms must be finite f32 values');
  word.setFloat32(0,rounded,true);
  return word.getUint32(0,true).toString(16).padStart(8,'0');
}
function uint(value:number,name:string,minimum:number):string {
  if(!Number.isSafeInteger(value)||value<minimum||value>0xffffffff)throw new RangeError(`Terrain cache ${name} must be an integer in [${minimum}, 4294967295]`);
  return String(value);
}

/** The key compares uploaded f32 bits, not an epsilon or camera UI values.
 * Dimensions are exact raster integers; disabled terrain never uses a cache.
 * Geometry version is independent from a controller's submission generation.
 */
export function terrainCacheKey(view:TerrainCacheView,geometryVersion=TERRAIN_GEOMETRY_VERSION):string|null {
  const dimensions=[uint(view.width,'width',1),uint(view.height,'height',1)];
  const version=uint(geometryVersion,'geometry version',0);
  const values=[view.origin,view.forward,view.right,view.up].flatMap(v=>[v.x,v.y,v.z]);
  values.push(view.aspect,view.tanFov,view.inspection);
  const bits=values.map(f32Bits);
  return view.ground?`terrain-rgba32f:${version}:1:${dimensions.join('x')}:${bits.join(':')}`:null;
}

export type TerrainCacheDecision='direct'|'build'|'cached';
type CachePhase='empty'|'settling'|'building'|'valid'|'failed'|'disposed';
export interface TerrainCacheSnapshot {
  readonly key:string|null;readonly generation:number;readonly phase:CachePhase;
  readonly builds:number;readonly hits:number;readonly direct:number;readonly invalidations:number;readonly failures:number;
}

/** One controller per render host. It owns no GPU resources.
 * A new key renders directly once, then requests one build on the next frame.
 * Publish only after submitting the matching prepass. Pending and failed builds
 * render directly; failure needs a different key or an explicit retry.
 */
export class TerrainCacheState {
  private key:string|null=null;
  private phase:CachePhase='empty';
  private serial=0;
  private builds=0;private hits=0;private direct=0;private invalidations=0;private failures=0;

  get generation():number {return this.serial;}

  update(key:string|null):TerrainCacheDecision {
    if(this.phase==='disposed'){this.direct++;return 'direct';}
    if(key!==this.key){
      if(this.key!==null)this.invalidations++;
      this.serial++;this.key=key;this.phase=key===null?'empty':'settling';
      this.direct++;return 'direct';
    }
    if(this.phase==='valid'){this.hits++;return 'cached';}
    if(this.phase==='settling'){this.phase='building';this.builds++;return 'build';}
    this.direct++;return 'direct';
  }

  commit(key:string,generation:number):boolean {
    if(this.phase!=='building'||key!==this.key||generation!==this.serial)return false;
    this.phase='valid';return true;
  }

  fail(key:string,generation:number):boolean {
    if(this.phase!=='building'||key!==this.key||generation!==this.serial)return false;
    this.phase='failed';this.failures++;return true;
  }

  retry():boolean {
    if(this.phase!=='failed')return false;
    this.serial++;this.phase='settling';return true;
  }

  /** Call when releasing/resizing resources or replacing the device. */
  invalidate():void {
    if(this.phase==='disposed')return;
    this.serial++;this.invalidations++;this.key=null;this.phase='empty';
  }

  release():void {this.invalidate();}

  /** Terminal: even later update/commit calls cannot publish a cache. */
  dispose():void {
    if(this.phase==='disposed')return;
    this.invalidate();this.phase='disposed';
  }

  snapshot():TerrainCacheSnapshot {
    return {key:this.key,generation:this.serial,phase:this.phase,builds:this.builds,hits:this.hits,direct:this.direct,invalidations:this.invalidations,failures:this.failures};
  }
}
