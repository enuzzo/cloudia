import {wgslFn,wgsl} from 'three/tsl';
import {LANDSCAPE_WGSL} from './landscape';

// Keep the exact source operations of the original fragment ray and slope.
export const TERRAIN_VIEW_RAY=`  let screen = vec2<f32>(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0 - 0.16*(1.0-inspection));
  let ray = normalize(forward + right * screen.x * aspect * tanFov + up * screen.y * tanFov);`;
export const TERRAIN_SLOPE='let slope=vec2<f32>(terrainHeight(p+vec2<f32>(.08,0))-terrainHeight(p-vec2<f32>(.08,0)),terrainHeight(p+vec2<f32>(0,.08))-terrainHeight(p-vec2<f32>(0,.08)))/.16;';
const landscape=wgsl(LANDSCAPE_WGSL);
const colorOriginal=LANDSCAPE_WGSL.slice(LANDSCAPE_WGSL.indexOf('fn landscapeColor('));
export const TERRAIN_CACHED_COLOR_WGSL=colorOriginal
  .replace('fn landscapeColor(', 'fn landscapeColorCached(')
  .replace('haze:f32)->vec3<f32>{','haze:f32,geometry:vec3<f32>)->vec3<f32>{')
  .replace('let h=terrainHeight(p);','let h=geometry.z;')
  .replace(TERRAIN_SLOPE,'let slope=geometry.xy;');
export const terrainCachedColor=wgsl(TERRAIN_CACHED_COLOR_WGSL);
export const TERRAIN_GEOMETRY_WGSL=`fn terrainGeometry(uv:vec2<f32>,origin:vec3<f32>,forward:vec3<f32>,right:vec3<f32>,up:vec3<f32>,aspect:f32,tanFov:f32,inspection:f32)->vec4<f32>{
${TERRAIN_VIEW_RAY}
  let seaDistance=earthDistance(origin,ray);
  if(seaDistance<=0.0){return vec4<f32>(-1.0,0.0,0.0,0.0);}
  let distance=landscapeDistance(origin,ray,seaDistance);
  let p=(origin+ray*distance).xz;
  let h=terrainHeight(p);
  ${TERRAIN_SLOPE}
  return vec4<f32>(distance,slope,h);
}`;
export function createTerrainGeometryPass(){return wgslFn(TERRAIN_GEOMETRY_WGSL,[landscape]);}
export const TERRAIN_CACHE_LOAD='textureLoad(terrainGeometry,vec2<i32>(floor(uv*resolution)),0)';
export function createTerrainRecordReadPass(){return wgslFn(`fn terrainRecordRead(uv:vec2<f32>,resolution:vec2<f32>,terrainGeometry:texture_2d<f32>)->vec4<f32>{return ${TERRAIN_CACHE_LOAD};}`);}
