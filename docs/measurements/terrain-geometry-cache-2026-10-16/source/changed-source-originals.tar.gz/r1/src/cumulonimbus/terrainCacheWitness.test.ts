import {webcrypto} from 'node:crypto';
import {afterAll,beforeAll,describe,expect,it,vi} from 'vitest';
import {compareTerrainBuffers,selectedTerrainPixels,TERRAIN_WITNESS_SENTINEL} from './terrainCacheWitness';

beforeAll(()=>vi.stubGlobal('crypto',webcrypto));
afterAll(()=>vi.unstubAllGlobals());
const bits=(values:number[])=>new Float32Array(new Uint32Array(values).buffer);

describe('complete terrain raw-buffer witness',()=>{
  it('hashes the exact raw view with real SHA256 and reports every channel',async()=>{
    const storage=new Float32Array([99,0,0,0,0,88]),view=storage.subarray(1,5);
    const result=await compareTerrainBuffers(view,new Float32Array(4),1,1,'geometry');
    expect(result.status).toBe('pass');expect(result.bitEqual).toBe(true);
    expect(result.reference.sha256).toBe('374708fff7719dd5979ec875d56cd2286f6d3cf7ec317a3b25632aab28ec37bb');
    expect(result.candidate.sha256).toBe(result.reference.sha256);
    expect(result).toMatchObject({pixelCount:1,channelCount:4,channelsPerPixel:4,byteLength:16,mismatchedChannels:0,mismatchedPixels:0,firstDiffs:[]});
    expect(result.reference).toMatchObject({finiteChannels:4,nanChannels:0,infiniteChannels:0,sentinelChannels:0,sentinelPixels:0,geometry:{hitPixels:1,missPixels:0,tZeroPixels:1,invalidDistancePixels:0}});
  });
  it('distinguishes negative zero from positive zero by bits',async()=>{
    const result=await compareTerrainBuffers(bits([0x80000000,0,0,0]),bits([0,0,0,0]),1,1,'geometry');
    expect(result.status).toBe('fail');expect(result.bitEqual).toBe(false);
    expect(result.firstDiffs).toEqual([{index:0,pixelIndex:0,x:0,y:0,channel:0,reference:{uintHex:'0x80000000',float:'-0'},candidate:{uintHex:'0x00000000',float:0}}]);
    expect(result.reference.geometry?.tZeroPixels).toBe(1);expect(result.candidate.geometry?.tZeroPixels).toBe(1);
    expect(result.reference.sha256).not.toBe(result.candidate.sha256);
  });
  it('distinguishes a miss at -1 from a valid hit at t=0',async()=>{
    const reference=new Float32Array([-1,0,0,0,0,0,0,0,4,0,0,0]),candidate=reference.slice();candidate[0]=0;
    const result=await compareTerrainBuffers(reference,candidate,3,1,'geometry');
    expect(result.status).toBe('fail');
    expect(result.reference.geometry).toEqual({hitPixels:2,missPixels:1,tZeroPixels:1,invalidDistancePixels:0});
    expect(result.candidate.geometry).toEqual({hitPixels:3,missPixels:0,tZeroPixels:2,invalidDistancePixels:0});
    expect(result.firstDiffs[0].reference).toEqual({uintHex:'0xbf800000',float:-1});
  });
  it('does not pass equal NaN payloads and preserves differing NaN payload bits',async()=>{
    const reference=bits([0,0x7fc00001,0,0]);
    const equal=await compareTerrainBuffers(reference,reference,1,1,'geometry');
    expect(equal.bitEqual).toBe(true);expect(equal.status).toBe('fail');expect(equal.reference.nanChannels).toBe(1);
    const changed=await compareTerrainBuffers(reference,bits([0,0x7fc00002,0,0]),1,1,'geometry');
    expect(changed.mismatchedChannels).toBe(1);expect(changed.firstDiffs[0]).toMatchObject({channel:1,reference:{uintHex:'0x7fc00001',float:'NaN'},candidate:{uintHex:'0x7fc00002',float:'NaN'}});
    expect(changed.reference.sha256).not.toBe(changed.candidate.sha256);
  });
  it('fails an otherwise equal buffer with infinity or untouched finite sentinels',async()=>{
    const infinite=bits([0,0x7f800000,0xff800000,0]);
    const inf=await compareTerrainBuffers(infinite,infinite,1,1,'geometry');
    expect(inf.bitEqual).toBe(true);expect(inf.status).toBe('fail');expect(inf.reference.infiniteChannels).toBe(2);
    const untouched=new Float32Array([0,TERRAIN_WITNESS_SENTINEL,TERRAIN_WITNESS_SENTINEL,0,0,0,0,TERRAIN_WITNESS_SENTINEL]);
    const sentinel=await compareTerrainBuffers(untouched,untouched,2,1,'linear');
    expect(sentinel.status).toBe('fail');expect(sentinel.reference).toMatchObject({finiteChannels:8,sentinelChannels:3,sentinelPixels:2,geometry:null});
  });
  it('scans through the last pixel and its last channel',async()=>{
    const reference=new Float32Array(4*4*3),candidate=reference.slice();candidate[47]=1;
    const result=await compareTerrainBuffers(reference,candidate,4,3,'geometry');
    expect(result).toMatchObject({status:'fail',mismatchedChannels:1,mismatchedPixels:1});
    expect(result.firstDiffs[0]).toEqual({index:47,pixelIndex:11,x:3,y:2,channel:3,reference:{uintHex:'0x00000000',float:0},candidate:{uintHex:'0x3f800000',float:1}});
  });
  it('detects a change at a pixel absent from the selected records',async()=>{
    const reference=new Float32Array(8*6*4),candidate=reference.slice(),pixelIndex=18;
    expect(selectedTerrainPixels(8,6).some(pixel=>pixel.pixelIndex===pixelIndex)).toBe(false);
    candidate[pixelIndex*4+2]=1;
    const result=await compareTerrainBuffers(reference,candidate,8,6,'geometry');
    expect(result).toMatchObject({status:'fail',mismatchedChannels:1,mismatchedPixels:1});
    expect(result.firstDiffs[0]).toMatchObject({pixelIndex,x:2,y:2,channel:2});
  });
  it('counts every mismatch while bounding first differences to eight records',async()=>{
    const result=await compareTerrainBuffers(new Float32Array(32),new Float32Array(32).fill(1),4,2,'linear');
    expect(result).toMatchObject({status:'fail',mismatchedChannels:32,mismatchedPixels:8});
    expect(result.firstDiffs).toHaveLength(8);expect(result.firstDiffs.at(-1)?.index).toBe(7);
  });
  it('classifies invalid negative t only in geometry scope',async()=>{
    const invalid=new Float32Array([-2,0,0,0]);
    const geometry=await compareTerrainBuffers(invalid,invalid,1,1,'geometry');
    expect(geometry.status).toBe('fail');expect(geometry.reference.geometry?.invalidDistancePixels).toBe(1);
    const linear=await compareTerrainBuffers(invalid,invalid,1,1,'linear');
    expect(linear.status).toBe('pass');expect(linear.reference.geometry).toBeNull();
  });
  it('freezes bytes before asynchronous hashing can observe caller mutation',async()=>{
    const reference=new Float32Array(4),candidate=new Float32Array(4);
    const pending=compareTerrainBuffers(reference,candidate,1,1,'geometry');candidate[0]=5;reference[1]=NaN;
    const result=await pending;expect(result.status).toBe('pass');expect(result.candidate.geometry?.tZeroPixels).toBe(1);
    expect(result.reference.nanChannels).toBe(0);expect(result.reference.sha256).toBe(result.candidate.sha256);
  });
  it('uses deterministic normalized selections and deduplicates small rasters',()=>{
    expect(selectedTerrainPixels(1,1)).toEqual([{x:0,y:0,pixelIndex:0}]);
    expect(selectedTerrainPixels(5,5)).toEqual([
      {x:0,y:0,pixelIndex:0},{x:4,y:0,pixelIndex:4},{x:0,y:4,pixelIndex:20},{x:4,y:4,pixelIndex:24},
      {x:2,y:2,pixelIndex:12},{x:1,y:1,pixelIndex:6},{x:3,y:1,pixelIndex:8},{x:1,y:3,pixelIndex:16},{x:3,y:3,pixelIndex:18},
    ]);
  });
  it.each([[0,1],[-1,1],[1.5,1],[1,NaN],[Infinity,1],[Number.MAX_SAFE_INTEGER,2]])('rejects invalid raster dimensions %s x %s',async(width,height)=>{
    expect(()=>selectedTerrainPixels(width,height)).toThrow(RangeError);
    await expect(compareTerrainBuffers(new Float32Array(4),new Float32Array(4),width,height,'geometry')).rejects.toThrow(RangeError);
  });
  it('rejects either buffer length mismatch and an unnamed scope',async()=>{
    await expect(compareTerrainBuffers(new Float32Array(3),new Float32Array(4),1,1,'geometry')).rejects.toThrow(RangeError);
    await expect(compareTerrainBuffers(new Float32Array(4),new Float32Array(5),1,1,'geometry')).rejects.toThrow(RangeError);
    await expect(compareTerrainBuffers(new Float32Array(4),new Float32Array(4),1,1,' ')).rejects.toThrow(RangeError);
  });
});
