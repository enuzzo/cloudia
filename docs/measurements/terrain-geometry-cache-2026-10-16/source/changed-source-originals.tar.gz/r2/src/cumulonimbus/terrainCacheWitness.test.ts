import {webcrypto} from 'node:crypto';
import {afterAll,beforeAll,describe,expect,it,vi} from 'vitest';
import {compareTerrainBuffers,selectedTerrainPixels,TERRAIN_WITNESS_SENTINEL} from './terrainCacheWitness';

beforeAll(()=>vi.stubGlobal('crypto',webcrypto));
afterAll(()=>vi.unstubAllGlobals());
const bits=(values:number[])=>new Float32Array(new Uint32Array(values).buffer);

describe('complete terrain raw-buffer witness',()=>{
  it('hashes the exact raw view with real SHA256 and reports every channel',async()=>{
    const storage=new Float32Array([99,0,0,0,0,88]),view=storage.subarray(1,5);
    const result=await compareTerrainBuffers(view,new Float32Array(4),1,1,'geometry');
    expect(result.status).toBe('pass');expect(result.bitEqual).toBe(true);
    expect(result.reference.sha256).toBe('374708fff7719dd5979ec875d56cd2286f6d3cf7ec317a3b25632aab28ec37bb');
    expect(result.candidate.sha256).toBe(result.reference.sha256);
    expect(result).toMatchObject({pixelCount:1,channelCount:4,channelsPerPixel:4,byteLength:16,mismatchedChannels:0,mismatchedPixels:0,firstDiffs:[]});
    expect(result.reference).toMatchObject({finiteChannels:4,nanChannels:0,infiniteChannels:0,sentinelChannels:0,sentinelPixels:0,geometry:{hitPixels:1,missPixels:0,tZeroPixels:1,invalidDistancePixels:0}});
  });
  it('distinguishes negative zero from positive zero by bits',async()=>{
    const result=await compareTerrainBuffers(bits([0x80000000,0,0,0]),bits([0,0,0,0]),1,1,'geometry');
    expect(result.status).toBe('fail');expect(result.bitEqual).toBe(false);
    expect(result.firstDiffs).toEqual([{index:0,pixelIndex:0,x:0,y:0,channel:0,reference:{uintHex:'0x80000000',float:'-0'},candidate:{uintHex:'0x00000000',float:0}}]);
    expect(result.reference.geometry?.tZeroPixels).toBe(1);expect(result.candidate.geometry?.tZeroPixels).toBe(1);
    expect(result.reference.sha256).not.toBe(result.candidate.sha256);
  });
  it('distinguishes a miss at -1 from a valid hit at t=0',async()=>{
    const reference=new Float32Array([-1,0,0,0,0,0,0,0,4,0,0,0]),candidate=reference.slice();candidate[0]=0;
    const result=await compareTerrainBuffers(reference,candidate,3,1,'geometry');
    expect(result.status).toBe('fail');
    expect(result.reference.geometry).toEqual({hitPixels:2,missPixels:1,tZeroPixels:1,invalidDistancePixels:0});
    expect(result.candidate.geometry).toEqual({hitPixels:3,missPixels:0,tZeroPixels:2,invalidDistancePixels:0});
    expect(result.firstDiffs[0].reference).toEqual({uintHex:'0xbf800000',float:-1});
  });
  it('does not pass equal NaN payloads and preserves differing NaN payload bits',async()=>{
    const reference=bits([0,0x7fc00001,0,0]);
    const equal=await compareTerrainBuffers(reference,reference,1,1,'geometry');
    expect(equal.bitEqual).toBe(true);expect(equal.status).toBe('fail');expect(equal.reference.nanChannels).toBe(1);
    const changed=await compareTerrainBuffers(reference,bits([0,0x7fc00002,0,0]),1,1,'geometry');
    expect(changed.mismatchedChannels).toBe(1);expect(changed.firstDiffs[0]).toMatchObject({channel:1,reference:{uintHex:'0x7fc00001',float:'NaN'},candidate:{uintHex:'0x7fc00002',float:'NaN'}});
    expect(changed.reference.sha256).not.toBe(changed.candidate.sha256);
  });
  it('fails an otherwise equal buffer with infinity or untouched finite sentinels',async()=>{
    const infinite=bits([0,0x7f800000,0xff800000,0]);
    const inf=await compareTerrainBuffers(infinite,infinite,1,1,'geometry');
    expect(inf.bitEqual).toBe(true);expect(inf.status).toBe('fail');expect(inf.reference.infiniteChannels).toBe(2);
    const untouched=new Float32Array([0,TERRAIN_WITNESS_SENTINEL,TERRAIN_WITNESS_SENTINEL,0,0,0,0,TERRAIN_WITNESS_SENTINEL]);
    const sentinel=await compareTerrainBuffers(untouched,untouched,2,1,'linear');
    expect(sentinel.status).toBe('fail');expect(sentinel.reference).toMatchObject({finiteChannels:8,sentinelChannels:3,sentinelPixels:2,geometry:null});
  });
  it('scans through the last pixel and its last channel',async()=>{
    const reference=new Float32Array(4*4*3),candidate=reference.slice();candidate[47]=1;
    const result=await compareTerrainBuffers(reference,candidate,4,3,'geometry');
    expect(result).toMatchObject({status:'fail',mismatchedChannels:1,mismatchedPixels:1});
    expect(result.firstDiffs[0]).toEqual({index:47,pixelIndex:11,x:3,y:2,channel:3,reference:{uintHex:'0x00000000',float:0},candidate:{uintHex:'0x3f800000',float:1}});
  });
  it('detects a change at a pixel absent from the selected records',async()=>{
    const reference=new Float32Array(8*6*4),candidate=reference.slice(),pixelIndex=18;
    expect(selectedTerrainPixels(8,6).some(pixel=>pixel.pixelIndex===pixelIndex)).toBe(false);
    candidate[pixelIndex*4+2]=1;
    const result=await compareTerrainBuffers(reference,candidate,8,6,'geometry');
    expect(result).toMatchObject({status:'fail',mismatchedChannels:1,mismatchedPixels:1});
    expect(result.firstDiffs[0]).toMatchObject({pixelIndex,x:2,y:2,channel:2});
  });
  it('counts every mismatch while bounding first differences to eight records',async()=>{
    const result=await compareTerrainBuffers(new Float32Array(32),new Float32Array(32).fill(1),4,2,'linear');
    expect(result).toMatchObject({status:'fail',mismatchedChannels:32,mismatchedPixels:8});
    expect(result.firstDiffs).toHaveLength(8);expect(result.firstDiffs.at(-1)?.index).toBe(7);
  });
  it('classifies invalid negative t only in geometry scope',async()=>{
    const invalid=new Float32Array([-2,0,0,0]);
    const geometry=await compareTerrainBuffers(invalid,invalid,1,1,'geometry');
    expect(geometry.status).toBe('fail');expect(geometry.reference.geometry?.invalidDistancePixels).toBe(1);
    const linear=await compareTerrainBuffers(invalid,invalid,1,1,'linear');
    expect(linear.status).toBe('pass');expect(linear.reference.geometry).toBeNull();
  });
  it('freezes bytes before asynchronous hashing can observe caller mutation',async()=>{
    const reference=new Float32Array(4),candidate=new Float32Array(4);
    const pending=compareTerrainBuffers(reference,candidate,1,1,'geometry');candidate[0]=5;reference[1]=NaN;
    const result=await pending;expect(result.status).toBe('pass');expect(result.candidate.geometry?.tZeroPixels).toBe(1);
    expect(result.reference.nanChannels).toBe(0);expect(result.reference.sha256).toBe(result.candidate.sha256);
  });
  it('uses deterministic normalized selections and deduplicates small rasters',()=>{
    expect(selectedTerrainPixels(1,1)).toEqual([{x:0,y:0,pixelIndex:0}]);
    expect(selectedTerrainPixels(5,5)).toEqual([
      {x:0,y:0,pixelIndex:0},{x:4,y:0,pixelIndex:4},{x:0,y:4,pixelIndex:20},{x:4,y:4,pixelIndex:24},
      {x:2,y:2,pixelIndex:12},{x:1,y:1,pixelIndex:6},{x:3,y:1,pixelIndex:8},{x:1,y:3,pixelIndex:16},{x:3,y:3,pixelIndex:18},
    ]);
  });
  it.each([[0,1],[-1,1],[1.5,1],[1,NaN],[Infinity,1],[Number.MAX_SAFE_INTEGER,2]])('rejects invalid raster dimensions %s x %s',async(width,height)=>{
    expect(()=>selectedTerrainPixels(width,height)).toThrow(RangeError);
    await expect(compareTerrainBuffers(new Float32Array(4),new Float32Array(4),width,height,'geometry')).rejects.toThrow(RangeError);
  });
  it('rejects either buffer length mismatch and an unnamed scope',async()=>{
    await expect(compareTerrainBuffers(new Float32Array(3),new Float32Array(4),1,1,'geometry')).rejects.toThrow(RangeError);
    await expect(compareTerrainBuffers(new Float32Array(4),new Float32Array(5),1,1,'geometry')).rejects.toThrow(RangeError);
    await expect(compareTerrainBuffers(new Float32Array(4),new Float32Array(4),1,1,' ')).rejects.toThrow(RangeError);
  });
});

describe('full-range float error metrics',()=>{
  it('uses fixed finite-pair errors and separate RGBA, RGB and channel denominators',async()=>{
    const result=await compareTerrainBuffers(new Float32Array(4),new Float32Array([1,2,2,1]),1,1,'linear');
    expect(result.numeric.rgba).toMatchObject({comparedChannels:4,finitePairs:4,nonFinitePairs:0,bitMismatches:4,maxAbsoluteError:2,maxUlpDistance:1073741824});
    expect(result.numeric.rgba.rmse).toBeCloseTo(1.5811388300841898,14);
    expect(result.numeric.rgb.rmse).toBeCloseTo(1.7320508075688772,14);
    expect(result.numeric.rgb).toMatchObject({comparedChannels:3,finitePairs:3,bitMismatches:3});
    expect(result.numeric.perChannel.map(channel=>channel.rmse)).toEqual([1,2,2,1]);
    expect(result.numeric.rgba.maxAbsoluteAt).toMatchObject({index:1,pixelIndex:0,x:0,y:0,channel:1,absoluteError:2});
    expect(result.numeric.rgba.maxUlpAt).toMatchObject({index:1,ulpDistance:1073741824});
  });
  it('handles ordered negative values, signed zero and opposite minimum subnormals',async()=>{
    const reference=bits([0x80000001,0x80000000,0xbf800001,0x3f800000]);
    const candidate=bits([0x00000001,0x00000000,0xbf800000,0x3f800001]);
    const result=await compareTerrainBuffers(reference,candidate,1,1,'linear'),metric=result.numeric.rgba;
    expect(result.status).toBe('fail');
    expect(metric).toMatchObject({finitePairs:4,bitMismatches:4,signedZeroBitMismatches:1,maxUlpDistance:2,maxAbsoluteError:1.1920928955078125e-7});
    expect(metric.rmse).toBeCloseTo(8.429369702178807e-8,20);
    expect(metric.maxUlpAt).toMatchObject({index:0,ulpDistance:2});
    expect(metric.maxAbsoluteAt).toMatchObject({index:2,absoluteError:1.1920928955078125e-7});
    expect(metric.ulpHistogram.filter(bin=>bin.count)).toEqual([{min:0,max:0,count:1},{min:1,max:1,count:2},{min:2,max:2,count:1}]);
  });
  it('keeps -0/+0 a bit failure with zero absolute/RMSE/ULP error',async()=>{
    const result=await compareTerrainBuffers(bits([0x80000000,0,0,0]),new Float32Array(4),1,1,'linear');
    expect(result.status).toBe('fail');
    expect(result.numeric.rgba).toMatchObject({bitMismatches:1,signedZeroBitMismatches:1,maxAbsoluteError:0,rmse:0,maxUlpDistance:0,maxAbsoluteAt:null,maxUlpAt:null});
    expect(result.numeric.rgba.ulpHistogram[0]).toEqual({min:0,max:0,count:4});
    const across=await compareTerrainBuffers(new Float32Array([-1,0,0,0]),new Float32Array([1,0,0,0]),1,1,'linear');
    expect(across.numeric.rgba.maxUlpDistance).toBe(2130706432);
  });
  it('finds the true maximum after the eight retained first differences',async()=>{
    const reference=new Float32Array(16),candidate=new Float32Array(16);
    candidate.fill(.5,0,9);candidate[15]=4;
    const result=await compareTerrainBuffers(reference,candidate,4,1,'linear');
    expect(result.firstDiffs).toHaveLength(8);expect(result.firstDiffs.at(-1)?.index).toBe(7);
    expect(result.numeric.rgba).toMatchObject({maxAbsoluteError:4,maxUlpDistance:1082130432});
    expect(result.numeric.rgba.maxAbsoluteAt).toMatchObject({index:15,pixelIndex:3,x:3,y:0,channel:3});
    expect(result.numeric.rgba.maxUlpAt).toMatchObject({index:15,ulpDistance:1082130432});
    expect(result.numeric.rgba.ulpHistogram.reduce((sum,bin)=>sum+bin.count,0)).toBe(16);
  });
  it('excludes non-finite pairs from RMSE and leaves finite sentinels visible and invalid',async()=>{
    const result=await compareTerrainBuffers(new Float32Array([0,1,2,NaN]),new Float32Array([2,Infinity,0,NaN]),1,1,'linear');
    expect(result.status).toBe('fail');
    expect(result.numeric.rgba).toMatchObject({comparedChannels:4,finitePairs:2,nonFinitePairs:2,maxAbsoluteError:2,rmse:2});
    expect(result.numeric.rgba.ulpHistogram.reduce((sum,bin)=>sum+bin.count,0)).toBe(2);
    const none=await compareTerrainBuffers(new Float32Array(4).fill(NaN),new Float32Array(4).fill(Infinity),1,1,'linear');
    expect(none.numeric.rgba).toMatchObject({finitePairs:0,nonFinitePairs:4,maxAbsoluteError:null,rmse:null,maxUlpDistance:null});
    const sentinel=new Float32Array([0,TERRAIN_WITNESS_SENTINEL,0,0]);
    const equal=await compareTerrainBuffers(sentinel,sentinel,1,1,'linear');
    expect(equal.status).toBe('fail');expect(equal.numeric.rgba).toMatchObject({finitePairs:4,rmse:0});
  });
  it('labels the geometry comparison as fresh prepass versus stored prepass, without an inline-solver proof',async()=>{
    const result=await compareTerrainBuffers(new Float32Array(4),new Float32Array(4),1,1,'geometry');
    expect(result.referenceRole).toBe('fresh prepass output');expect(result.candidateRole).toBe('stored prepass via textureLoad');
    expect(result.scopeLimit).toContain('Does not compare with the terrain solver executed inline');
    expect(result.roundingHypothesis).toContain('not an established cause');expect(result.quantization).toBeNull();
  });
});

describe('derived RGB8 metrics, independently of raw bit acceptance',()=>{
  const scope='render-post-film-linear';
  it('quantizes the fixed half-linear witness to 128 linear8 and 188 IEC sRGB8, excluding alpha',async()=>{
    const result=await compareTerrainBuffers(new Float32Array(4),new Float32Array([.5,.5,.5,1]),1,1,scope),q=result.quantization!;
    expect(result.status).toBe('fail');expect(result.mismatchedChannels).toBe(4);
    expect(q).toMatchObject({rgbChannels:3,alphaChannelsExcluded:1,eligiblePixels:1,excludedPixels:0,invalidChannels:0,excludedChannels:0});
    expect(q.linear8).toMatchObject({comparedChannels:3,mismatchedChannels:3,mismatchedPixels:1,maxDelta:128,maxDeltaAt:{channel:0,reference:0,candidate:128,delta:128},deltaHistogram:[{delta:128,count:3}]});
    expect(q.srgb8).toMatchObject({comparedChannels:3,mismatchedChannels:3,mismatchedPixels:1,maxDelta:188,maxDeltaAt:{channel:0,reference:0,candidate:188,delta:188},deltaHistogram:[{delta:188,count:3}]});
    expect(q.linear8.perChannel.map(channel=>channel.maxDelta)).toEqual([128,128,128]);
    expect(q.srgb8.perChannel.map(channel=>channel.maxDelta)).toEqual([188,188,188]);
    expect(q.scope).toContain('not renderer/compositor output');expect(q.rules).toContain('x<=0.0031308');expect(q.rules).toContain('1/2.4');
  });
  it('uses fixed dark, quarter-linear and white code values',async()=>{
    const result=await compareTerrainBuffers(new Float32Array(4),new Float32Array([.0031308,.25,1,0]),1,1,scope),q=result.quantization!;
    expect(q.linear8.perChannel.map(channel=>channel.maxDelta)).toEqual([1,64,255]);
    expect(q.srgb8.perChannel.map(channel=>channel.maxDelta)).toEqual([10,137,255]);
  });
  it('reports a full-range quantized tail maximum with exact channel and pixel counts',async()=>{
    const reference=new Float32Array(16),candidate=new Float32Array(16);
    candidate.fill(.5,0,12);candidate[14]=1;
    const result=await compareTerrainBuffers(reference,candidate,4,1,scope),q=result.quantization!;
    expect(result.firstDiffs.at(-1)?.index).toBe(7);
    for(const metric of [q.linear8,q.srgb8]){
      expect(metric).toMatchObject({comparedChannels:12,mismatchedChannels:10,mismatchedPixels:4,maxDelta:255,maxDeltaAt:{pixelIndex:3,x:3,y:0,channel:2,reference:0,candidate:255}});
      expect(metric.perChannel.map(channel=>channel.mismatchedChannels)).toEqual([3,3,4]);
      expect(metric.deltaHistogram.reduce((sum,bin)=>sum+bin.count,0)).toBe(12);
    }
  });
  it('clamps RGB, ignores alpha in derived metrics and still fails invalid raw data',async()=>{
    const reference=new Float32Array([0,1,1,NaN]),candidate=new Float32Array([-1,2,2,NaN]);
    const result=await compareTerrainBuffers(reference,candidate,1,1,scope),q=result.quantization!;
    expect(result.status).toBe('fail');expect(q).toMatchObject({eligiblePixels:1,excludedPixels:0,invalidChannels:0,clippedReferenceChannels:0,clippedCandidateChannels:3,alphaChannelsExcluded:1});
    for(const metric of [q.linear8,q.srgb8])expect(metric).toMatchObject({comparedChannels:3,mismatchedChannels:0,mismatchedPixels:0,maxDelta:0,maxDeltaAt:null,deltaHistogram:[{delta:0,count:3}]});
  });
  it('does not turn a sub-code-value raw difference into a bit pass',async()=>{
    const reference=bits([0x3f000000,0x3f000000,0x3f000000,0x3f800000]);
    const candidate=bits([0x3f000001,0x3f000000,0x3f000000,0x3f800000]);
    const result=await compareTerrainBuffers(reference,candidate,1,1,scope),q=result.quantization!;
    expect(result.status).toBe('fail');expect(result.numeric.rgba.maxUlpDistance).toBe(1);
    expect(q.linear8.mismatchedChannels).toBe(0);expect(q.srgb8.mismatchedChannels).toBe(0);
  });
  it('counts invalid RGB pairs separately from all channels of excluded pixels',async()=>{
    const candidate=new Float32Array([NaN,.5,.5,1,0,Infinity,TERRAIN_WITNESS_SENTINEL,1,.5,.5,.5,NaN]);
    const result=await compareTerrainBuffers(new Float32Array(12),candidate,3,1,scope),q=result.quantization!;
    expect(result.status).toBe('fail');
    expect(q).toMatchObject({rgbChannels:9,alphaChannelsExcluded:3,eligiblePixels:1,excludedPixels:2,invalidChannels:3,excludedChannels:6});
    expect(q.linear8).toMatchObject({comparedChannels:3,mismatchedChannels:3,mismatchedPixels:1});
    expect(q.srgb8.maxDelta).toBe(188);
    expect(q.invalidPolicy).toContain('Raw bit/invalid-data FAIL is unchanged');
  });
});
