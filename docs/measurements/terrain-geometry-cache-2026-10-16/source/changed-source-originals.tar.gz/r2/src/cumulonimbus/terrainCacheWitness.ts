export const TERRAIN_WITNESS_SENTINEL=-987654.25;
/** Chosen before capture: corners, centre, then quarter/three-quarter samples. */
export const SELECTED_TERRAIN_PIXEL_COORDINATES=Object.freeze([
  [0,0],[1,0],[0,1],[1,1],[.5,.5],[.25,.25],[.75,.25],[.25,.75],[.75,.75],
] as const);

export interface TerrainWitnessPixel {readonly x:number;readonly y:number;readonly pixelIndex:number}
type WitnessFloat=number|'NaN'|'+Infinity'|'-Infinity'|'-0';
interface RawChannel {readonly uintHex:string;readonly float:WitnessFloat}
interface TerrainVariantStats {
  readonly sha256:string;readonly finiteChannels:number;readonly nanChannels:number;readonly infiniteChannels:number;
  readonly sentinelChannels:number;readonly sentinelPixels:number;
  readonly geometry:{readonly hitPixels:number;readonly missPixels:number;readonly tZeroPixels:number;readonly invalidDistancePixels:number}|null;
}
interface TerrainWitnessDiff extends TerrainWitnessPixel {
  readonly index:number;readonly channel:number;readonly reference:RawChannel;readonly candidate:RawChannel;
}
interface TerrainWitnessRecord extends TerrainWitnessPixel {
  readonly reference:readonly RawChannel[];readonly candidate:readonly RawChannel[];
}
interface ErrorPosition extends TerrainWitnessDiff {readonly absoluteError:number;readonly ulpDistance:number}
interface FloatErrorSummary {
  readonly comparedChannels:number;readonly finitePairs:number;readonly nonFinitePairs:number;
  readonly bitMismatches:number;readonly signedZeroBitMismatches:number;
  readonly maxAbsoluteError:number|null;readonly rmse:number|null;readonly maxUlpDistance:number|null;
  readonly maxAbsoluteAt:ErrorPosition|null;readonly maxUlpAt:ErrorPosition|null;
  readonly ulpHistogram:readonly {readonly min:number;readonly max:number|null;readonly count:number}[];
}
interface QuantizedPosition extends TerrainWitnessPixel {
  readonly channel:number;readonly reference:number;readonly candidate:number;readonly delta:number;
}
interface QuantizedSummary {
  readonly comparedChannels:number;readonly mismatchedChannels:number;readonly mismatchedPixels:number;
  readonly maxDelta:number;readonly maxDeltaAt:QuantizedPosition|null;
  readonly deltaHistogram:readonly {readonly delta:number;readonly count:number}[];
  readonly perChannel:readonly {readonly channel:number;readonly comparedChannels:number;readonly mismatchedChannels:number;readonly mismatchedPixels:number;readonly maxDelta:number;readonly maxDeltaAt:QuantizedPosition|null}[];
}
interface RgbQuantization {
  readonly scope:string;readonly rules:string;readonly invalidPolicy:string;
  readonly rgbChannels:number;readonly alphaChannelsExcluded:number;
  readonly eligiblePixels:number;readonly excludedPixels:number;readonly invalidChannels:number;readonly excludedChannels:number;
  readonly clippedReferenceChannels:number;readonly clippedCandidateChannels:number;
  readonly linear8:QuantizedSummary;readonly srgb8:QuantizedSummary;
}
export interface TerrainBufferComparison {
  readonly scope:string;readonly width:number;readonly height:number;readonly channelsPerPixel:4;
  readonly referenceRole:string;readonly candidateRole:string;readonly scopeLimit:string;readonly roundingHypothesis:string;
  readonly pixelCount:number;readonly channelCount:number;readonly byteLength:number;
  readonly bitEqual:boolean;readonly status:'pass'|'fail';
  readonly reference:TerrainVariantStats;readonly candidate:TerrainVariantStats;
  readonly mismatchedChannels:number;readonly mismatchedPixels:number;
  readonly firstDiffs:readonly TerrainWitnessDiff[];
  readonly numeric:{readonly rules:string;readonly rgba:FloatErrorSummary;readonly rgb:FloatErrorSummary;readonly perChannel:readonly (FloatErrorSummary&{readonly channel:number})[]};
  readonly quantization:RgbQuantization|null;
  readonly selectedCoordinates:typeof SELECTED_TERRAIN_PIXEL_COORDINATES;
  readonly selectedRecords:readonly TerrainWitnessRecord[];
}

function dimensions(width:number,height:number):number {
  const pixels=width*height;
  if(!Number.isSafeInteger(width)||width<=0||!Number.isSafeInteger(height)||height<=0||!Number.isSafeInteger(pixels*4))throw new RangeError('Terrain witness dimensions must be positive safe integers');
  return pixels;
}

export function selectedTerrainPixels(width:number,height:number):TerrainWitnessPixel[] {
  dimensions(width,height);
  const seen=new Set<number>(),selected:TerrainWitnessPixel[]=[];
  for(const [u,v] of SELECTED_TERRAIN_PIXEL_COORDINATES){
    const x=Math.floor(u*(width-1)),y=Math.floor(v*(height-1)),pixelIndex=y*width+x;
    if(!seen.has(pixelIndex)){seen.add(pixelIndex);selected.push({x,y,pixelIndex});}
  }
  return selected;
}

function snapshot(input:Float32Array){
  // Freeze the same bytes for both comparison and asynchronous hashing. Copy
  // bytes, not float values, so NaN payloads and signed zero remain intact.
  const bytes=new Uint8Array(input.byteLength);
  bytes.set(new Uint8Array(input.buffer,input.byteOffset,input.byteLength));
  return {bytes,bits:new Uint32Array(bytes.buffer),values:new Float32Array(bytes.buffer)};
}
function raw(bits:number,value:number):RawChannel {
  const float=Number.isNaN(value)?'NaN':value===Infinity?'+Infinity':value===-Infinity?'-Infinity':Object.is(value,-0)?'-0':value;
  return {uintHex:`0x${bits.toString(16).padStart(8,'0')}`,float};
}
// Adjacent finite f32 values map to adjacent integers. Both signed zeros map
// to the same integer; -minSubnormal to +minSubnormal therefore spans 2 ULP.
function ordered(bits:number):number {return bits>=0x80000000?0x80000000-(bits-0x80000000):0x80000000+bits;}
const ULP_BOUNDS=[0,1,2,4,8,16,32,64,128,256,1024,4096,65536,Infinity];
function ulpBin(distance:number):number {
  let bin=0;while(distance>ULP_BOUNDS[bin])bin++;return bin;
}
function errorAccumulator(){
  return {comparedChannels:0,finitePairs:0,nonFinitePairs:0,bitMismatches:0,signedZeroBitMismatches:0,
    squareSum:0,correction:0,maxAbsoluteError:0,maxUlpDistance:0,maxAbsoluteIndex:-1,maxUlpIndex:-1,histogram:new Array<number>(ULP_BOUNDS.length).fill(0)};
}
type ErrorAccumulator=ReturnType<typeof errorAccumulator>;
function accumulate(acc:ErrorAccumulator,index:number,reference:number,candidate:number,bitsDiffer:boolean,absoluteError:number,ulpDistance:number,bin:number):void {
  acc.comparedChannels++;if(bitsDiffer)acc.bitMismatches++;
  if(!Number.isFinite(reference)||!Number.isFinite(candidate)){acc.nonFinitePairs++;return;}
  acc.finitePairs++;acc.histogram[bin]++;
  if(bitsDiffer&&reference===0&&candidate===0)acc.signedZeroBitMismatches++;
  // Compensated f64 sum; each summary uses its own finite-pair denominator.
  const square=absoluteError*absoluteError,y=square-acc.correction,next=acc.squareSum+y;
  acc.correction=(next-acc.squareSum)-y;acc.squareSum=next;
  if(absoluteError>acc.maxAbsoluteError){acc.maxAbsoluteError=absoluteError;acc.maxAbsoluteIndex=index;}
  if(ulpDistance>acc.maxUlpDistance){acc.maxUlpDistance=ulpDistance;acc.maxUlpIndex=index;}
}
function errorSummary(acc:ErrorAccumulator,a:ReturnType<typeof snapshot>,b:ReturnType<typeof snapshot>,width:number):FloatErrorSummary {
  const position=(index:number):ErrorPosition|null=>{
    if(index<0)return null;
    const pixelIndex=Math.floor(index/4);
    return {index,pixelIndex,x:pixelIndex%width,y:Math.floor(pixelIndex/width),channel:index%4,reference:raw(a.bits[index],a.values[index]),candidate:raw(b.bits[index],b.values[index]),absoluteError:Math.abs(a.values[index]-b.values[index]),ulpDistance:Math.abs(ordered(a.bits[index])-ordered(b.bits[index]))};
  };
  return {comparedChannels:acc.comparedChannels,finitePairs:acc.finitePairs,nonFinitePairs:acc.nonFinitePairs,bitMismatches:acc.bitMismatches,signedZeroBitMismatches:acc.signedZeroBitMismatches,
    maxAbsoluteError:acc.finitePairs?acc.maxAbsoluteError:null,rmse:acc.finitePairs?Math.sqrt(acc.squareSum/acc.finitePairs):null,maxUlpDistance:acc.finitePairs?acc.maxUlpDistance:null,
    maxAbsoluteAt:position(acc.maxAbsoluteIndex),maxUlpAt:position(acc.maxUlpIndex),
    ulpHistogram:ULP_BOUNDS.map((max,bin)=>({min:bin===0?0:ULP_BOUNDS[bin-1]+1,max:Number.isFinite(max)?max:null,count:acc.histogram[bin]}))};
}
function quantizedAccumulator(){
  return {comparedChannels:0,mismatchedChannels:0,mismatchedPixels:0,maxDelta:0,maxDeltaAt:null as QuantizedPosition|null,histogram:new Array<number>(256).fill(0),
    perChannel:Array.from({length:3},(_,channel)=>({channel,comparedChannels:0,mismatchedChannels:0,mismatchedPixels:0,maxDelta:0,maxDeltaAt:null as QuantizedPosition|null}))};
}
function quantizedChannel(acc:ReturnType<typeof quantizedAccumulator>,reference:number,candidate:number,pixelIndex:number,channel:number,width:number):boolean {
  const delta=Math.abs(reference-candidate),perChannel=acc.perChannel[channel];
  acc.comparedChannels++;perChannel.comparedChannels++;acc.histogram[delta]++;
  if(delta===0)return false;
  acc.mismatchedChannels++;perChannel.mismatchedChannels++;perChannel.mismatchedPixels++;
  if(delta>acc.maxDelta||delta>perChannel.maxDelta){
    const position={pixelIndex,x:pixelIndex%width,y:Math.floor(pixelIndex/width),channel,reference,candidate,delta};
    if(delta>acc.maxDelta){acc.maxDelta=delta;acc.maxDeltaAt=position;}
    if(delta>perChannel.maxDelta){perChannel.maxDelta=delta;perChannel.maxDeltaAt=position;}
  }
  return true;
}
function quantizedSummary(acc:ReturnType<typeof quantizedAccumulator>):QuantizedSummary {
  return {comparedChannels:acc.comparedChannels,mismatchedChannels:acc.mismatchedChannels,mismatchedPixels:acc.mismatchedPixels,maxDelta:acc.maxDelta,maxDeltaAt:acc.maxDeltaAt,
    deltaHistogram:acc.histogram.flatMap((count,delta)=>count?[{delta,count}]:[]),perChannel:acc.perChannel};
}
function rgbQuantization(a:ReturnType<typeof snapshot>,b:ReturnType<typeof snapshot>,width:number,pixelCount:number):RgbQuantization {
  const linear=quantizedAccumulator(),srgb=quantizedAccumulator();
  let eligiblePixels=0,excludedPixels=0,invalidChannels=0,clippedReferenceChannels=0,clippedCandidateChannels=0;
  const invalid=(value:number)=>!Number.isFinite(value)||value===TERRAIN_WITNESS_SENTINEL;
  const srgbByte=(value:number)=>Math.round(255*(value<=.0031308?12.92*value:1.055*Math.pow(value,1/2.4)-.055));
  for(let pixelIndex=0;pixelIndex<pixelCount;pixelIndex++){
    const base=pixelIndex*4;let invalidPairs=0;
    for(let channel=0;channel<3;channel++)if(invalid(a.values[base+channel])||invalid(b.values[base+channel]))invalidPairs++;
    if(invalidPairs){excludedPixels++;invalidChannels+=invalidPairs;continue;}
    eligiblePixels++;let linearMismatch=false,srgbMismatch=false;
    for(let channel=0;channel<3;channel++){
      const av=a.values[base+channel],bv=b.values[base+channel];
      if(av<0||av>1)clippedReferenceChannels++;if(bv<0||bv>1)clippedCandidateChannels++;
      const ac=Math.max(0,Math.min(1,av)),bc=Math.max(0,Math.min(1,bv));
      if(quantizedChannel(linear,Math.round(ac*255),Math.round(bc*255),pixelIndex,channel,width))linearMismatch=true;
      if(quantizedChannel(srgb,srgbByte(ac),srgbByte(bc),pixelIndex,channel,width))srgbMismatch=true;
    }
    if(linearMismatch)linear.mismatchedPixels++;if(srgbMismatch)srgb.mismatchedPixels++;
  }
  return {scope:'Derived RGB8 comparison only; not renderer/compositor output or a presentation proof.',
    rules:'Clamp RGB to [0,1]. Linear8: Math.round(255*x). Derived IEC sRGB8: Math.round(255*(x<=0.0031308 ? 12.92*x : 1.055*x^(1/2.4)-0.055)). Alpha excluded. Zero-count delta bins omitted.',
    invalidPolicy:'Any RGB NaN, infinity or witness sentinel excludes all three channels of that pixel from both derived comparisons; invalidChannels counts the offending RGB pairs, excludedChannels counts all omitted RGB channels. Raw bit/invalid-data FAIL is unchanged.',
    rgbChannels:pixelCount*3,alphaChannelsExcluded:pixelCount,eligiblePixels,excludedPixels,invalidChannels,excludedChannels:excludedPixels*3,clippedReferenceChannels,clippedCandidateChannels,
    linear8:quantizedSummary(linear),srgb8:quantizedSummary(srgb)};
}
async function stats(buffer:ReturnType<typeof snapshot>,geometry:boolean):Promise<TerrainVariantStats> {
  let finiteChannels=0,nanChannels=0,infiniteChannels=0,sentinelChannels=0,sentinelPixels=0,lastSentinelPixel=-1;
  let hitPixels=0,missPixels=0,tZeroPixels=0,invalidDistancePixels=0;
  for(let index=0;index<buffer.values.length;index++){
    const value=buffer.values[index];
    if(Number.isFinite(value))finiteChannels++;
    else if(Number.isNaN(value))nanChannels++;
    else infiniteChannels++;
    if(value===TERRAIN_WITNESS_SENTINEL){
      sentinelChannels++;const pixel=Math.floor(index/4);
      if(pixel!==lastSentinelPixel){sentinelPixels++;lastSentinelPixel=pixel;}
    }
    if(geometry&&index%4===0){
      if(Number.isFinite(value)&&value>=0){hitPixels++;if(value===0)tZeroPixels++;}
      else if(value===-1)missPixels++;
      else invalidDistancePixels++;
    }
  }
  const digest=new Uint8Array(await crypto.subtle.digest('SHA-256',buffer.bytes));
  const sha256=Array.from(digest,value=>value.toString(16).padStart(2,'0')).join('');
  return {sha256,finiteChannels,nanChannels,infiniteChannels,sentinelChannels,sentinelPixels,geometry:geometry?{hitPixels,missPixels,tZeroPixels,invalidDistancePixels}:null};
}

/** Compares every RGBA f32 bit. Selected records are an inspection aid only.
 * Scope "geometry" additionally classifies component 0 as t: -1 miss, >=0 hit.
 * Equality alone cannot pass a buffer containing NaN, infinity or sentinel.
 */
export async function compareTerrainBuffers(reference:Float32Array,candidate:Float32Array,width:number,height:number,scope:string):Promise<TerrainBufferComparison> {
  const pixelCount=dimensions(width,height),channelCount=pixelCount*4;
  if(reference.length!==channelCount||candidate.length!==channelCount)throw new RangeError('Terrain witness buffer length must equal 4 * width * height');
  if(!scope.trim())throw new RangeError('Terrain witness scope must be named');
  const a=snapshot(reference),b=snapshot(candidate),firstDiffs:TerrainWitnessDiff[]=[];
  const rgba=errorAccumulator(),rgb=errorAccumulator(),perChannel=Array.from({length:4},errorAccumulator);
  let mismatchedChannels=0,mismatchedPixels=0,lastMismatchPixel=-1;
  for(let index=0;index<channelCount;index++){
    const av=a.values[index],bv=b.values[index],bitsDiffer=a.bits[index]!==b.bits[index],channel=index%4;
    const finite=Number.isFinite(av)&&Number.isFinite(bv),absoluteError=finite?Math.abs(av-bv):0,ulpDistance=finite?Math.abs(ordered(a.bits[index])-ordered(b.bits[index])):0,bin=ulpBin(ulpDistance);
    accumulate(rgba,index,av,bv,bitsDiffer,absoluteError,ulpDistance,bin);
    accumulate(perChannel[channel],index,av,bv,bitsDiffer,absoluteError,ulpDistance,bin);
    if(channel<3)accumulate(rgb,index,av,bv,bitsDiffer,absoluteError,ulpDistance,bin);
    if(!bitsDiffer)continue;
    mismatchedChannels++;const pixelIndex=Math.floor(index/4);
    if(pixelIndex!==lastMismatchPixel){mismatchedPixels++;lastMismatchPixel=pixelIndex;}
    if(firstDiffs.length<8)firstDiffs.push({index,pixelIndex,x:pixelIndex%width,y:Math.floor(pixelIndex/width),channel:index%4,reference:raw(a.bits[index],a.values[index]),candidate:raw(b.bits[index],b.values[index])});
  }
  const selectedRecords=selectedTerrainPixels(width,height).map(pixel=>{
    const record=(buffer:ReturnType<typeof snapshot>)=>Array.from({length:4},(_,channel)=>{
      const index=pixel.pixelIndex*4+channel;return raw(buffer.bits[index],buffer.values[index]);
    });
    return {...pixel,reference:record(a),candidate:record(b)};
  });
  const [referenceStats,candidateStats]=await Promise.all([stats(a,scope==='geometry'),stats(b,scope==='geometry')]);
  const invalid=(variant:TerrainVariantStats)=>variant.nanChannels+variant.infiniteChannels+variant.sentinelChannels+(variant.geometry?.invalidDistancePixels??0)>0;
  const bitEqual=mismatchedChannels===0;
  return {scope,width,height,channelsPerPixel:4,
    referenceRole:scope==='geometry'?'fresh prepass output':scope==='render-post-film-linear'?'monolithic direct integrator post-film linear output':'caller-provided reference buffer',candidateRole:scope==='geometry'?'stored prepass via textureLoad':scope==='render-post-film-linear'?'terrain-cached integrator post-film linear output':'caller-provided candidate buffer',
    scopeLimit:scope==='geometry'?'Compares a fresh geometry prepass with the stored prepass record. Does not compare with the terrain solver executed inline inside the monolithic direct integrator.':scope==='render-post-film-linear'?'Full-buffer numerical comparison after film mapping; no compositor or displayed-image equivalence claim.':'Full-buffer numerical comparison only; caller defines buffer semantics.',
    roundingHypothesis:'Compiler rounding is a possible explanation for differences, not an established cause.',
    pixelCount,channelCount,byteLength:reference.byteLength,bitEqual,status:bitEqual&&!invalid(referenceStats)&&!invalid(candidateStats)?'pass':'fail',reference:referenceStats,candidate:candidateStats,mismatchedChannels,mismatchedPixels,firstDiffs,
    numeric:{rules:'All pairs scanned. RMSE uses the finite-pair denominator of each RGBA/RGB/per-channel summary; finite sentinels remain in these numeric statistics and still cause raw FAIL. RGB means components 0,1,2; component 3 excluded. ULP uses ordered finite f32 values with +/-0 distance 0; signed-zero bit mismatches counted separately. Maxima retain the first position on ties; zero errors have no maximum position.',rgba:errorSummary(rgba,a,b,width),rgb:errorSummary(rgb,a,b,width),perChannel:perChannel.map((acc,channel)=>({...errorSummary(acc,a,b,width),channel}))},
    quantization:scope==='render-post-film-linear'?rgbQuantization(a,b,width,pixelCount):null,selectedCoordinates:SELECTED_TERRAIN_PIXEL_COORDINATES,selectedRecords};
}
