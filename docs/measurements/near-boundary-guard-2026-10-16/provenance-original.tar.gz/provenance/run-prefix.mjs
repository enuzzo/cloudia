// Geometry prefix only: inserted return precedes rasterization/detail/light bake.
import {readFileSync, writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync, gunzipSync} from 'node:zlib';
import {generateVolume, __resetAudit} from './geometry-prefix.mjs';
const [output, forceFrom] = process.argv.slice(2);
if (!output) throw new Error('Expected output path');
const forced = forceFrom ? JSON.parse(gunzipSync(readFileSync(forceFrom))).trig : null;
let cursor = 0;
const trig = [];
const originals = {sin:Math.sin,cos:Math.cos};
for (const name of ['sin','cos']) Math[name] = input => {
  let value;
  if (forced) {
    const entry = forced[cursor++];
    if (!entry || entry.name !== name || !Object.is(entry.input,input)) throw new Error('Transcendental argument/order differs at '+(cursor-1));
    value = entry.output;
  } else value = originals[name](input);
  trig.push({name,input,output:value});
  return value;
};
let result;
try { __resetAudit(); result=generateVolume(8,72); }
finally { for(const name of ['sin','cos']) Math[name]=originals[name]; }
if (forced && cursor!==forced.length) throw new Error('Unused forced trig entries');
const geometry=Object.fromEntries(['lobes','liquid','iceCores','summits','foundations'].map(key=>[key,result[key]]));
const rng=result.rng.map(row=>({initialSeed:row.initialSeed,count:row.words.length,sha256:createHash('sha256').update(new Uint8Array(new Uint32Array(row.words).buffer)).digest('hex')}));
const report={runtime:{node:process.versions.node,bun:process.versions.bun??null,v8:process.versions.v8,jsc:process.versions.webkit??null},scope:'Primitive construction only; return before rasterization/detail/bake. No new scalar/neighbor/density samples.',forcedTrigFrom:forceFrom??null,primitiveCount:geometry.lobes.length,geometry,contractions:result.contractions,rng,trig};
writeFileSync(output,gzipSync(JSON.stringify(report,null,2)+'\n',{mtime:0}));
console.log(JSON.stringify({output,runtime:report.runtime,primitiveCount:report.primitiveCount,trigCalls:trig.length,forced:Boolean(forced)}));
