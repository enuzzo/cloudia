"""Analyze captured primitive-prefix outputs; no generator, density or GPU call."""
from pathlib import Path
from collections import Counter
import difflib
import gzip
import hashlib
import json
import struct

BASE = Path(__file__).resolve().parent
OLD = Path('/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle14/near-light')
FROZEN = Path('/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle15/secondary-hierarchy')
def load(name):
    return json.loads(gzip.decompress((BASE / (name + '.json.gz')).read_bytes()))
def sha(data):
    return hashlib.sha256(data).hexdigest()
old = load('old-primitive-metadata')
saved = load('baseline10493-trace72')['geometry']
node, bun = load('node'), load('bun')
node_bun, bun_node = load('node-forced-bun'), load('bun-forced-node')
assert saved['pre'] == saved['post'] == node['geometry']['lobes']
assert old == bun['geometry'] == node_bun['geometry']
assert node['geometry'] == bun_node['geometry']
assert node['rng'] == bun['rng'] == node_bun['rng'] == bun_node['rng']
assert node['contractions'] == bun['contractions'] == node_bun['contractions'] == bun_node['contractions']
assert len(old['lobes']) == len(saved['pre']) == 2589
for name in ['liquid','iceCores','summits','foundations']:
    assert node['geometry'][name] == bun['geometry'][name]
changes, components = [], Counter()
float32_changes = 0
for index, (a,b) in enumerate(zip(old['lobes'],saved['pre'])):
    assert len(a) == len(b)
    row = []
    for channel, (x,y) in enumerate(zip(a,b)):
        if x != y:
            assert channel < 3, 'Unexpected radius/blend difference'
            row.append(dict(component=['x','y','z'][channel], old=x, baseline10493=y, delta=y-x))
            components[['x','y','z'][channel]] += 1
        float32_changes += struct.pack('<f',x) != struct.pack('<f',y)
    if row:
        changes.append(dict(index=index, old=a, baseline10493=b, differences=row))
trig = []
assert len(node['trig']) == len(bun['trig']) == 12666
for index,(a,b) in enumerate(zip(node['trig'],bun['trig'])):
    assert a['name'] == b['name'] and a['input'] == b['input']
    if a['output'] != b['output']:
        trig.append(dict(index=index,name=a['name'],input=a['input'],node=a['output'],bun=b['output'],delta=b['output']-a['output']))
old_source = (OLD / 'source-snapshots/volume.ts').read_text()
new_source = (FROZEN / 'baseline-source/src/cumulonimbus/volume.ts').read_text()
def prefix(source):
    return source[source.index('export function generateVolume('):source.index('  // Rasterize lobes')]
assert prefix(old_source) == prefix(new_source)
(BASE / 'source-volume.diff').write_text(''.join(difflib.unified_diff(old_source.splitlines(keepends=True),new_source.splitlines(keepends=True),fromfile='frozen08c/volume.ts',tofile='baseline10493/volume.ts',n=4)))
for name,text in [('volume08c.ts',old_source),('volume10493.ts',new_source)]:
    (BASE / (name+'.gz')).write_bytes(gzip.compress(text.encode(),mtime=0))
for name,value in [('primitive-diff',changes),('trig-diff',trig)]:
    (BASE / (name+'.json.gz')).write_bytes(gzip.compress((json.dumps(value,indent=2)+'\n').encode(),mtime=0))
inputs = [OLD/'carving-causality.json',OLD/'geometry-scalar.ts',OLD/'source-snapshots/volume.ts',FROZEN/'geometry-traces.json.gz',FROZEN/'baseline-source/src/cumulonimbus/volume.ts',FROZEN/'diagnostics/baseline.mjs',BASE/'geometry-prefix.mjs',BASE/'run-prefix.mjs']
input_hashes = {str(p):dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in inputs}
summary = dict(status='CAUSALLY_EXPLAINED',cause='Different Math.sin/Math.cos rounding between Bun1.3.11 and Node26.11.0; reciprocal replay of only those outputs accounts for every differing primitive component',sourceScope='seed72/congestus; identical authored primitive-construction prefix in08c and10493, only later sheared shoulder code differs',primitiveCount=2589,changedPrimitiveTuples=len(changes),changedComponents=dict(components),maxAbsCoordinateDifferenceKm=max(abs(d['delta']) for r in changes for d in r['differences']),radiusOrBlendDifferences=0,componentDifferencesAfterFloat32Projection=float32_changes,parentArraysExact=True,orderAndShapePreserved=True,trigCalls=12666,differentTrigResults=len(trig),maxAbsTrigDifference=max(abs(r['delta']) for r in trig),sameTrigArgumentsAndOrder=True,reciprocalChecks=dict(nodeEqualsSaved10493=True,bunEqualsOld08cAllFiveArrays=True,nodeWithBunTrigEqualsBunAllFiveArrays=True,bunWithNodeTrigEqualsNodeAllFiveArrays=True,rngAllFourExact=True,contractionsAllFourExact=True),runtimes=dict(node=node['runtime'],bun=bun['runtime']),inputHashes=input_hashes,limits=['No density, raw-U, rasterization, detail or light bake was executed','Float32 projection of primitive coordinates is diagnostic only; generator evaluates double precision before per-union f32 stores','Full256 output-byte equality does not establish equality of every preclamp scalar','No neighboring-node guard probe, new model, renderer or FPS run','Bun process.versions.node/v8 are compatibility metadata; runtime here is Bun1.3.11, not Node'],nextRequirement='Use one chosen runtime and same baseline primitive set for both old and candidate scalar evaluation, then verify cached original bytes before any further guard qualification')
(BASE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({key:value for key,value in summary.items() if key not in ['inputHashes','runtimes','limits']},indent=2))
