# Provenienza delle primitive seed 72: differenza spiegata

**La mancata uguaglianza esatta è interamente riprodotta dai diversi arrotondamenti di `Math.sin`/`Math.cos` nei runtime Bun 1.3.11 e Node 26.11.0.** Non è necessario cambiare ordine, parametri o riferimenti delle primitive per ottenere i due insiemi salvati.

Il confronto riguarda il vecchio `primitiveMetadata` della diagnosi frozen `08c33cb` e il trace baseline `10493` del trial secondary-hierarchy. Entrambi contengono 2.589 primitive nello stesso ordine. Differiscono 299 tuple, con 333 componenti dei centri: X 145, Y 19, Z 169. Differenza assoluta massima `4.440892098500626e-16` km; raggi e blend sono identici. Liquid, iceCores, summits e foundations coincidono esattamente. Anche la proiezione dei componenti a float32 coincide, ma questa sola osservazione non prova l'identità del successivo raster.

Il prefisso autoriale di `generateVolume`, dall'ingresso fino alla rasterizzazione, è testualmente identico nei due sorgenti. La differenza di codice è l'importazione e il successivo ramo della spalla inclinata, condizionato alla famiglia sheared; seed 72 è congestus.

## Controprova causale

È stato usato lo **stesso bundle JavaScript diagnostico baseline 10493**, con una sola uscita aggiunta prima di rasterizzazione, dettaglio o bake. Sono stati eseguiti soltanto i primitivi, senza campionare densità o vicinati.

| Esecuzione dello stesso prefisso | Uguaglianza esatta |
|---|---|
| Node 26.11.0 | Trace baseline 10493 salvato |
| Bun 1.3.11 | Tutti i cinque array del vecchio metadata 08c |
| Node con i soli risultati sin/cos acquisiti da Bun | Tutti i cinque array Bun/08c |
| Bun con i soli risultati sin/cos acquisiti da Node | Tutti i cinque array Node/10493 |

Le 12.666 chiamate trigonometriche hanno stessi argomenti e stesso ordine. In 521 casi i risultati differiscono, al massimo di `1.1102230246251565e-16`. Il replay reciproco sostituisce soltanto tali risultati, controllando ogni nome e argomento. Tutte le differenze geometriche si trasferiscono esattamente con essi. Conteggi e hash dei flussi RNG, nonché fattori di contrazione, sono identici nelle quattro esecuzioni.

`summary.json` contiene input hash, conteggi e limiti; i quattro output completi, i due estratti originali e le liste integrali delle differenze sono conservati gzip. `source-volume.diff` conserva il diff autoriale; i due sorgenti e il bundle baseline originale sono preservati lossless. `analyze.py` ricontrolla i dati acquisiti senza eseguire primitive o densità.

## Conseguenza operativa e limiti

Per la prossima estrazione scalare si dovranno usare **un unico runtime e le stesse primitive baseline per vecchio e candidato**, verificando prima i byte originali della cache. La scelta proposta è Node 26.11.0 e il prefisso baseline 10493, che riproducono il trace già salvato.

La spiegazione elimina l'ambiguità di provenienza degli array. Non dimostra uguaglianza di ogni valore preclamp U, di ogni campo Float32 o di un'intera generazione a 256³. Le precedenti prove di output non vengono estese a questi stati interni. Non è stato avviato il probe dei vicinati, non è stata cambiata la guardia o il modello e nessun file del repository è stato modificato.
