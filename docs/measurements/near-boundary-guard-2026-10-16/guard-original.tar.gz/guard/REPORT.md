# Guardia dei vicinati: modello non promosso

**La guardia risulta coerente nei vicinati campionati, ma assorbe quasi tutto l'effetto utile ipotizzato. Il root ha deciso di non avviare un'app candidata.** Nessuna nuova variante o ulteriore probe: il modello fisso viene conservato come risultato non promosso. Forcing positivo, RGB e percorso GPU completo restano fuori da questa prova.

## Provenienza risolta prima del probe

La differenza fra vecchi metadata 08c e trace 10493 è stata spiegata e congelata in `../near-provenance-diff/`: il replay reciproco dei soli risultati sin/cos tra Bun 1.3.11 e Node 26.11.0 riproduce esattamente i due insiemi. Non si è dedotta l'uguaglianza di ogni valore preclamp dalla sola uguaglianza di output a 256³.

Per questa prova si usa **Node 26.11.0 con le stesse primitive baseline 10493 per vecchio e provvisorio**. Il prefisso termina prima di rasterizzazione, dettaglio e bake. Sono stati verificati prima i 252 byte della cache e tutti i byte del modello provvisorio già fissato: nessuna discrepanza. Sono stati quindi ricostruiti soltanto **209 vicini mancanti**, arrivando a 461 nodi; anche tutti i 461 byte originali coincidono con la cache verificata SHA256. Il modello I1 non è stato modificato.

## Guardia applicata e verso del confronto

Ogni nodo modificato influenza otto celle trilineari, con 27 corner distinti nel vicinato 3×3×3. Le 55 proposte toccano 176 celle distinte. Per ciascuna cella vengono confrontati **sia i vecchi byte sia i byte provvisori completi**, prima di qualunque revert, con il bound:

```text
flowAlphaHalfMax = .1800537109375
E(i) = .6950537109375 + .065*i
M(i) = 1 - .99766*i
threshold = E + float32(.002)*(1-E)/M + 2^-16
iceMax = smoothstep(iceStart,iceEnd,maxCornerY+.06+2^-14 km)
```

`float32(.002)` vale `0.0020000000949949026`. I due slack sono margini ingegneristici espliciti, fissati prima del conteggio; non sono una prova di conformità aritmetica di ogni GPU. Tutte le celle effettivamente esaminate sono liquide (`iceMax=0`), con il massimo locale già aumentato dal padding almeno 1,059602 km sotto iceStart. Il ramo con ghiaccio positivo non viene esercitato.

In tutte queste celle il minimo ammesso è **178/255**. Il peggior corner provvisorio di una cella accettata vale proprio 178/255; supera il bound padded `0.6956788623336558` di `0.002360353352618638`. La densità fine minima risultante dal bound non padded è `0.009790264239492245`, sopra `.002`.

Sopravvivono **12 dei 55 cambiamenti**, mentre 43 tornano ai byte originali. Venticinque proposte avevano già un corner vecchio insufficiente; 43 ne hanno uno provvisorio insufficiente. La guardia non viene ricalcolata contro vicini già ripristinati. È verificata la disuguaglianza `oldByte ≥ guardedByte ≥ provisionalByte`: qualsiasi revert alza soltanto i minimi e non può invalidare una proposta accettata contro il provvisorio completo.

## Effetto residuo sugli stessi campioni

I 13 punti front+5m sono esattamente invariati; tutti i 52 punti e i 394 campioni centrali restano positivi. Il raggio debole `(0.05,0.05)` resta invariato ai quattro livelli, incluse le vecchie τ1 e τ3.

| Nove UV JPEG validi, vecchie profondità | Baseline | Provvisorio senza guardia | Con guardia |
|---|---:|---:|---:|
| Densità media a τ1 | 0,685707 | 0,652230 | 0,685143 |
| CV densità a τ1 | 4,766201% | 6,338465% | 4,798513% |
| CV alla distanza media di contributo | 3,653275% | 5,356654% | 3,690451% |
| CV densità a τ3 | 7,626554% | 10,238678% | 7,626554% |

Nel centro, sulla sola finestra originale: tau totale `5.1222794 → 5.1214016`; attraversamento τ1 più profondo di 0,070938 m, τ3 di 0,060948 m. Il provvisorio senza guardia produceva rispettivamente 2,734632 e 4,738770 m. Non è stato cercato il nuovo termine del raggio e non è stata ricalcolata la luce.

Questi sono campioni di densità e integrali scalari, non misure di contrasto dell'immagine o bellezza. La variazione residua nei nove UV è troppo piccola per motivare ora un'app candidata: questa è la decisione operativa, non un nuovo giudizio visivo.

## Limiti della conclusione

Il certificato copre i vicinati dei 55 cambiamenti selezionati, per forcing0 e campi fini/flow mantenuti fissi. Non è stata costruita la selezione dell'intero volume né provata la frontiera globale, la dinamica, altre famiglie o forcing positivo. Gli 81 cambiamenti provvisori nei vicini aggiunti servono solo come minimi conservativi per i nodi esaminati: non sono una nuova proposta applicata al materiale. Non sono stati generati volumi 32³/64³/256³, build, test, immagini o prove GPU/FPS. Tutti i sorgenti del prodotto e gli archivi repo precedenti restano invariati.
