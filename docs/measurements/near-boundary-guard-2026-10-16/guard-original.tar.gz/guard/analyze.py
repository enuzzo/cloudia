"""One fixed 27-corner guard on55 existing changes. No bake or new model."""
from pathlib import Path
from collections import Counter
from itertools import product
import hashlib
import json
import math
import statistics
import struct

BASE = Path(__file__).resolve().parent
C15 = BASE.parent.parent / 'Cloudia-QA-2026-10-16-cycle15'
source = json.loads((BASE/'nodes.json').read_text())
stencils = json.loads((C15/'near-interior-stencils.json').read_text())
previous = json.loads((C15/'near-interior-next.json').read_text())
patches = json.loads((C15.parent/'Cloudia-QA-2026-10-16-cycle14/near-light/jpeg-comparison.json').read_text())
nodes = {tuple(n['index']):n for n in source['nodes']}
known = {key:n for key,n in nodes.items() if n['known252']}
changes = {key:n for key,n in known.items() if n['oldByte'] != n['newByte']}
assert len(known)==252 and len(changes)==55 and len(nodes)==461
assert source['allReconstructedOriginalByteMismatches']==0
valid_uv={tuple(s['uv']) for s in patches['samples'] if not s['excluded']}
assert len(valid_uv)==9

# Fixed arithmetic safety allowance, not tuned to the surviving count.
FLOW_HALF_MAX=0.1800537109375
FINE_CUTOFF=struct.unpack('<f',struct.pack('<f',.002))[0]
DENSITY_SLACK=2**-16
COORDINATE_SLACK_KM=2**-14
ice_start,ice_end=source['iceRange']
def smooth(a,b,v):
    t=max(0,min(1,(v-a)/(b-a)))
    return t*t*(3-2*t)
def key_add(a,b):return tuple(x+y for x,y in zip(a,b))
def cell_bound(low):
    max_warped_y=-.5+(low[1]+1+.5)/256*8.5
    max_local_y=max_warped_y+.06+COORDINATE_SLACK_KM
    ice=smooth(ice_start,ice_end,max_local_y)
    erosion=.515+FLOW_HALF_MAX+.065*ice
    material=1-.99766*ice
    exact=erosion+FINE_CUTOFF*(1-erosion)/material
    return dict(maxWarpedYKm=max_warped_y,maxLocalYKmPadded=max_local_y,iceMax=ice,erosionBound=erosion,materialMinimum=material,threshold=exact,paddedThreshold=exact+DENSITY_SLACK,minimumAllowedByte=math.floor((exact+DENSITY_SLACK)*255)+1)
node_guards=[]
all_cells={}
accepted=set()
for index,node in changes.items():
    cells=[]
    for offset in product([-1,0],repeat=3):
        low=key_add(index,offset)
        corners=[key_add(low,corner) for corner in product([0,1],repeat=3)]
        assert all(corner in nodes for corner in corners)
        bound=cell_bound(low)
        old_min=min(nodes[c]['oldByte'] for c in corners)
        provisional_min=min(nodes[c]['newByte'] for c in corners)
        assert provisional_min<=old_min
        row=dict(low=list(low),**bound,oldMinimumByte=old_min,provisionalMinimumByte=provisional_min,oldMargin=old_min/255-bound['paddedThreshold'],provisionalMargin=provisional_min/255-bound['paddedThreshold'])
        row['passes']=row['oldMargin']>0 and row['provisionalMargin']>0
        cells.append(row)
        all_cells[low]=row
    neighborhood={key_add(index,offset) for offset in product([-1,0,1],repeat=3)}
    assert len(neighborhood)==27 and neighborhood=={key_add(tuple(r['low']),corner) for r in cells for corner in product([0,1],repeat=3)}
    passes=all(r['passes'] for r in cells)
    if passes:accepted.add(index)
    node_guards.append(dict(index=list(index),oldByte=node['oldByte'],provisionalByte=node['newByte'],accepted=passes,worstProvisionalMargin=min(r['provisionalMargin'] for r in cells),worstOldMargin=min(r['oldMargin'] for r in cells),cells=cells))

for key,node in nodes.items():
    node['guardedByte']=node['newByte'] if key in accepted else node['oldByte']
    assert node['oldByte']>=node['guardedByte']>=node['newByte']
for row in node_guards:
    if row['accepted']:
        for cell in row['cells']:
            corners=[key_add(tuple(cell['low']),off) for off in product([0,1],repeat=3)]
            assert min(nodes[c]['guardedByte']/255 for c in corners)>cell['paddedThreshold']

def js_sum(values):
    value=0
    for item in values:value+=item
    return value
def sample(stencil,old_macro,old_rho):
    assert 0<old_rho<1
    assert js_sum(c['weight']*nodes[tuple(c['index'])]['oldByte']/255 for c in stencil)==old_macro
    erosion=(old_macro-old_rho)/(1-old_rho)
    result=dict(oldMacro=old_macro,oldDensity=old_rho)
    for variant,field in [('provisional','newByte'),('guarded','guardedByte')]:
        macro=js_sum(c['weight']*nodes[tuple(c['index'])][field]/255 for c in stencil)
        density=old_rho if macro==old_macro else max(0,min(1,(macro-erosion)/(1-erosion)))
        if density<.002:density=0
        result[variant+'Macro']=macro
        result[variant+'Density']=density
    assert result['oldDensity']>=result['guardedDensity']-1e-15>=result['provisionalDensity']-1e-15
    return result
records=[dict(uv=r['uv'],label=r['label'],validJPEGPatch=tuple(r['uv']) in valid_uv,oldViewDistanceKm=r['viewDistanceKm'],**sample(r['stencil'],r['macro'],r['renderDensity'])) for r in stencils['records']]
center=[dict(distanceKm=r['distanceKm'],oldOpacityWeight=r['weight'],**sample(r['stencil'],r['macro'],r['rho'])) for r in stencils['centerPlateau']['trace']]
for old,row in zip(previous['records'],records):
    assert old['newRenderDensity']==row['provisionalDensity']
    assert old['newMacro']==row['provisionalMacro']

def stats(values):
    mean=statistics.mean(values)
    std=statistics.pstdev(values)
    return dict(n=len(values),min=min(values),max=max(values),mean=mean,standardDeviation=std,cvPercent=std/mean*100)
def summary(rows):
    return dict(samples=len(rows),**{variant:dict(density=stats([r[variant+'Density'] for r in rows]),zeroDensitySamples=sum(r[variant+'Density']==0 for r in rows),exactlyUnchanged=sum(r[variant+'Macro']==r['oldMacro'] and r[variant+'Density']==r['oldDensity'] for r in rows)) for variant in ['old','provisional','guarded']})
labels=['first-plus5m','view-tau1','mean-opacity-distance','view-tau3']
summary13={label:summary([r for r in records if r['label']==label]) for label in labels}
summary9={label:summary([r for r in records if r['label']==label and r['validJPEGPatch']]) for label in labels}
def path(variant):
    tau=0
    crossing={str(level):None for level in [1,3,5]}
    for r in center:
        rho=r[variant+'Density'];increment=rho*18*.001
        for level in [1,3,5]:
            if crossing[str(level)] is None and tau+increment>=level:
                crossing[str(level)]=r['distanceKm']-.0005+(level-tau)/(rho*18)
        tau+=increment
    return dict(tauWithinOriginalWindow=tau,opacityWithinOriginalWindow=-math.expm1(-tau),crossingsKm=crossing)
paths={variant:path(variant) for variant in ['old','provisional','guarded']}
accepted_cells=[c for row in node_guards if row['accepted'] for c in row['cells']]
if accepted_cells:
    worst=min(accepted_cells,key=lambda c:c['provisionalMargin'])
    worst=dict(worst,strictPositiveFineDensityLowerBound=(worst['provisionalMinimumByte']/255-worst['erosionBound'])/(1-worst['erosionBound'])*worst['materialMinimum'])
else:worst=None
parameters=dict(forcing=0,flowAlphaHalfMaximum=FLOW_HALF_MAX,cutoffF32=FINE_CUTOFF,normalizedDensitySlack=DENSITY_SLACK,coordinateSlackKm=COORDINATE_SLACK_KM,erosionFormula='.6950537109375+.065*i',materialFormula='1-.99766*i',thresholdFormula='E+cutoffF32*(1-E)/M+normalizedDensitySlack',scope='3x3x3 old and full provisional corners in8 adjacent trilinear cells per original changed node; finite arithmetic slack is explicit engineering allowance, not cross-adapter GPU conformance proof')
node_summary=dict(knownNodes=252,missingNeighborsRecovered=source['missingNeighborsRecovered'],totalReconstructedNodes=len(nodes),allOriginalBytesMatchCache=True,allKnownProvisionalBytesMatchPriorModel=True,originalChangedKnownNodes=55,acceptedKnownChanges=len(accepted),revertedKnownChanges=55-len(accepted),knownByteChangesOutsideAcceptedSet=0,uniqueAffectedCells=len(all_cells),maxIceAcrossCheckedCells=max(c['iceMax'] for c in all_cells.values()),minimumPaddedLocalYGapToIceStartKm=min(ice_start-c['maxLocalYKmPadded'] for c in all_cells.values()),requiredByteRange=[min(c['minimumAllowedByte'] for c in all_cells.values()),max(c['minimumAllowedByte'] for c in all_cells.values())],provisionalChangesInRecoveredNeighbors=sum(n['oldByte']!=n['newByte'] for n in nodes.values() if not n['known252']),rejectedByOldCorner=sum(any(c['oldMargin']<=0 for c in r['cells']) for r in node_guards),rejectedByProvisionalCorner=sum(any(c['provisionalMargin']<=0 for c in r['cells']) for r in node_guards),monotoneRevertCheck=True,worstAcceptedCell=worst)
inputs=[BASE/'nodes.json',BASE/'collect.mjs',BASE/'scalar-baseline.mjs',Path(__file__).resolve(),C15/'near-interior-stencils.json',C15/'near-interior-next.json',C15/'near-interior-boundary-guard-root.md',BASE.parent/'near-provenance-diff/manifest.json']
hashes={str(p):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in inputs}
report=dict(status='LOCAL_GUARD_EVALUATED_NOT_PRODUCT_OR_GPU_QUALIFIED',parameters=parameters,nodeSummary=node_summary,summaries13Rays=summary13,summaries9ValidPatches=summary9,weakRayRecords=[r for r in records if r['uv']==[.05,.05]],centerSummary=summary(center),centerPaths=paths,inputHashes=hashes,nodeGuards=node_guards,records=records,centerRecords=center,nodes=list(nodes.values()),limitations=['Only55 original changed nodes qualified; no full-volume selection or global boundary qualification','Same Node26 baseline10493 geometry for both sides;461 original cache bytes reproduced before guard','8-cell proof is conditional on fixed fine/flow fields, forcing0 and the stated finite-precision allowance; no native GPU execution','Only seed72 neighborhood sampled; all checked cells liquid, so nonzero-ice branch not exercised','Old tau coordinates and fine erosion retained; center paths end at original last sample, not new ray termination','No new RGB/image, coherent light/rain bake, dynamics, forcing>0, all-seed or performance claim'])
(BASE/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(nodeSummary=node_summary,centerPaths=paths,summary9={label:{v:r[v]['density'] for v in ['old','provisional','guarded']} for label,r in summary9.items()},summary13={label:{v:dict(mean=r[v]['density']['mean'],unchanged=r[v]['exactlyUnchanged'],zeros=r[v]['zeroDensitySamples']) for v in ['old','provisional','guarded']} for label,r in summary13.items()}),indent=2))
