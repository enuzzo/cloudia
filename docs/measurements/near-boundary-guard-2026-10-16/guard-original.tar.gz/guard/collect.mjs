// Baseline10493/Node26: original252 nodes plus ONLY missing neighbors of55 changes.
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {generateVolume,evaluateAuthoredVoxel,iceHeights} from './scalar-baseline.mjs';
const base=import.meta.dirname;
const cycle15='/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle15';
const old=JSON.parse(readFileSync(cycle15+'/near-interior-stencils.json','utf8'));
const model=JSON.parse(readFileSync(cycle15+'/near-interior-next.json','utf8'));
const cache='/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle10/rain-work/data/macro-rgba8.bin';
const bytes=readFileSync(cache),sha=v=>createHash('sha256').update(v).digest('hex');
if(bytes.length!==old.inputChecks['macro-rgba8.bin'].bytes||sha(bytes)!==old.inputChecks['macro-rgba8.bin'].sha256)throw Error('Original macro cache SHA mismatch');
const geometry=generateVolume(8,72); // Early return before any raster/detail/bake.
const key=i=>i.join(',');
const clamp=x=>Math.max(0,Math.min(1,x));
const smooth=(a,b,x)=>{const t=clamp((x-a)/(b-a));return t*t*(3-2*t);};
const nodes=new Map();
let originalMismatches=0;
function collect(index,known){
  if(nodes.has(key(index)))return nodes.get(key(index));
  const scalar=evaluateAuthoredVoxel(geometry,index,256,72);
  if(scalar.ice!==0||scalar.point[1]<=.96)throw Error('Liquid/baseFade assumption not covered at '+key(index));
  const actualByte=bytes[((index[2]*256+index[1])*256+index[0])*4];
  if(scalar.predictedByte!==actualByte)originalMismatches++;
  const oldRaw=scalar.raw,gate=smooth(1,1.25,oldRaw);
  const newInterior=scalar.interior+.1*smooth(.04,.28,scalar.field)*gate;
  const newRaw=(scalar.field+scalar.erosion*scalar.erosionScale*newInterior-.025)*10;
  const newByte=Math.round(Math.fround(clamp(newRaw)*(.65+.35*scalar.noise2))*255);
  if(newByte>actualByte)throw Error('Model is not monotone at '+key(index));
  const row={index,point:scalar.point,known252:known,field:scalar.field,oldRaw,newRaw,oldByte:actualByte,newByte,gate,predictedByte:scalar.predictedByte,oldSaturated:oldRaw>=1,newSaturated:newRaw>=1};
  nodes.set(key(index),row);return row;
}
for(const node of old.nodes)collect(node.index,true);
if(nodes.size!==252||originalMismatches!==0)throw Error('Original252 byte replay failed');
const expected=new Map(model.nodes.map(row=>[key(row.index),row]));
const originalChanged=[...nodes.values()].filter(row=>row.oldByte!==row.newByte);
if(originalChanged.length!==55)throw Error('Original changed-byte set is not55');
for(const row of nodes.values()){
  const previous=expected.get(key(row.index));
  if(!previous||row.oldByte!==previous.oldByte||row.newByte!==previous.newByte)throw Error('Prior fixed-model byte replay differs at '+key(row.index));
}
for(const row of originalChanged)for(let z=-1;z<=1;z++)for(let y=-1;y<=1;y++)for(let x=-1;x<=1;x++){
  const index=[row.index[0]+x,row.index[1]+y,row.index[2]+z];
  if(index.some(n=>n<=0||n>=255))throw Error('Texture-edge case outside audit scope');
  collect(index,false);
}
if(originalMismatches!==0)throw Error('Neighbor original cache byte mismatch');
const output={runtime:process.version,baselineCommit:'10493afa7f6d90389c39e17b2cad79397dfdac01',sourceScope:'Same baseline10493 primitives and scalar evaluator in Node26 for old and provisional candidate. Primitive prefix returns before rasterization. Model fixed; no full-volume generation.',cache:{bytes:bytes.length,sha256:sha(bytes)},originalKnownNodes:252,originalKnownByteMismatches:0,originalCandidateByteMismatches:0,changedKnownNodes:55,totalNodes:nodes.size,missingNeighborsRecovered:nodes.size-252,allReconstructedOriginalByteMismatches:originalMismatches,iceRange:iceHeights(72),nodes:[...nodes.values()]};
writeFileSync(base+'/nodes.json',JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({runtime:output.runtime,originalKnownNodes:252,changedKnownNodes:55,totalNodes:output.totalNodes,missingNeighborsRecovered:output.missingNeighborsRecovered,originalMismatches,iceRange:output.iceRange}));
