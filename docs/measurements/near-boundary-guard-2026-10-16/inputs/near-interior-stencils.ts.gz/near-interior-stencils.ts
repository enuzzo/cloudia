import {generateVolume as primitiveSet,evaluateAuthoredVoxel} from "/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle14/near-light/geometry-scalar";
/** Read-only CPU audit of a verified existing cloud cache. No generation/render. */
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {sampleCloudDensity,sampleDetail,materialExtinction,BOUNDS_MIN,BOUNDS_SIZE} from "/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle14/near-light/source-snapshots/volume";
import {writeFilteredSourcePosition} from "/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle14/near-light/motionField-runtime";
import {solarDirection} from "/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle14/near-light/source-snapshots/sun";
import {atmosphereLighting,skyRadiance} from "/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle14/near-light/source-snapshots/atmosphere";
const dir="/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle14/near-light",base='/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle10/rain-work/data';
const sha=(v:Uint8Array|string)=>createHash('sha256').update(v).digest('hex');
const input=JSON.parse(readFileSync(base+'/manifest.json','utf8')),frozen=JSON.parse(readFileSync(dir+'/snapshot-manifest.json','utf8'));
for(const [path,proof] of Object.entries(frozen.files) as any){if(sha(readFileSync(dir+'/source-snapshots/'+path.split('/').at(-1)))!==proof.sha256)throw Error('Source mismatch '+path);}
for(const name of ['volume','motion','motionField','light'])if(frozen.files['src/cumulonimbus/'+name+'.ts'].sha256!==input.sourceHashesAfter[name])throw Error('Material cache source mismatch '+name);
const dataChecks:any={};
function binary(name:string){const data=readFileSync(base+'/'+name),proof=input.files[name];if(data.byteLength!==proof.bytes||sha(data)!==proof.sha256)throw Error('Input hash '+name);dataChecks[name]=proof;return data;}
const volume={size:256,data:binary('macro-rgba8.bin')},detail={size:128,data:binary('detail-rgba8.bin')},flowBytes=binary('flow-rgba16f.bin');
const field=new Uint16Array(flowBytes.buffer,flowBytes.byteOffset,flowBytes.byteLength/2),state=input.state,iceRange=input.iceRange;
const time=60,windStrength=.55,phase=(72%71)/71*.35;
const wind=[windStrength*(.52+.23*Math.sin(time*.055+phase*3)),windStrength*.26*Math.sin(time*.031+.6)];
const drift=[windStrength*(.32*Math.sin(time*.027)+.11*Math.sin(time*.071)),Math.sin(time*.04)*.015,0];
const target=[-.28995623264629566,2.4981598424383944,-.02734375],surface=1.4795113574194039;
const origin=[target[0],target[1],target[2]+surface],aspect=1280/720,tanFov=.2867;
const sun=solarDirection(0),lighting=atmosphereLighting(sun,1,0);
const clamp=(x:number,a=0,b=1)=>Math.max(a,Math.min(b,x));
const smooth=(a:number,b:number,x:number)=>{const t=clamp((x-a)/(b-a));return t*t*(3-2*t);};
const norm=(p:number[])=>{const l=Math.hypot(...p);return p.map(v=>v/l);};
const q=new Float64Array(4);let evaluations=0;
function material(p:number[],distance:number,micro=true){
 evaluations++;writeFilteredSourcePosition(p.map((v,i)=>v-drift[i]),state,iceRange,wind,field,q);
 const local=[q[0],q[1],q[2]],coord=local.map((v,i)=>(v-BOUNDS_MIN[i])/BOUNDS_SIZE[i]);
 if(coord.some(v=>v<0||v>1))return {rho:0,sigma:0,ice:0,local,coord,micro:0,light:[0,0,0]};
 const ice=smooth(iceRange[0],iceRange[1],q[1]),weight=(1-smooth(.08,.3,distance))*(1-ice);
 const microErosion=micro&&weight>.001?weight*(1-sampleDetail(detail,q[0]*8,q[1]*8,q[2]*8,2))*.055:0;
 let rho=sampleCloudDensity(volume,detail,q[0],q[1],q[2],ice,q[3]+microErosion);if(rho<.002)rho=0;
 const light=[1,2,3].map(c=>sampleDetail(volume,coord[0],coord[1],coord[2],c,false)*16);
 return {rho,sigma:rho*materialExtinction(ice),ice,local,coord,micro:microErosion,light};
}
const film=(v:number)=>clamp(v*(2.51*v+.03)/(v*(2.43*v+.59)+.14));
const srgb=(v:number)=>v<=.0031308?12.92*v:1.055*v**(1/2.4)-.055;
const luma=(c:number[])=>c[0]*.2126+c[1]*.7152+c[2]*.0722;
function source(m:ReturnType<typeof material>,ray:number[],distance:number){
 const mu=ray.reduce((s,v,i)=>s+v*sun[i],0),forward=(1-.68**2)/Math.max(1+.68**2-2*.68*mu,.04)**1.5;
 const back=(1-.25**2)/Math.max(1+.25**2+2*.25*mu,.04)**1.5,phase=.45+.55*(.82*forward+.18*back);
 const solar=Math.exp(-m.light[0]),sky=Math.exp(-m.light[2]);
 const direct=lighting.solar.map(v=>v*1.65*solar*phase);
 const ambient=lighting.ambient.map(v=>v*(.18+.82*sky**.35));
 const multiple=[1,.985,.95].map((v,i)=>v*(.27*Math.exp(-m.light[0]*.45)+.10*Math.exp(-m.light[0]*.18))+[.028,.032,.04][i]);
 const total=direct.map((v,i)=>v+ambient[i]+multiple[i]);
 return {direct,ambient,multiple,total,phase,solar,sky,aerial:Math.exp(-.0035*distance)};
}
function stats(values:number[]){const n=values.length,mean=values.reduce((a,b)=>a+b,0)/n;return {n,min:Math.min(...values),max:Math.max(...values),mean,standardDeviation:Math.sqrt(values.reduce((s,v)=>s+(v-mean)**2,0)/n),rangePercentOfMean:(Math.max(...values)-Math.min(...values))/mean*100};}
function integrate(uv:number[],micro=true,adaptive=false,step=.001){
 const ray=norm([(uv[0]*2-1)*aspect*tanFov,(1-uv[1]*2)*tanFov,-1]);
 const sky=skyRadiance(ray,sun,1),rgb=[0,0,0],components={direct:[0,0,0],ambient:[0,0,0],multiple:[0,0,0]};
 const first:any={rho002:null,rho025:null,tau1:null,tau3:null,tau5:null};
 let tau=0,T=1,weight=0,weightedDistance=0,samples=0,weightedRho=0,weightedSunTau=0,weightedSkyTau=0;
 const range={rho:[Infinity,-Infinity],sunTau:[Infinity,-Infinity],skyTau:[Infinity,-Infinity],source:[Infinity,-Infinity]};
 const checkpoints:any[]=[];
 let t=0;
 while(t<2&&T>=.006){
  const ds=Math.min(adaptive?Math.min(7/384,Math.max(.0015,t*.008)):step,2-t),at=adaptive?t:t+ds/2;
  const position=origin.map((v,i)=>v+ray[i]*at),m=material(position,at,micro);samples++;
  if(m.rho>0&&first.rho002===null)first.rho002=t;
  if(m.rho>.025&&first.rho025===null)first.rho025=t;
  const before=tau;const dTau=m.sigma*ds;tau+=dTau;
  for(const level of [1,3,5])if(tau>=level&&first['tau'+level]===null)first['tau'+level]=t+(level-before)/Math.max(1e-15,m.sigma);
  if(m.rho>0){
   const s=source(m,ray,at),w=T*(-Math.expm1(-dTau));weight+=w;weightedDistance+=w*at;
   weightedRho+=w*m.rho;weightedSunTau+=w*m.light[0];weightedSkyTau+=w*m.light[2];
   for(let c=0;c<3;c++){
    rgb[c]+=w*(sky[c]+(s.total[c]-sky[c])*s.aerial);
    for(const kind of ['direct','ambient','multiple'] as const)components[kind][c]+=w*s[kind][c];
   }
   if(w>1e-6){for(const [name,value] of [['rho',m.rho],['sunTau',m.light[0]],['skyTau',m.light[2]],['source',luma(s.total)]] as const){range[name][0]=Math.min(range[name][0],value);range[name][1]=Math.max(range[name][1],value);}}
  }
  T=Math.exp(-tau);t+=ds;
 }
 for(const level of [.1,.2,.3,.4,.5]){const p=origin.map((v,i)=>v+ray[i]*level),m=material(p,level,micro),s=source(m,ray,level);checkpoints.push({distanceKm:level,position:p,...m,source:s});}
 for(let c=0;c<3;c++)rgb[c]+=sky[c]*T;
 const mapped=rgb.map(film),display=mapped.map(srgb);
 return {uv,ray,micro,adaptive,stepKm:adaptive?null:step,first,samples,endKm:t,opacity:1-T,residual:T,rgb,film:mapped,srgb:display,display8:display.map(v=>v*255),luminance:luma(rgb),filmLuminance:luma(mapped),srgbLuminance:luma(display),
  components,weighted:{distanceKm:weightedDistance/weight,rho:weightedRho/weight,sunTau:weightedSunTau/weight,skyTau:weightedSkyTau/weight},range,checkpoints};
}

const existing=JSON.parse(readFileSync(dir+'/near-light.json','utf8'));
const geometry=primitiveSet(8,72) as any;
const scalarCache=new Map<string,any>();let macroMismatch=0,comparedNodes=0;
function scalar(index:number[]){
 const key=index.join(',');if(scalarCache.has(key))return scalarCache.get(key);
 const result=evaluateAuthoredVoxel(geometry,index,256,72);
 const at=((index[2]*256+index[1])*256+index[0])*4,actualByte=volume.data[at];
 result.actualByte=actualByte;result.byteDifference=result.predictedByte-actualByte;
 comparedNodes++;if(result.byteDifference!==0)macroMismatch++;
 scalarCache.set(key,result);return result;
}
const records:any[]=[];
for(const ray of existing.rays){
 for(const sample of [{label:'first-plus5m',distance:ray.first.rho002+.005},{label:'view-tau1',distance:ray.first.tau1},{label:'mean-opacity-distance',distance:ray.weighted.distanceKm},{label:'view-tau3',distance:ray.first.tau3}]){
  const position=origin.map((v,i)=>v+ray.ray[i]*sample.distance),m=material(position,sample.distance,true),local=m.local;
  const fine=[0,1,2].map(c=>sampleDetail(detail,local[0]*.3,local[1]*.3,local[2]*.3,c));
  const warp=[(fine[1]-.5)*(.16-.08*m.ice),(fine[2]-.5)*(.12-.1*m.ice),(fine[0]-.5)*(.16-.06*m.ice)];
  const warped=local.map((v,i)=>v+warp[i]);
  const normalized=warped.map((v,i)=>(v-BOUNDS_MIN[i])/BOUNDS_SIZE[i]);
  const texel=normalized.map(v=>clamp(v)*256-.5),lo=texel.map(Math.floor),fraction=texel.map((v,i)=>v-lo[i]);
  const stencil:any[]=[];
  for(let dz=0;dz<2;dz++)for(let dy=0;dy<2;dy++)for(let dx=0;dx<2;dx++){
   const index=[dx,dy,dz].map((v,i)=>Math.max(0,Math.min(255,lo[i]+v)));
   const weight=(dx?fraction[0]:1-fraction[0])*(dy?fraction[1]:1-fraction[1])*(dz?fraction[2]:1-fraction[2]);
   stencil.push({index,weight,scalar:scalar(index)});
  }
  const weighted=(name:string)=>stencil.reduce((sum,c)=>sum+c.weight*c.scalar[name],0);
  const macro=stencil.reduce((sum,c)=>sum+c.weight*c.scalar.actualByte/255,0);
  const macroWithoutInterior=stencil.reduce((sum,c)=>sum+c.weight*Math.round(c.scalar.withoutInterior*255)/255,0);
  records.push({uv:ray.uv,label:sample.label,viewDistanceKm:sample.distance,position,local,warped,microErosion:m.micro,fine,renderDensity:m.rho,
   macro,macroWithoutInterior,deltaMacroWithoutInterior:macroWithoutInterior-macro,
   diagnostic:{field:weighted('field'),parentField:weighted('parentField'),decorationFieldGain:weighted('decorationFieldGain'),interior:weighted('interior'),erosion:weighted('erosion'),erosionScale:weighted('erosionScale'),carving:weighted('carving'),carvingWithoutInterior:weighted('carvingWithoutInterior'),raw:weighted('raw'),saturatedStencilWeight:stencil.reduce((sum,c)=>sum+c.weight*(c.scalar.saturated?1:0),0),parentWinnerStencilWeight:stencil.reduce((sum,c)=>sum+c.weight*(c.scalar.bestPrimitiveKind==='parent'?1:0),0)},stencil});
 }
}
const summaries=Object.fromEntries(['first-plus5m','view-tau1','mean-opacity-distance','view-tau3'].map(label=>{
 const points=records.filter(p=>p.label===label);
 return [label,Object.fromEntries(['macro','renderDensity','deltaMacroWithoutInterior','field','parentField','decorationFieldGain','interior','carving','carvingWithoutInterior','raw','saturatedStencilWeight','parentWinnerStencilWeight'].map(name=>[name,stats(points.map(p=>name in p?p[name]:p.diagnostic[name]))]))];
}));

const centerRay=existing.rays.find((r:any)=>r.uv[0]===.5&&r.uv[1]===.5);
let tau=0,weightTotal=0,weightedSaturation=0,weightedInterior=0,weightedActive=0;
const centerTrace:any[]=[];
for(let t=0;t<2&&Math.exp(-tau)>=.006;t+=.001){
 const at=t+.0005,position=origin.map((v,i)=>v+centerRay.ray[i]*at),m=material(position,at,true);
 if(m.rho<=0)continue;
 const fine=[0,1,2].map(c=>sampleDetail(detail,m.local[0]*.3,m.local[1]*.3,m.local[2]*.3,c));
 const warp=[(fine[1]-.5)*(.16-.08*m.ice),(fine[2]-.5)*(.12-.1*m.ice),(fine[0]-.5)*(.16-.06*m.ice)];
 const texel=m.local.map((v,i)=>clamp((v+warp[i]-BOUNDS_MIN[i])/BOUNDS_SIZE[i])*256-.5),lo=texel.map(Math.floor),fraction=texel.map((v,i)=>v-lo[i]);
 let saturated=0,active=0,interior=0;const stencil:any[]=[];
 for(let dz=0;dz<2;dz++)for(let dy=0;dy<2;dy++)for(let dx=0;dx<2;dx++){
  const index=[dx,dy,dz].map((v,i)=>Math.max(0,Math.min(255,lo[i]+v))),w=(dx?fraction[0]:1-fraction[0])*(dy?fraction[1]:1-fraction[1])*(dz?fraction[2]:1-fraction[2]);
  const node=scalar(index);stencil.push({index,weight:w});saturated+=w*(node.raw>=1?1:0);active+=w*(node.raw>0&&node.raw<1?1:0);interior+=w*node.interior;
 }
 const dTau=m.sigma*.001,w=Math.exp(-tau)*(-Math.expm1(-dTau));tau+=dTau;
 weightTotal+=w;weightedSaturation+=w*saturated;weightedInterior+=w*interior;weightedActive+=w*active;
 centerTrace.push({distanceKm:at,rho:m.rho,weight:w,saturatedStencilWeight:saturated,activeStencilWeight:active,interior,macro:stencil.reduce((sum,c)=>sum+c.weight*scalar(c.index).actualByte/255,0),stencil});
}
const centerPlateau={stepKm:.001,opacity:weightTotal,weightedSaturatedStencilFraction:weightedSaturation/weightTotal,weightedActiveStencilFraction:weightedActive/weightTotal,weightedInterior:weightedInterior/weightTotal,trace:centerTrace};
const centerTau1=records.find(p=>p.uv[0]===.5&&p.uv[1]===.5&&p.label==='view-tau1');
const desaturationThresholds=centerTau1.stencil.map((s:any)=>{
 const n=s.scalar,extraNegativeFieldKm=Math.max(0,(n.raw-1)/(10+n.ice*4));
 const fullLiquidErosionMagnitude=-n.erosion*n.erosionScale*(1-n.ice);
 return {index:s.index,weight:s.weight,currentInterior:n.interior,raw:n.raw,extraNegativeFieldKm,interiorToReachClampEdge:n.interior+extraNegativeFieldKm/fullLiquidErosionMagnitude};
});
const output={git:frozen.git,method:'Existing cached08c seed72 material only. Extracted primitive construction returns before rasterization, detail generation and light bake; geometry generated atsize8 only because geometry itself is resolution-independent. Reconstruct original Float32 smooth-union raster field and noise/carving/clamp at unique256-cubed voxel centers around the actual warped density samples, verify every reconstructed byte against existing macroR cache. No volume/cache generated. Four sampled depth locations per13rays; continuous field diagnostic summaries are trilinear averages of node diagnostics, not a stored GPU raw field. Counterfactual without interior attenuation is scalar-only, same existing noise; no modified texture/light bake/render or artistic claim.',geometryCounts:{parents:geometry.liquid.length+geometry.iceCores.length,lobes:geometry.lobes.length},inputChecks:dataChecks,comparedNodes,macroMismatch,summaries,records,centerPlateau,desaturationThresholds,nodes:[...scalarCache.values()]};
const previous=JSON.parse(readFileSync(dir+'/carving-causality.json','utf8'));
if(JSON.stringify(previous.records)!==JSON.stringify(records))throw Error('Existing52 records changed');
const legacyCenter=centerTrace.map(({macro,stencil,...record})=>record);
if(JSON.stringify(previous.centerPlateau.trace)!==JSON.stringify(legacyCenter))throw Error('Existing394 center positions/weights changed');
if(comparedNodes!==252||macroMismatch!==0)throw Error('Reconstructed252 byte guard failed');
writeFileSync("/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle15/near-interior-stencils.json",JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({existingRecords:records.length,existingCenterSamples:centerTrace.length,reconstructedNodes:comparedNodes,byteMismatches:macroMismatch,output:"/Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle15/near-interior-stencils.json"}));
