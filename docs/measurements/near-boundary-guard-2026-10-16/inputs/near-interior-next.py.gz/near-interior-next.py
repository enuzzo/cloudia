"""ONE fixed scalar counterfactual on existing frozen seed72 samples only.

No sweep, new field/noise, volume generation, light bake, image or GPU run.
"""
from pathlib import Path
import hashlib
import json
import math
import statistics
import struct

BASE = Path(__file__).resolve().parent
OLD = BASE.parent / 'Cloudia-QA-2026-10-16-cycle14' / 'near-light'
input_path = BASE / 'near-interior-stencils.json'
data = json.loads(input_path.read_text())
legacy = json.loads((OLD / 'carving-causality.json').read_text())
patches = json.loads((OLD / 'jpeg-comparison.json').read_text())
assert data['comparedNodes'] == len(data['nodes']) == 252 and data['macroMismatch'] == 0
assert data['records'] == legacy['records']
assert len(data['centerPlateau']['trace']) == len(legacy['centerPlateau']['trace']) == 394
valid_uv = {tuple(s['uv']) for s in patches['samples'] if not s['excluded']}
assert len(valid_uv) == 9

def clamp(v):
    return max(0, min(1, v))

def smooth(a, b, v):
    t = clamp((v - a) / (b - a))
    return t * t * (3 - 2 * t)

def f32(v):
    return struct.unpack('<f', struct.pack('<f', v))[0]

def js_sum(values):
    # Python 3.12+ sum may compensate float additions; JS reduce is sequential.
    value = 0
    for item in values:
        value += item
    return value

def byte(raw, node):
    return math.floor(f32(clamp(raw) * (.65 + .35 * node['noise2'])) * 255 + .5)

nodes = {}
for node in data['nodes']:
    assert node['ice'] == 0 and node['point'][1] > .96
    old_interior = 1 - .6 * smooth(.04, .28, node['field'])
    old_raw = (node['field'] + node['erosion'] * node['erosionScale'] * old_interior - .025) * 10
    old_byte = byte(old_raw, node)
    assert old_byte == node['actualByte'] == node['predictedByte']
    # Parameters fixed before running: previous +.1 carving-interior difference,
    # with a smooth gate wholly above the original clamp edge. No parameter fit.
    gate = smooth(1, 1.25, old_raw)
    new_interior = old_interior + .1 * smooth(.04, .28, node['field']) * gate
    new_raw = (node['field'] + node['erosion'] * node['erosionScale'] * new_interior - .025) * 10
    new_byte = byte(new_raw, node)
    assert new_byte <= old_byte
    if old_raw <= 1:
        assert gate == 0 and new_byte == old_byte
    key = ','.join(map(str, node['index']))
    nodes[key] = dict(index=node['index'], field=node['field'], existingNegativeErosion=node['erosion'], oldInterior=old_interior, newInterior=new_interior, gate=gate, oldRaw=old_raw, newRaw=new_raw, oldByte=old_byte, newByte=new_byte, oldSaturated=old_raw >= 1, newSaturated=new_raw >= 1)

def sample(stencil, old_macro, old_rho):
    assert 0 < old_rho < 1
    # Preserve JS evaluation order for the original cached byte interpolation.
    reconstructed = js_sum(item['weight'] * nodes[','.join(map(str, item['index']))]['oldByte'] / 255 for item in stencil)
    assert reconstructed == old_macro
    new_macro = js_sum(item['weight'] * nodes[','.join(map(str, item['index']))]['newByte'] / 255 for item in stencil)
    erosion = (old_macro - old_rho) / (1 - old_rho)
    new_rho = old_rho if new_macro == old_macro else clamp((new_macro - erosion) / (1 - erosion))
    if new_rho < .002:
        new_rho = 0
    assert new_rho <= old_rho + 1e-15
    return dict(oldMacro=old_macro, newMacro=new_macro, deltaMacro=new_macro-old_macro, oldRenderDensity=old_rho, newRenderDensity=new_rho, deltaRenderDensity=new_rho-old_rho, effectiveFineErosion=erosion, oldSaturatedStencilWeight=sum(item['weight'] * nodes[','.join(map(str, item['index']))]['oldSaturated'] for item in stencil), newSaturatedStencilWeight=sum(item['weight'] * nodes[','.join(map(str, item['index']))]['newSaturated'] for item in stencil), newZeroDensity=new_rho == 0)

records = []
for row in data['records']:
    records.append(dict(uv=row['uv'], validJPEGPatch=tuple(row['uv']) in valid_uv, label=row['label'], oldViewDistanceKm=row['viewDistanceKm'], **sample(row['stencil'], row['macro'], row['renderDensity'])))
center = []
for row in data['centerPlateau']['trace']:
    center.append(dict(distanceKm=row['distanceKm'], oldOpacityWeight=row['weight'], **sample(row['stencil'], row['macro'], row['rho'])))

def stats(values):
    return dict(n=len(values), min=min(values), max=max(values), mean=statistics.mean(values), standardDeviation=statistics.pstdev(values))

def summarize(rows):
    return dict(samples=len(rows), exactlyUnchanged=sum(r['deltaMacro'] == 0 and r['deltaRenderDensity'] == 0 for r in rows), zeroDensitySamples=sum(r['newZeroDensity'] for r in rows), **{key: stats([r[key] for r in rows]) for key in ['oldMacro','newMacro','oldRenderDensity','newRenderDensity','deltaRenderDensity','oldSaturatedStencilWeight','newSaturatedStencilWeight']})

labels = ['first-plus5m','view-tau1','mean-opacity-distance','view-tau3']
summary13 = {label:summarize([r for r in records if r['label']==label]) for label in labels}
summary9 = {label:summarize([r for r in records if r['label']==label and r['validJPEGPatch']]) for label in labels}

def center_tau(kind):
    tau = 0
    crossings = {str(level): None for level in [1,3,5]}
    for row in center:
        rho = row[kind]
        increment = rho * 18 * .001
        for level in [1,3,5]:
            if crossings[str(level)] is None and tau + increment >= level:
                crossings[str(level)] = row['distanceKm'] - .0005 + (level - tau) / (rho * 18)
        tau += increment
    return dict(tauWithinOriginalWindow=tau, opacityWithinOriginalWindow=-math.expm1(-tau), firstStoredDistanceKm=center[0]['distanceKm'], lastStoredDistanceKm=center[-1]['distanceKm'], crossingsKm=crossings)

center_summary = summarize(center)
center_summary['oldPath'] = center_tau('oldRenderDensity')
center_summary['newPath'] = center_tau('newRenderDensity')
weights = sum(row['oldOpacityWeight'] for row in center)
center_summary['oldOpacityWeightedMeanDensityBefore'] = sum(row['oldOpacityWeight'] * row['oldRenderDensity'] for row in center) / weights
center_summary['oldOpacityWeightedMeanDensityAfter'] = sum(row['oldOpacityWeight'] * row['newRenderDensity'] for row in center) / weights
center_summary['oldOpacityWeightOnChangedSamplesFraction'] = sum(row['oldOpacityWeight'] for row in center if row['deltaRenderDensity'] != 0) / weights

node_summary = dict(reconstructedNodes=len(nodes), originalByteMismatches=0, originallyUnsaturatedNodes=sum(not n['oldSaturated'] for n in nodes.values()), originallySaturatedNodes=sum(n['oldSaturated'] for n in nodes.values()), changedNodes=sum(n['oldByte'] != n['newByte'] for n in nodes.values()), desaturatedNodes=sum(n['oldSaturated'] and not n['newSaturated'] for n in nodes.values()), changedOriginallyUnsaturatedNodes=sum(not n['oldSaturated'] and n['oldByte'] != n['newByte'] for n in nodes.values()), newlyZeroMacroNodes=sum(n['oldByte'] > 0 and n['newByte'] == 0 for n in nodes.values()))
input_hashes = {}
for path in [input_path, BASE/'near-interior-stencils.ts', OLD/'carving-causality.json', OLD/'jpeg-comparison.json', OLD/'near-light.json', OLD/'snapshot-manifest.json', OLD/'geometry-scalar.ts', Path(__file__).resolve()]:
    raw = path.read_bytes()
    input_hashes[str(path)] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
report = dict(model=dict(name='Existing carving with saturation-only smooth gate', formula='I1=I0+0.1*smoothstep(.04,.28,F)*smoothstep(1,1.25,U0); U1=(F+erosion*heightScale*I1-.025)*10; same modulation/f32-store/R8-round', fixedBeforeRun=True, parameterSweep=False, newNoiseFields=0, gateWidthRawUnits=.25, gateWidthMeaning='Chosen dimensionless transition width above U0=1; not a physical length or visually fitted parameter'), sourceGit=data['git'], inputHashes=input_hashes, cacheInputs=data['inputChecks'], nodeSummary=node_summary, summaries13Rays=summary13, summaries9ValidPatches=summary9, weakRayRecords=[r for r in records if r['uv']==[.05,.05]], centerSummary=center_summary, records=records, nodes=list(nodes.values()), centerRecords=center, limitations=['Only frozen08c seed72 sample locations; no current full-volume qualification','Original JSON stored196 complete nodes; recovered original252 by identical existing52 stencils and394 center samples, verifying original bytes/records/weights before counterfactual','No new positive samples, ray positions, volume, detail, lighting cache, bake, render or performance measurement','Unchanged unsaturated macro nodes do not establish unchanged interpolated/fine-eroded shell everywhere; modified saturated neighbours can affect mixed cells','9 JPEG-valid UVs supply4 existing material depth samples each, not complete new RGB integrations or actual JPEG predictions','Old tau1/tau3 coordinates stay fixed for13-rays point comparison; only center cumulative tau recomputed along394 original samples and truncated at old endpoint','F is a smooth primitive-union scalar, not exact signed distance; gate width is not a certified world-space shell thickness','Gated macro changes need a coherent future material/light treatment before any product or visual claim'])
(BASE/'near-interior-next.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(nodeSummary=node_summary,summaries13Rays=summary13,summaries9ValidPatches=summary9,weakRayRecords=report['weakRayRecords'],centerSummary=center_summary),indent=2))
