# Possibile guardia conservativa, ancora non eseguita

Analisi root sul modello unico `near-interior-next.md`, 16 ottobre 2026.
Nessuna nuova variante, estrazione, generazione o qualifica visiva.

Il solo gate U0>1 preserva i nodi non saturi, ma un nodo saturo modificato
entra nelle otto celle trilineari che lo toccano. La positività dei nodi
macro non certifica la positività dopo erosione fine e soglia 0,002.

Una guardia sufficiente per il confronto **dispersione/forcing=0**, più
restrittiva della proposta originale, può lavorare sulle celle adiacenti:

1. Calcolare il byte candidato provvisorio dello stesso modello per il
   vicinato 3×3×3 di ogni nodo modificato. Non introdurre un secondo modello.
2. Stimare il massimo ice possibile nel campionatore: la coordinata macro
   campionata differisce da local.y per warp Y al massimo 0,06 km. Usare
   quindi l'estremo alto delle celle adiacenti +0,06 nella smoothstep ice.
3. Nel ramo forcing0 il calcolo limita flow.a a0,18, ma il texture half
   può arrotondarlo verso0,1800537109375. Non usare0,18 come bound GPU.
   Con questo valore, erosione liquida≤0,6400537109375 e ice≤0,7600537109375.
   Il micro vicino aggiunge al massimo0,055×(1−ice). Un bound aritmetico
   è E(i)=0,6950537109375+0,065i; va aggiunto un margine per operazioni e
   filtraggio f32 dopo aver verificato la rappresentazione del texture reale.
4. Il minimo della modulazione materiale ice è
   0,012×0,65×0,3=0,00234. Per ice=i, M(i)=1−0,99766i.
   Una densità macro R > E + 0,002×(1−E)/M assicura che il risultato fine
   resti sopra la soglia di eliminazione, per tutti i noise/flow ammessi.
   In liquido puro byte≥178 (178/255≈0,69804 >0,695664) hanno un margine
   ampio rispetto all'arrotondamento f32. Per ice alto il criterio è severo.
5. Accettare un nodo modificato solo se tutti i corner vecchi e provvisori
   delle celle adiacenti superano il bound pertinente. Altrimenti conservare
   il byte originario. La proposta riduce soltanto R: ripristinare gli altri
   nodi rifiutati può solo alzare i minimi, quindi non invalida i nodi sicuri.

Così ogni cella influenzata da un cambiamento avrebbe materiale positivo
sia prima sia dopo, mentre le altre celle rimarrebbero byte-identiche.
Questo sarebbe un argomento per conservare il supporto fine a forcing0,
non per conservare densità, profondità τ, illuminazione o RGB. Serve ancora
verifica indipendente della derivazione, della monotonia del byte candidato,
delle convenzioni di interpolazione e del bound di ice/warp nel codice reale.

Il criterio potrebbe eliminare gran parte dell'effetto che interessa: non
è stata misurata la percentuale di nodi sopravvissuti, neppure sui252 noti.
I loro vicinati completi non sono tutti presenti nel vecchio JSON.

Non estendere questa prova alla dispersione: forcing modifica erosione,
massFactor e fragments, che può avvicinarsi arbitrariamente a zero. Un
bound globale unico diventerebbe troppo restrittivo. La QA della dispersione
resterebbe separata anche se il confronto forcing0 superasse questa guardia.
