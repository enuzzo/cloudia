# Un solo controfattuale: carving esistente attivo soltanto nel plateau saturo

**Esito locale promettente, nessun candidato prodotto autorizzato o generato.** Il modello preserva esattamente i 13 campioni esistenti a 5 m dal primo ingresso e non svuota alcuna delle 52 coordinate dei quattro livelli sui 13 raggi. Recupera una parte della variazione del carving già presente nell'interno. Con questi soli campioni **non si può certificare il guscio/frontiera dell'intero materiale interpolato**: la proposta supera le guardie locali richieste, non una qualifica globale o visiva.

## Modello fissato prima del calcolo

La revisione scalare precedente aumentava il carving anche nel fronte non saturo e azzerava tutti i 13 punti front+5m. Qui si usa la **stessa** differenza massima fra coefficiente `.6` e `.5`, applicata solo oltre il clamp originario:

```text
S  = smoothstep(.04,.28,F)
I0 = 1 - .6*S
U0 = (F + E*H*I0 - .025)*10
G  = smoothstep(1,1.25,U0)
I1 = I0 + .1*S*G
U1 = (F + E*H*I1 - .025)*10
R1 = round255(float32(clamp(U1,0,1) * (.65+.35*n2)))
```

E è il rumore negativo già esistente, H la sua modulazione in quota. Campo dei primitivi F, c1/c2/n1/n2/n3, soglie e modulazione finale restano quelli originali. Non si aggiunge una frequenza o un noise. G è nullo per U0≤1: tutti i nodi non saturi conservano esattamente il proprio byte. La finestra adimensionale `.25` è stata dichiarata prima del primo calcolo, senza sweep o fit visivo; non è una distanza fisica né uno spessore certificato del guscio. La transizione continua evita il salto di un semplice interruttore a U0=1.

## Input e riconciliazione 196/252

Si usa esclusivamente la cache seed 72 della diagnosi congelata `08c33cb55d4cb308377d3526c362f4d30d02e7f8`, con la camera esterna già qualificata. Non è stata rifatta una qualifica dell'intero prodotto v50 corrente.

Il vecchio `carving-causality.json` serializzava gli scalari di **196 nodi** nei 52 stencil; il conteggio **252** includeva altri nodi della traccia centrale, di cui erano rimaste soltanto medie. Il piccolo estrattore esterno ha recuperato esattamente gli stessi 252 nodi, senza nuove coordinate o raggi: 52 record originari e 394 campioni centrali identici, incluse le vecchie densità e i pesi. I 252 byte ricostruiti coincidono con la cache, senza discrepanze. La costruzione delle primitive termina prima della rasterizzazione; non è stato generato nemmeno un volume ridotto o eseguito un bake.

Il JSON contiene hash SHA256 degli input, dell'estrattore e del modello, più i tre hash dei buffer originali verificati in lettura. Conserva 252 risultati di nodo, 52 campioni e 394 record centrali. Il confronto precedente dei nove patch JPEG validi rimane un fatto della baseline: qui i nove UV selezionano **36 campioni di densità a quattro profondità**, non nove nuove previsioni RGB.

## Risultati

Dei 252 nodi, 71 non erano saturi e restano invariati; 181 erano saturi. Il modello desatura 57 nodi ma cambia 55 byte: due differenze restano nascoste dalla quantizzazione R8. Nessun nodo macro prima positivo diventa zero.

| Vecchie coordinate sui 13 raggi | Densità media prima → dopo | Coordinate esattamente invariate | Nuovi vuoti |
|---|---:|---:|---:|
| Primo ingresso +5 m | 0,091105 → 0,091105 | 13/13 | 0 |
| τ1 | 0,660048 → 0,628824 | 4/13 | 0 |
| Distanza media di contributo | 0,656552 → 0,624112 | 3/13 | 0 |
| τ3 | 0,771356 → 0,760452 | 7/13 | 0 |

Il raggio debole UV `(0.05,0.05)`, prima svuotato dallo scalare, è esattamente invariato ai quattro livelli: densità 0,103238 al fronte+5m, 0,321786 alla vecchia τ1 e 0,565976 alla vecchia τ3. È escluso dal confronto fotografico per l'overlay del logo, ma resta una guardia materiale valida.

Nei nove UV JPEG validi, la densità media alla vecchia τ1 passa da 0,685707 a 0,652230; la deviazione standard da 0,032682 a 0,041341. Il coefficiente di variazione sale da 4,766% a 6,338%. Alla vecchia τ3 passa da 7,627% a 10,239%. Sono variazioni spaziali di densità campionata, **non misure di contrasto dell'immagine o qualità**.

Nel centro, la vecchia τ1 ha densità 0,680387→0,620942 e peso dello stencil ancora saturo 100%→9,892%. Sulla sola finestra dei 394 campioni centrali, tutti positivi, la tau integrata scende da 5,122279 a 5,050682 (−1,398%). I nuovi attraversamenti centrali sono più profondi di 2,735 m a τ1 e 4,739 m a τ3; questa integrazione resta limitata alla vecchia finestra, senza cercare un nuovo termine del raggio. Non è stata ricalcolata la luce.

## Limite decisivo e differenza dai tentativi ritirati

Il modello recupera risposta del carving originale **prima del clamp macro**. Non è il meso post-clamp v26, né la sola interpolazione di U/M v35; non dimostra però che produrrà un rilievo fotografico migliore. Il calo medio può limitarsi a una riduzione lieve dell'opacità, e l'illuminazione coerente resta da verificare.

Preservare i nodi non saturi non basta a preservare ogni punto interpolato: un nodo saturo modificato può contribuire a una cella mista vicina al guscio, e l'erosione fine può spostare una soglia locale. I 13 front+5m risultano identici perché i loro stencil hanno peso saturo zero; **non sono una copertura dell'intera superficie**. F inoltre è un campo di unione liscia, non la distanza firmata esatta della nube. Con i soli 252 nodi non è possibile certificare la condizione globale richiesta.

🌟 Questa è una proposta causale più selettiva dello scalare, da tenere ferma senza altri parametri. Il successivo requisito sarebbe una guardia dedicata alle celle miste del bordo prima di autorizzare un volume o un'app candidata; qui non è stata eseguita. Nessuna affermazione visiva, fisica o prestazionale e nessuna modifica agli archivi appena congelati.

Risultato completo: `near-interior-next.json`, SHA256 `b526b685fcec465d21b0c3bef81aadbcd076b3c5958d26d2de98a53e7d7023e7`. Replay scalare: `python3 near-interior-next.py`, dai soli input esterni indicati nello script; non modifica sorgenti o cache.
