from pathlib import Path
q=Path(__file__).resolve().parent
old=(q/'input/original-audit-pixels.mjs').read_text()
source=old[old.index('const size=256,detailSize=128'):old.index('const prior=JSON.parse')]
def replace(a,b):
 global source
 assert source.count(a)==1,a[:90]
 source=source.replace(a,b)
replace('let field=-10,weights=new Map(),prefix=[];', 'let field=-10,weights=new Map(),prefix=[],fullPrefix=[];')
replace('field=Math.fround(sd+(old-sd)*h+blend*h*(1-h));', '''field=Math.fround(sd+(old-sd)*h+blend*h*(1-h));
    if(trace){const continuousAfter=sd+(old-sd)*h+blend*h*(1-h);fullPrefix.push({id,sd,blend,h,before:old,continuousAfter,after:field,float32RoundingDelta:field-continuousAfter});}''')
replace('let value=0,carving=null;', 'let value=0,carving=null,carvingTrace={fieldSkipped:field<-.3};')
needle='''    value=Math.round(Math.fround(clamp((field+carving-(.025-.017*ice))*(10+ice*4))*(.65+.35*n2)*(1-ice*(1-fibers)*.5)*clamp((p[1]-.72)/.24))*255)/255;'''
replace(needle,needle+'''
    if(trace){const threshold=.025-.017*ice,densityScale=10+ice*4,scaled=(field+carving-threshold)*densityScale,clamped=clamp(scaled),noiseGain=.65+.35*n2,iceGain=1-ice*(1-fibers)*.5,baseFade=clamp((p[1]-.72)/.24),beforeFloat32=clamped*noiseGain*iceGain*baseFade,float32Density=Math.fround(beforeFloat32),byte=Math.round(float32Density*255);
      assert.equal(byte/255,value);carvingTrace={fieldSkipped:false,sourceRelativePoint:[px,py,pz],n1,n2,n3,c1,c2,erosion,ice,fibers,interior,heightScale:mod.heightErosionScale(p[1]),carving,threshold,densityScale,scaled,clamped,noiseGain,iceGain,baseFade,beforeFloat32,float32Density,byte,normalizedR8:value};}
''')
replace(')),prefix});', ')),prefix,fullPrefix,carvingTrace});')
replace('erosion=Math.min(.92,erosion);let density=', 'const erosionBeforeCap=erosion;erosion=Math.min(.92,erosion);let density=')
replace('if(trace)result.neighbors=raw.neighbors;', '''if(trace){result.neighbors=raw.neighbors;result.fineTrace={detailSample:local.map(v=>v*.3),fineDetail:fine,warpCoefficients:[.16+.0*ice+(.08-.16)*ice,.12+(.02-.12)*ice,.16+(.1-.16)*ice],erosionBeforeCap,erosionAfterCap:erosion,macroRaw:raw.value,densityBeforeThreshold:raw.value>=.002?clamp((raw.value-erosion)/(1-erosion))*material:0,threshold:.002};}''')
pre=r'''import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {gzipSync,gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const qa=dirname(fileURLToPath(import.meta.url));
const sha=b=>createHash('sha256').update(b).digest('hex');
const json=async p=>JSON.parse(await readFile(`${qa}/${p}`,'utf8'));
const frozen=await json('freeze-manifest.json');
assert.equal(sha(await readFile(fileURLToPath(import.meta.url))),frozen.scriptSHA256);
assert.equal(sha(await readFile(`${qa}/frozen-protocol.json`)),frozen.protocolSHA256);
assert.equal(sha(await readFile(`${qa}/inputs-manifest.json`)),frozen.inputsManifestSHA256);
const inputs=await json('inputs-manifest.json');
for(const item of inputs.inputs){const data=await readFile(`${qa}/${item.path}`);assert.equal(data.length,item.bytes);assert.equal(sha(data),item.sha256);}
const protocol=await json('frozen-protocol.json');
const stored=JSON.parse(gunzipSync(await readFile(`${qa}/input/actual74-layout-and-old-stencils.json.gz`)));
const previous=JSON.parse(gunzipSync(await readFile(`${qa}/input/previous-r1-results.json.gz`)));
assert.equal(stored.sourceSha256,protocol.sourceSHA256);
const mod=await import('./input/baseline-functions.mjs');
const {clamp,smoothstep,noise,cellularNoise}=mod;
const layout=stored.layout,lobes=layout.lobes,roles=new Map(layout.roles),parents=new Map(layout.parents),groups=stored.groups;
const groupName=i=>roles.get(i)??`streak-or-other-${i}`;
assert.equal(lobes.length,1918);assert.equal(protocol.points.length,5);
'''
post=r'''
function cornerCacheAt(point){const v=point.map((x,a)=>clamp((x-bmin[a])/extent[a])*size-.5),i=v.map(Math.floor),f=v.map((x,a)=>x-i[a]),out=[];
  for(let z=0;z<2;z++)for(let y=0;y<2;y++)for(let x=0;x<2;x++) {const index=[i[0]+x,i[1]+y,i[2]+z].map(a=>Math.max(0,Math.min(size-1,a))),q=rawCache.get(index.join(','));assert(q);const w=(x?f[0]:1-f[0])*(y?f[1]:1-f[1])*(z?f[2]:1-f[2]);out.push({index,field:q.field,byte:Math.round(q.value*255),value:q.value,trilinearWeight:w});}return out;}
const baseline=[];
for(const point of protocol.points){const p=point.world,expected=point.expectedSavedScalars;let actual;
  try{actual=densityAt(p,null,false);for(const key of ['density','sigma','raw','ice'])assert.equal(actual[key],expected[key],`${point.label}.${key}`);
    assert.equal(point.t,expected.t);assert.deepEqual(p,protocol.ray.origin.map((o,a)=>o+protocol.ray.ray[a]*point.t));
    const corners=cornerCacheAt(actual.warpedPoint);baseline.push({point,actual,corners});
  }catch(error){await writeFile(`${qa}/baseline-mismatch.json`,JSON.stringify({label:point.label,expected,actual,error:String(error),stoppedBeforeAttribution:true},null,2)+'\n');throw error;}
}
const allBytes=Buffer.from(baseline.flatMap(v=>v.corners.map(c=>c.byte)));
const reproduction={allFiveOriginalFineRawSigmaIceExact:true,savedSampleIndices:protocol.points.map(v=>v.savedSampleIndex),firstRecordedCornerSlots:allBytes.length,firstRecordedDiscreteR8SHA256:sha(allBytes),previousR8Scope:protocol.oldR8Provenance,points:baseline};
await writeFile(`${qa}/baseline-reproduction.json.gz`,gzipSync(JSON.stringify(reproduction)));
console.log(JSON.stringify({baselineReproduced:true,indices:reproduction.savedSampleIndices,firstRecordedDiscreteR8SHA256:sha(allBytes)}));
const identity=id=>{if(id==='shoulder')return {id,type:'inclinedShoulder10493',group:'shoulder',role:'inclinedShoulder10493',parent:null,depth:0};let root=id,depth=0;while(parents.has(root)){root=parents.get(root);depth++;}return {id,type:'ellipsoid',group:root,role:groupName(root),parent:parents.get(id)??null,depth,primitive:lobes[id]};};
const pointReports=[],catalog=new Map();
for(const checked of baseline){const {point,actual:old,corners}=checked,actual=densityAt(point.world,null,true);
  for(const key of ['density','sigma','raw','ice'])assert.equal(actual[key],old[key]);
  const weightsRaw=new Map(),weightsField=new Map();
  for(let j=0;j<actual.neighbors.length;j++){const n=actual.neighbors[j],c=corners[j];assert.deepEqual(n.index,c.index);assert.equal(n.value,c.value);assert.equal(n.field,c.field);assert.equal(n.trilinearWeight,c.trilinearWeight);
    n.byte=Math.round(n.value*255);n.fullPrefix=n.fullPrefix.map(step=>{const label=identity(step.id);catalog.set(step.id,label);return {...step,group:label.group,role:label.role,parent:label.parent,depth:label.depth};});
    for(const w of n.weights){weightsRaw.set(w.group,(weightsRaw.get(w.group)??0)+w.weight*n.value*n.trilinearWeight);weightsField.set(w.group,(weightsField.get(w.group)??0)+w.weight*n.trilinearWeight);}
    n.sourcePointMeaning='Unanimated physical source-grid voxel center, km; not an independently projected visible/offscreen pixel';
  }
  const ranking=weights=>{const sum=[...weights.values()].reduce((a,b)=>a+b,0);return [...weights].map(([group,weight])=>({group,role:group==='shoulder'?'inclinedShoulder10493':groupName(group),weight,normalized:sum?weight/sum:0})).sort((a,b)=>b.weight-a.weight);};
  const ds=Math.min(protocol.ray.step,protocol.ray.far-point.t),before=point.expectedSavedScalars.tau-point.expectedSavedScalars.sigma*ds,transmittanceBefore=Math.exp(-before),attenuationIncrement=transmittanceBefore*(1-Math.exp(-point.expectedSavedScalars.sigma*ds));
  pointReports.push({point,actual,rawSignalPrefixRanking:ranking(weightsRaw),interpolatedFieldDerivativeRanking:ranking(weightsField),savedAttenuation:{tauBefore:before,tauAfter:point.expectedSavedScalars.tau,transmittanceBefore,transmittanceAfter:Math.exp(-point.expectedSavedScalars.tau),attenuationIncrement,meaning:'Attenuation only from the already-saved ray integral, no lighting/RGB or new integration'},note:'All five world points share the same on-screen pixel; only peak is the saved density maximum along that ray. No tau1/opaque surface at this pixel; source corner points are not extra pixel queries.'});
}
const report={audit:protocol.audit,protocolSHA256:frozen.protocolSHA256,scriptSHA256:frozen.scriptSHA256,baseline:protocol.baseline,sourceSHA256:protocol.sourceSHA256,runtime:{node:process.version,arch:process.arch},reproduction:{allFiveOriginalFineRawSigmaIceExact:true,firstRecordedDiscreteR8SHA256:sha(allBytes)},ray:protocol.ray,points:pointReports,primitiveCatalog:[...catalog.values()],work:{worldPositions:5,macroCornerSlotsPerPass:40,distinctMacroTexels:rawCache.size,detail128Texels:detailCache.size,flow16Texels:flowCache.size,...counts,sdfEvaluations,noGenerator:true,noNewRay:true,noVolume:true,noCandidate:true,noOmissionCounterfactual:true},limits:['Only the five frozen positions and their eight macro corners; no entire image/volume or architecture qualified.','Continuous records are primitive SDF, union operation before Float32, Float32 field, carving before macro quantization and fine steps at the actual points. No extra direct continuous-field point was evaluated.','Prefix derivatives are geometric support attribution, not additive mass/RGB; Float32/R8 clamps are nonlinear and rounding derivatives are not modeled.','The previous r1 saved filtered macroR8 raw, not these discrete corner bytes; old scalar identity and new within-audit corner identity are separately reported.','Occlusion values are saved density attenuation only; no light cache/RGB inversion, no full 3D topology inference.','No inference that increasing this particular saddle ray is a universal artistic or physical goal.']};
await writeFile(`${qa}/attribution.json.gz`,gzipSync(JSON.stringify(report)));
const summary={...report,points:pointReports.map(({actual,...v})=>({...v,source:{reference:actual.reference,local:actual.local,warpedPoint:actual.warpedPoint},scalars:{density:actual.density,sigma:actual.sigma,raw:actual.raw,ice:actual.ice,erosion:actual.erosion,material:actual.material,flow:actual.flow},fineTrace:actual.fineTrace,corners:actual.neighbors.map(n=>({index:n.index,point:n.point,field:n.field,carving:n.carving,byte:n.byte,value:n.value,trilinearWeight:n.trilinearWeight,carvingTrace:n.carvingTrace,activeFieldWeights:n.weights.map(w=>({id:w.id,group:w.group,role:w.role,weight:w.weight})),evaluatedLobes:n.fullPrefix.length}))})),primitiveCatalog:undefined};
await writeFile(`${qa}/summary.json`,JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify({work:report.work,points:pointReports.map(v=>({label:v.point.label,fine:v.actual.density,raw:v.actual.raw,source:v.actual.warpedPoint,erosion:v.actual.erosion,ranking:v.rawSignalPrefixRanking,fieldRanking:v.interpolatedFieldDerivativeRanking}))},null,2));
'''
(q/'audit.mjs').write_text(pre+source+post)
print('prepared audit script bytes',(q/'audit.mjs').stat().st_size)
