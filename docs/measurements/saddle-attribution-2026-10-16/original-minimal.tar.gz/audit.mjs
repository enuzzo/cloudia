import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {gzipSync,gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const qa=dirname(fileURLToPath(import.meta.url));
const sha=b=>createHash('sha256').update(b).digest('hex');
const json=async p=>JSON.parse(await readFile(`${qa}/${p}`,'utf8'));
const frozen=await json('freeze-manifest.json');
assert.equal(sha(await readFile(fileURLToPath(import.meta.url))),frozen.scriptSHA256);
assert.equal(sha(await readFile(`${qa}/frozen-protocol.json`)),frozen.protocolSHA256);
assert.equal(sha(await readFile(`${qa}/inputs-manifest.json`)),frozen.inputsManifestSHA256);
const inputs=await json('inputs-manifest.json');
for(const item of inputs.inputs){const data=await readFile(`${qa}/${item.path}`);assert.equal(data.length,item.bytes);assert.equal(sha(data),item.sha256);}
const protocol=await json('frozen-protocol.json');
const stored=JSON.parse(gunzipSync(await readFile(`${qa}/input/actual74-layout-and-old-stencils.json.gz`)));
const previous=JSON.parse(gunzipSync(await readFile(`${qa}/input/previous-r1-results.json.gz`)));
assert.equal(stored.sourceSha256,protocol.sourceSHA256);
const mod=await import('./input/baseline-functions.mjs');
const {clamp,smoothstep,noise,cellularNoise}=mod;
const layout=stored.layout,lobes=layout.lobes,roles=new Map(layout.roles),parents=new Map(layout.parents),groups=stored.groups;
const groupName=i=>roles.get(i)??`streak-or-other-${i}`;
assert.equal(lobes.length,1918);assert.equal(protocol.points.length,5);
const size=256,detailSize=128,seed=74,bmin=[-5,-.5,-3.5],extent=[10,8.5,7];
const center=(i,a,n=size)=>bmin[a]+(i+.5)/n*extent[a];
const bounds=lobes.map(l=>({start:l.slice(0,3).map((c,a)=>Math.max(1,Math.floor((c-l[a+3]-.35-bmin[a])/extent[a]*size-.5))),end:l.slice(0,3).map((c,a)=>Math.min(size-2,Math.ceil((c+l[a+3]+.35-bmin[a])/extent[a]*size-.5)))}));
const mature=layout.summits.reduce((a,b)=>lobes[a][1]>lobes[b][1]?a:b),m=lobes[mature],foot=lobes[layout.foundations[layout.summits.indexOf(mature)]],cap=layout.iceCores.map(i=>lobes[i]).reduce((a,b)=>Math.hypot(a[0]-m[0],a[2]-m[2])<Math.hypot(b[0]-m[0],b[2]-m[2])?a:b);
const shoulder=mod.prepareInclinedShoulder([0,1,2].map(a=>foot[a]+(m[a]-foot[a])*.68),[cap[0]+cap[3]*.28,cap[1]-cap[4]*.1,cap[2]],Math.max(m[3]*.95,foot[3]*.62),Math.max(m[5]*.95,cap[5]*.68));
const shoulderBounds={start:shoulder.min.map((v,a)=>Math.max(1,Math.floor((v-.35-bmin[a])/extent[a]*size-.5))),end:shoulder.max.map((v,a)=>Math.min(size-2,Math.ceil((v+.35-bmin[a])/extent[a]*size-.5)))};
const iceRange=mod.iceHeights(seed),cellular=cellularNoise(seed+137),detailCellular=cellularNoise(seed+513);
const rawCache=new Map(),detailCache=new Map(),flowCache=new Map();let sdfEvaluations=0;
const counts={rawHits:0,rawMisses:0,detailHits:0,detailMisses:0,flowMisses:0};
function rawVoxel(x,y,z,skip=null,trace=false) {
  x=Math.max(0,Math.min(size-1,x));y=Math.max(0,Math.min(size-1,y));z=Math.max(0,Math.min(size-1,z));
  const key=`${x},${y},${z}`,cacheKey=skip===null?key:`${skip}:${key}`;
  if(!trace&&rawCache.has(cacheKey)){counts.rawHits++;return rawCache.get(cacheKey);}
  counts.rawMisses++;if(x===0||y===0||z===0||x===size-1||y===size-1||z===size-1)return {value:0,field:-10};
  const p=[center(x,0),center(y,1),center(z,2)];let field=-10,weights=new Map(),prefix=[],fullPrefix=[];
  const merge=(sd,blend,id)=>{const old=field,h=clamp(.5+.5*(old-sd)/blend);field=Math.fround(sd+(old-sd)*h+blend*h*(1-h));
    if(trace){const continuousAfter=sd+(old-sd)*h+blend*h*(1-h);fullPrefix.push({id,sd,blend,h,before:old,continuousAfter,after:field,float32RoundingDelta:field-continuousAfter});}
    if(trace&&h<1){for(const [key,w]of weights){const nw=w*h;if(nw<1e-12)weights.delete(key);else weights.set(key,nw);}weights.set(id,(weights.get(id)??0)+1-h);prefix.push({id,sd,h,before:old,after:field});}};
  for(let i=0;i<lobes.length;i++) {
    if(skip!==null&&groups[i]===skip)continue;const b=bounds[i];if(x<b.start[0]||x>b.end[0]||y<b.start[1]||y>b.end[1]||z<b.start[2]||z>b.end[2])continue;
    const l=lobes[i],sd=(1-Math.sqrt(((p[0]-l[0])/l[3])**2+((p[1]-l[1])/l[4])**2+((p[2]-l[2])/l[5])**2))*Math.min(l[3],l[4],l[5]);sdfEvaluations++;merge(sd,l[6]??.2,i);
  }
  const b=shoulderBounds;
  if(skip!=='shoulder'&&x>=b.start[0]&&x<=b.end[0]&&y>=b.start[1]&&y<=b.end[1]&&z>=b.start[2]&&z<=b.end[2])merge(shoulder.sample(...p),.16,'shoulder');
  let value=0,carving=null,carvingTrace={fieldSkipped:field<-.3};
  if(field>=-.3){const px=p[0]-bmin[0],py=p[1]-bmin[1],pz=p[2]-bmin[2];
    const n1=noise(px*1.25,py*1.25,pz*1.25,seed),n2=noise(px*3.6,py*3.6,pz*3.6,seed+12),n3=noise(px*9,py*9,pz*9,seed+42),c1=cellular(px*1.8,py*1.8,pz*1.8),c2=cellular(px*4.5,py*4.5,pz*4.5);
    const erosion=Math.min(0,(n1-.5)*.2-(1-c1)*.52-(1-c2)*.2+(n3-.5)*.1),ice=smoothstep(...iceRange,p[1]),fibers=noise(px*.3+py*.17,py*5,pz,seed+81),interior=1-.6*smoothstep(.04,.28,field);
    carving=erosion*mod.heightErosionScale(p[1])*interior*(1-ice)-(.012+(1-fibers)*.045+(1-n1)*.07+(1-n2)*.025)*ice;
    value=Math.round(Math.fround(clamp((field+carving-(.025-.017*ice))*(10+ice*4))*(.65+.35*n2)*(1-ice*(1-fibers)*.5)*clamp((p[1]-.72)/.24))*255)/255;
    if(trace){const threshold=.025-.017*ice,densityScale=10+ice*4,scaled=(field+carving-threshold)*densityScale,clamped=clamp(scaled),noiseGain=.65+.35*n2,iceGain=1-ice*(1-fibers)*.5,baseFade=clamp((p[1]-.72)/.24),beforeFloat32=clamped*noiseGain*iceGain*baseFade,float32Density=Math.fround(beforeFloat32),byte=Math.round(float32Density*255);
      assert.equal(byte/255,value);carvingTrace={fieldSkipped:false,sourceRelativePoint:[px,py,pz],n1,n2,n3,c1,c2,erosion,ice,fibers,interior,heightScale:mod.heightErosionScale(p[1]),carving,threshold,densityScale,scaled,clamped,noiseGain,iceGain,baseFade,beforeFloat32,float32Density,byte,normalizedR8:value};}

  }
  const result={value,field};if(trace)Object.assign(result,{index:[x,y,z],point:p,carving,weights:[...weights].map(([id,weight])=>({id,weight,group:id==='shoulder'?'shoulder':groups[id],role:id==='shoulder'?'inclinedShoulder10493':groupName(groups[id]),lobe:id==='shoulder'?null:lobes[id]})),prefix,fullPrefix,carvingTrace});
  if(!trace)rawCache.set(cacheKey,result);return result;
}
function detailVoxel(x,y,z){x=(x+detailSize)%detailSize;y=(y+detailSize)%detailSize;z=(z+detailSize)%detailSize;const key=`${x},${y},${z}`;
  if(detailCache.has(key)){counts.detailHits++;return detailCache.get(key);}counts.detailMisses++;
  const p=[(x+.5)/detailSize,(y+.5)/detailSize,(z+.5)/detailSize];
  const v=[Math.round((detailCellular(p[0]*32,p[1]*32,p[2]*32)*.65+noise(p[0]*8,p[1]*8,p[2]*8,seed,8)*.35)*255)/255,
    Math.round(noise(p[0]*16,p[1]*16,p[2]*16,seed+21,16)*255)/255,Math.round(noise(p[0]*32,p[1]*32,p[2]*32,seed+39,32)*255)/255];detailCache.set(key,v);return v;}
function linearDetail(p){const v=p.map(x=>(x-Math.floor(x))*detailSize-.5),i=v.map(Math.floor),f=v.map((x,a)=>x-i[a]),sum=[0,0,0];
  for(let z=0;z<2;z++)for(let y=0;y<2;y++)for(let x=0;x<2;x++){const q=detailVoxel(i[0]+x,i[1]+y,i[2]+z),w=(x?f[0]:1-f[0])*(y?f[1]:1-f[1])*(z?f[2]:1-f[2]);for(let c=0;c<3;c++)sum[c]+=q[c]*w;}return sum;}
function macro(p,skip=null,trace=false){const v=p.map((x,a)=>clamp((x-bmin[a])/extent[a])*size-.5),i=v.map(Math.floor),f=v.map((x,a)=>x-i[a]);let sum=0;const neighbors=[];
  for(let z=0;z<2;z++)for(let y=0;y<2;y++)for(let x=0;x<2;x++){const q=rawVoxel(i[0]+x,i[1]+y,i[2]+z,skip,trace),w=(x?f[0]:1-f[0])*(y?f[1]:1-f[1])*(z?f[2]:1-f[2]);sum+=q.value*w;if(trace)neighbors.push({...q,trilinearWeight:w});}return{value:sum,neighbors};}
const state=mod.motionState(60,seed);state.dispersion=0;
const wind=[.55*(.52+.23*Math.sin(60*.055+state.seedPhase*3)),.55*.26*Math.sin(60*.031+.6)],drift=[.55*(.32*Math.sin(60*.027)+.11*Math.sin(60*.071)),Math.sin(60*.04)*.015,0];
function flow(p){const v=p.map((x,a)=>(x-bmin[a])/extent[a]*16-.5),i=v.map(Math.floor),f=v.map((x,a)=>x-i[a]),out=[0,0,0,0];
  for(let z=0;z<2;z++)for(let y=0;y<2;y++)for(let x=0;x<2;x++){const k=[i[0]+x,i[1]+y,i[2]+z].map(a=>Math.max(0,Math.min(15,a))),key=k.join(',');let q=flowCache.get(key);
    if(!q){q=[0,0,0,0];mod.writeDisplacement(center(k[0],0,16),center(k[1],1,16),center(k[2],2,16),state,iceRange,q);q=q.map(c=>mod.DataUtils.fromHalfFloat(mod.DataUtils.toHalfFloat(c)));flowCache.set(key,q);counts.flowMisses++;}
    const w=(x?f[0]:1-f[0])*(y?f[1]:1-f[1])*(z?f[2]:1-f[2]);for(let c=0;c<4;c++)out[c]+=q[c]*w;}return out;}
function densityAt(world,skip=null,trace=false){const reference=mod.referencePosition(world.map((v,a)=>v-drift[a]),state,iceRange,wind),flowValue=flow(reference),local=reference.map((v,a)=>v-flowValue[a]),ice=smoothstep(...iceRange,local[1]),fine=linearDetail(local.map(v=>v*.3));
  const warpedPoint=local.map((v,a)=>v+([fine[1],fine[2],fine[0]][a]-.5)*([.16,.12,.16][a]+([.08,.02,.1][a]-[.16,.12,.16][a])*ice)),raw=macro(warpedPoint,skip,trace);
  let erosion=(1-fine[0])*.38+(1-fine[2])*.08+flowValue[3],material=1;
  if(ice>0){const bend=linearDetail([local[0]*.12,local[1]*.10,local[2]*.06])[1],iceDetail=linearDetail([local[0]*.055+bend*.08,local[1]*.34+local[0]*.022+(bend-.5)*.06,local[2]*.08+(bend-.5)*.025]),wisps=iceDetail[0];
    erosion=erosion*(1-ice)+(.08+(1-wisps)*.5+flowValue[3])*ice;const strand=smoothstep(.3,.7,wisps);material=1-ice+(.012+.56*strand**1.7)*(.65+.35*smoothstep(.25,.75,iceDetail[2]))*(1-.7*smoothstep(.4,3.8,local[0]))*ice;}
  const erosionBeforeCap=erosion;erosion=Math.min(.92,erosion);let density=raw.value>=.002?clamp((raw.value-erosion)/(1-erosion))*material:0;if(density<.002)density=0;
  const result={density,sigma:mod.materialExtinction(ice)*density,world,reference,local,warpedPoint,ice,flow:flowValue,raw:raw.value,erosion,material};if(trace){result.neighbors=raw.neighbors;result.fineTrace={detailSample:local.map(v=>v*.3),fineDetail:fine,warpCoefficients:[.16+.0*ice+(.08-.16)*ice,.12+(.02-.12)*ice,.16+(.1-.16)*ice],erosionBeforeCap,erosionAfterCap:erosion,macroRaw:raw.value,densityBeforeThreshold:raw.value>=.002?clamp((raw.value-erosion)/(1-erosion))*material:0,threshold:.002};}return result;}

function cornerCacheAt(point){const v=point.map((x,a)=>clamp((x-bmin[a])/extent[a])*size-.5),i=v.map(Math.floor),f=v.map((x,a)=>x-i[a]),out=[];
  for(let z=0;z<2;z++)for(let y=0;y<2;y++)for(let x=0;x<2;x++) {const index=[i[0]+x,i[1]+y,i[2]+z].map(a=>Math.max(0,Math.min(size-1,a))),q=rawCache.get(index.join(','));assert(q);const w=(x?f[0]:1-f[0])*(y?f[1]:1-f[1])*(z?f[2]:1-f[2]);out.push({index,field:q.field,byte:Math.round(q.value*255),value:q.value,trilinearWeight:w});}return out;}
const baseline=[];
for(const point of protocol.points){const p=point.world,expected=point.expectedSavedScalars;let actual;
  try{actual=densityAt(p,null,false);for(const key of ['density','sigma','raw','ice'])assert.equal(actual[key],expected[key],`${point.label}.${key}`);
    assert.equal(point.t,expected.t);assert.deepEqual(p,protocol.ray.origin.map((o,a)=>o+protocol.ray.ray[a]*point.t));
    const corners=cornerCacheAt(actual.warpedPoint);baseline.push({point,actual,corners});
  }catch(error){await writeFile(`${qa}/baseline-mismatch.json`,JSON.stringify({label:point.label,expected,actual,error:String(error),stoppedBeforeAttribution:true},null,2)+'\n');throw error;}
}
const allBytes=Buffer.from(baseline.flatMap(v=>v.corners.map(c=>c.byte)));
const reproduction={allFiveOriginalFineRawSigmaIceExact:true,savedSampleIndices:protocol.points.map(v=>v.savedSampleIndex),firstRecordedCornerSlots:allBytes.length,firstRecordedDiscreteR8SHA256:sha(allBytes),previousR8Scope:protocol.oldR8Provenance,points:baseline};
await writeFile(`${qa}/baseline-reproduction.json.gz`,gzipSync(JSON.stringify(reproduction)));
console.log(JSON.stringify({baselineReproduced:true,indices:reproduction.savedSampleIndices,firstRecordedDiscreteR8SHA256:sha(allBytes)}));
const identity=id=>{if(id==='shoulder')return {id,type:'inclinedShoulder10493',group:'shoulder',role:'inclinedShoulder10493',parent:null,depth:0};let root=id,depth=0;while(parents.has(root)){root=parents.get(root);depth++;}return {id,type:'ellipsoid',group:root,role:groupName(root),parent:parents.get(id)??null,depth,primitive:lobes[id]};};
const pointReports=[],catalog=new Map();
for(const checked of baseline){const {point,actual:old,corners}=checked,actual=densityAt(point.world,null,true);
  for(const key of ['density','sigma','raw','ice'])assert.equal(actual[key],old[key]);
  const weightsRaw=new Map(),weightsField=new Map();
  for(let j=0;j<actual.neighbors.length;j++){const n=actual.neighbors[j],c=corners[j];assert.deepEqual(n.index,c.index);assert.equal(n.value,c.value);assert.equal(n.field,c.field);assert.equal(n.trilinearWeight,c.trilinearWeight);
    n.byte=Math.round(n.value*255);n.fullPrefix=n.fullPrefix.map(step=>{const label=identity(step.id);catalog.set(step.id,label);return {...step,group:label.group,role:label.role,parent:label.parent,depth:label.depth};});
    for(const w of n.weights){weightsRaw.set(w.group,(weightsRaw.get(w.group)??0)+w.weight*n.value*n.trilinearWeight);weightsField.set(w.group,(weightsField.get(w.group)??0)+w.weight*n.trilinearWeight);}
    n.sourcePointMeaning='Unanimated physical source-grid voxel center, km; not an independently projected visible/offscreen pixel';
  }
  const ranking=weights=>{const sum=[...weights.values()].reduce((a,b)=>a+b,0);return [...weights].map(([group,weight])=>({group,role:group==='shoulder'?'inclinedShoulder10493':groupName(group),weight,normalized:sum?weight/sum:0})).sort((a,b)=>b.weight-a.weight);};
  const ds=Math.min(protocol.ray.step,protocol.ray.far-point.t),before=point.expectedSavedScalars.tau-point.expectedSavedScalars.sigma*ds,transmittanceBefore=Math.exp(-before),attenuationIncrement=transmittanceBefore*(1-Math.exp(-point.expectedSavedScalars.sigma*ds));
  pointReports.push({point,actual,rawSignalPrefixRanking:ranking(weightsRaw),interpolatedFieldDerivativeRanking:ranking(weightsField),savedAttenuation:{tauBefore:before,tauAfter:point.expectedSavedScalars.tau,transmittanceBefore,transmittanceAfter:Math.exp(-point.expectedSavedScalars.tau),attenuationIncrement,meaning:'Attenuation only from the already-saved ray integral, no lighting/RGB or new integration'},note:'All five world points share the same on-screen pixel; only peak is the saved density maximum along that ray. No tau1/opaque surface at this pixel; source corner points are not extra pixel queries.'});
}
const report={audit:protocol.audit,protocolSHA256:frozen.protocolSHA256,scriptSHA256:frozen.scriptSHA256,baseline:protocol.baseline,sourceSHA256:protocol.sourceSHA256,runtime:{node:process.version,arch:process.arch},reproduction:{allFiveOriginalFineRawSigmaIceExact:true,firstRecordedDiscreteR8SHA256:sha(allBytes)},ray:protocol.ray,points:pointReports,primitiveCatalog:[...catalog.values()],work:{worldPositions:5,macroCornerSlotsPerPass:40,distinctMacroTexels:rawCache.size,detail128Texels:detailCache.size,flow16Texels:flowCache.size,...counts,sdfEvaluations,noGenerator:true,noNewRay:true,noVolume:true,noCandidate:true,noOmissionCounterfactual:true},limits:['Only the five frozen positions and their eight macro corners; no entire image/volume or architecture qualified.','Continuous records are primitive SDF, union operation before Float32, Float32 field, carving before macro quantization and fine steps at the actual points. No extra direct continuous-field point was evaluated.','Prefix derivatives are geometric support attribution, not additive mass/RGB; Float32/R8 clamps are nonlinear and rounding derivatives are not modeled.','The previous r1 saved filtered macroR8 raw, not these discrete corner bytes; old scalar identity and new within-audit corner identity are separately reported.','Occlusion values are saved density attenuation only; no light cache/RGB inversion, no full 3D topology inference.','No inference that increasing this particular saddle ray is a universal artistic or physical goal.']};
await writeFile(`${qa}/attribution.json.gz`,gzipSync(JSON.stringify(report)));
const summary={...report,points:pointReports.map(({actual,...v})=>({...v,source:{reference:actual.reference,local:actual.local,warpedPoint:actual.warpedPoint},scalars:{density:actual.density,sigma:actual.sigma,raw:actual.raw,ice:actual.ice,erosion:actual.erosion,material:actual.material,flow:actual.flow},fineTrace:actual.fineTrace,corners:actual.neighbors.map(n=>({index:n.index,point:n.point,field:n.field,carving:n.carving,byte:n.byte,value:n.value,trilinearWeight:n.trilinearWeight,carvingTrace:n.carvingTrace,activeFieldWeights:n.weights.map(w=>({id:w.id,group:w.group,role:w.role,weight:w.weight})),evaluatedLobes:n.fullPrefix.length}))})),primitiveCatalog:undefined};
await writeFile(`${qa}/summary.json`,JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify({work:report.work,points:pointReports.map(v=>({label:v.point.label,fine:v.actual.density,raw:v.actual.raw,source:v.actual.warpedPoint,erosion:v.actual.erosion,ranking:v.rawSignalPrefixRanking,fieldRanking:v.interpolatedFieldDerivativeRanking}))},null,2));
