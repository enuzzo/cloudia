# Attribuzione baseline della sella: corpo comune, non gruppo del becco

**Nei cinque campioni fissati, il supporto macro proviene soprattutto dal core `shared.body`: 94,70–99,21% dei pesi locali.** Il becco appartiene invece al rigonfiamento interno maturo, gruppo 91. I due problemi hanno quindi owner diversi nei punti verificati. Non è una spiegazione dell'intera U né una proposta di modifica del corpo comune o dell'erosione.

Il protocollo è stato congelato prima del campo: SHA-256 `a917b9710d4835d13d9ca20fe3a3f74f9b681f166b82c2ad437b3188dcb9f852`; script `6b9ea4c084db39853989b22a14d04710b2d096d629f6056a62e4bd1ca6a2345c`. Solo baseline 10493 e layout 74 effettivo archiviato; nessuna rigenerazione di primitive. Nessuna variante, nuovo raggio/griglia, volume, bake, app/GPU o modifica repository durante l'audit.

## Identità prima dell'attribuzione

Pixel nativo [1408,490], UV centro [1408.5/2560,490.5/1440]; origine [0,2.7,16], yaw/pitch0, inspection0, t60, wind0.55, dispersione0, stesse funzioni di motion/detail/flow/materiale/estinzione. I cinque indici e t sono quelli già salvati dal preflight r1: 144/145/148/151/152, senza ricerca di punti favorevoli.

Prima di registrare prefix/carving sono stati verificati con uguaglianza esatta JavaScript `===` densità fine, sigma, macroR8 filtrata `raw` e ice di tutti e cinque i campioni contro i vecchi valori. Poi il trace degli stessi 40 corner-slot ha riprodotto byte R8, field Float32 e pesi trilineari della prima fase esattamente.

**Limite di provenienza:** r1 conservava `raw` filtrato dalla texture R8, non gli otto byte discreti di questi punti. I 40 byte sono registrati qui per la prima volta; la loro uguaglianza è fra le due fasi di questo audit, non contro una cache precedente inesistente. SHA-256 dei 40 byte in ordine punto/corner: `16966c949c1f052fac4e00cc966bb0327203c86191aa498ec5c557e495225abc`.

| Punto già fissato | Sample | t | Fine esatta | RawR8 filtrata esatta | Erosione fine | Core16, peso normalizzato |
|---|---:|---:|---:|---:|---:|---:|
| Zero anteriore | 144 | 15,7242586863 | 0 | 0,187152702 | 0,229294926 | 98,5905% |
| Primo positivo | 145 | 15,7424878529 | 0,130825744 | 0,325073414 | 0,223485301 | 98,1751% |
| Picco lungo raggio | 148 | 15,7971753529 | 0,560654607 | 0,675639518 | 0,261718714 | 99,2069% |
| Ultimo positivo | 151 | 15,8518628529 | 0,011732858 | 0,229088780 | 0,219936405 | 94,7023% |
| Zero posteriore | 152 | 15,8700920196 | 0 | 0,101795232 | 0,235186039 | 96,5492% |

I pesi sono derivate del prefisso di unione pesate con R8 e filtro trilineare; non massa o contributi RGB. In questi punti i contributor finali sono core 16,9,5,8: nessun billow mantiene peso finale. Oltre a core 16: `young.middle`0,595–3,641%, `main.shoulder0`0,152–1,512%, `young.foundation`0,046–0,144%. La spalla10493, i summit e l'incus non hanno peso finale in questi stencil. Nessun controfattuale per omissione è stato eseguito.

## Dal pixel ai punti fisici sorgente

`world` è lungo il raggio camera. `reference` applica il moto di riferimento, `local` sottrae il flow half filtrato, `warpedPoint` aggiunge il warp fine prima della macro. Le coordinate complete e tutti gli otto centri voxel fisici sono nei raw.

| Punto | WorldXYZ, km | WarpedSourceXYZ, km |
|---|---|---|
| Zero anteriore | [0,802699;3,413996;0,312483] | [0,610470;3,104200;0,326759] |
| Primo positivo | [0,803629;3,414824;0,294296] | [0,615421;3,100440;0,316073] |
| Picco | [0,806421;3,417307;0,239737] | [0,628681;3,103451;0,256386] |
| Ultimo positivo | [0,809213;3,419790;0,185177] | [0,631564;3,140665;0,218394] |
| Zero posteriore | [0,810143;3,420618;0,166990] | [0,632762;3,156254;0,192575] |

Il flowY è 0,243692–0,274652 km e viene sottratto; il warpY abbassa ulteriormente il punto macro. Trasferire direttamente world Y≈3,417 alle primitive avrebbe guardato la quota sbagliata.

Il core 16 ha centro sorgente [0,381638;2,261577;0,029861] e raggi [1,407807;1,134157;1,132628]km. È il corpo comune fra le fondazioni, non un tronco mancante del maturo o il cap alto. Il catalogo registra gli indici solo come identità diagnostiche; i ruoli/parent derivano dal trace reale congelato.

## Dove si perde il supporto

Tutti i40 corner-slot hanno **field finale positivo**, fra 0,186285 e0,258478. Non sono fuori dal volume, sulle facce della texture o saltati dal gate field<−0.3. La macro viene però fortemente scavata: carving fra −0,215755 e−0,125886, con rumori/cellulari, interior, scala di quota e soglia salvati integralmente.

Negli stencil dello zero anteriore, ultimo positivo e zero posteriore, quattro corner su otto diventano R8 zero dopo carving/clamp/quantizzazione; primo positivo e picco hanno otto corner nonnulli. Il filtro mescola questi byte per ottenere i `raw` sopra. Infine, con ice 0 e materiale 1, `clamp((raw−E)/(1−E))` azzera i due punti esterni perché raw<E. All'ultimo positivo il margine raw−E è solo 0,009152375.

Sono quindi presenti, negli stessi punti, tre passaggi distinti: corpo geometrico positivo; perdita macro per carving/quantizzazione/interpolazione; ulteriore erosione fine. Non segue che diminuirne un coefficiente sia corretto: nessun modello alternativo o valore candidato è stato calcolato.

Il raw conserva ogni operazione effettivamente valutata dal raster locale: `sd`, blend, h, field precedente, risultato continuo prima di Float32, field Float32 e relativi arrotondamenti. Include il decode del carving fino al byte R8 e i fattori fini fino alla densità finale. Non è un SDF diretto nuovo al centro interpolato: le valutazioni geometriche sono solo quelle dei suoi otto corner autorizzati.

## Visibilità, occlusione e perimetro

Tutti i cinque punti appartengono allo stesso pixel visibile sullo schermo; non sono cinque punti di superficie visibile. “Picco” indica il massimo di densità già salvato lungo il raggio, non il massimo di luce diffusa. Il raggio non raggiungeτ1 e non individua una superficie opaca. I due zeri delimitano localmente il tratto positivo. I corner sono punti della griglia sorgente, non nuove interrogazioni di pixel fuori immagine.

I valori di attenuazione derivano dai vecchi tau già salvati. Dopo tutto il tratto, τ0,666904 corrisponde a T 0,513295; non è stato ricostruito RGB o il bake della luce. In questi cinque punti non emerge una testa giovane in primo piano che sostituisca il contributo del corpo comune. Ciò non risolve la relazione di occlusione delle torri presso altri margini della U.

Il risultato utile per una futura diagnosi è la separazione degli owner: **rigonfiamento 91 al becco, core comune 16 nel raggio sella.** Un'eventuale ridistribuzione gerarchica dovrebbe tenerne conto, ma qui non viene definita o autorizzata. Aumentare questa sella non è una necessità fisica o artistica universale.

Lavoro: cinque posizioni;40 corner-slot per fase,30 macrotexel distinti,32 texel dettaglio 128,12 texel flow 16,6.819 valutazioni SDF locali. Nessun altro punto, raggio, generatore o calcolo di campo successivo. `attribution.json.gz` conserva il raw completo; `summary.json` e `saved-data-interpretation.json` lo rendono leggibile. `inputs-manifest.json`, protocollo e manifest finale preservano la provenienza. Audit concluso, nessun seguito automatico.
