// Standalone test app: no GPU access, fetch or dispatch before the button click.
const button = document.getElementById('run');
const status = document.getElementById('status');
const result = document.getElementById('result');
const recordsElement = document.getElementById('records');
const sentry = 0x7fc00001;
const hex = value => '0x' + (value >>> 0).toString(16).padStart(8, '0');
const digest = async bytes => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)), x => x.toString(16).padStart(2, '0')).join('');
async function getBytes(path) {
  const response = await fetch(path, {cache: 'no-store'});
  if (!response.ok) throw new Error(`${path}: HTTP ${response.status}`);
  return new Uint8Array(await response.arrayBuffer());
}
async function runComparison() {
  const started = new Date().toISOString();
  let device;
  const resources = [];
  const validationErrors = [];
  let gpuSubmitted = false;
  let gpuCompleted = false;
  try {
    status.textContent = 'Verifica dei file congelati…';
    const manifest = JSON.parse(new TextDecoder().decode(await getBytes('./manifest.json')));
    const selected = {};
    for (const name of ['cases.json', 'old.wgsl', 'new.wgsl', 'provenance.json']) {
      const bytes = await getBytes('./' + name);
      const hash = await digest(bytes);
      if (bytes.length !== manifest.files[name].bytes || hash !== manifest.files[name].sha256) throw new Error(`Integrità diversa dal manifest: ${name}`);
      selected[name] = new TextDecoder().decode(bytes);
    }
    const input = JSON.parse(selected['cases.json']);
    const provenance = JSON.parse(selected['provenance.json']);
    if (input.count !== input.cases.length || input.count < 1 || input.count > 256 || input.strideFloats !== 32) throw new Error('Dimensioni input non valide');
    const flat = input.cases.flatMap(c => c.vectors.flat());
    if (flat.length !== input.count * 32 || !flat.every(Number.isFinite)) throw new Error('Input non finiti o stride errato');
    const packed = new Float32Array(flat);
    if (!packed.every(Number.isFinite)) throw new Error('Overflow nella conversione f32');
    if (!navigator.gpu) throw new Error('WebGPU non disponibile in questo browser');
    status.textContent = 'Richiesta adattatore WebGPU…';
    const adapter = await navigator.gpu.requestAdapter({powerPreference: 'high-performance'});
    if (!adapter) throw new Error('Nessun adattatore WebGPU disponibile');
    device = await adapter.requestDevice();
    device.addEventListener('uncapturederror', event => validationErrors.push(event.error.message));
    const pipelines = {};
    for (const variant of ['old', 'new']) {
      status.textContent = `Compilazione shader ${variant}…`;
      device.pushErrorScope('validation');
      const module = device.createShaderModule({label: `shared-aerial-${variant}`, code: selected[variant + '.wgsl']});
      const info = await module.getCompilationInfo();
      const errors = info.messages.filter(message => message.type === 'error');
      if (errors.length) {
        await device.popErrorScope();
        throw new Error(JSON.stringify({variant, compilationErrors: errors.map(e => ({message: e.message, line: e.lineNum, column: e.linePos}))}));
      }
      pipelines[variant] = await device.createComputePipelineAsync({label: `segment-${variant}`, layout: 'auto', compute: {module, entryPoint: 'compareSegments'}});
      const error = await device.popErrorScope();
      if (error) throw new Error(`${variant}: ${error.message}`);
    }
    const inputBuffer = device.createBuffer({label: '216 finite segment tuples', size: packed.byteLength, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST});
    resources.push(inputBuffer);
    device.queue.writeBuffer(inputBuffer, 0, packed);
    const outputBytes = input.count * 4 * 4;
    const initialized = new Uint32Array(input.count * 4).fill(sentry);
    const outputs = {};
    device.pushErrorScope('validation');
    const encoder = device.createCommandEncoder({label: 'two separate segment comparisons'});
    for (const variant of ['old', 'new']) {
      const output = device.createBuffer({label: `segment-${variant}-bits`, size: outputBytes, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST});
      const readback = device.createBuffer({label: `segment-${variant}-readback`, size: outputBytes, usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ});
      resources.push(output, readback);
      device.queue.writeBuffer(output, 0, initialized);
      const bindGroup = device.createBindGroup({layout: pipelines[variant].getBindGroupLayout(0), entries: [{binding: 0, resource: {buffer: inputBuffer}}, {binding: 1, resource: {buffer: output}}]});
      const pass = encoder.beginComputePass({label: `compute-${variant}`});
      pass.setPipeline(pipelines[variant]);
      pass.setBindGroup(0, bindGroup);
      pass.dispatchWorkgroups(Math.ceil(input.count / 32));
      pass.end();
      encoder.copyBufferToBuffer(output, 0, readback, 0, outputBytes);
      outputs[variant] = {readback};
    }
    status.textContent = 'Esecuzione dei due shader GPU e lettura f32…';
    device.queue.submit([encoder.finish()]);
    gpuSubmitted = true;
    for (const variant of ['old', 'new']) {
      await outputs[variant].readback.mapAsync(GPUMapMode.READ);
      const data = outputs[variant].readback.getMappedRange().slice(0);
      outputs[variant].readback.unmap();
      outputs[variant].bits = new Uint32Array(data);
      outputs[variant].floats = new Float32Array(data);
      outputs[variant].sha256 = await digest(data);
    }
    await device.queue.onSubmittedWorkDone();
    gpuCompleted = true;
    const submissionError = await device.popErrorScope();
    if (submissionError) validationErrors.push(submissionError.message);
    let bitMismatches = 0, mismatchTuples = 0, nonFiniteLanes = 0, unwrittenLanes = 0;
    const mismatchExamples = [];
    const ranges = {old: {min: [Infinity,Infinity,Infinity,Infinity], max: [-Infinity,-Infinity,-Infinity,-Infinity]}, new: {min: [Infinity,Infinity,Infinity,Infinity], max: [-Infinity,-Infinity,-Infinity,-Infinity]}};
    const records = input.cases.map((c, index) => {
      const offset = index * 4;
      let mismatch = false;
      for (let channel = 0; channel < 4; channel++) {
        if (outputs.old.bits[offset + channel] !== outputs.new.bits[offset + channel]) { bitMismatches++; mismatch = true; }
        for (const variant of ['old', 'new']) {
          const value = outputs[variant].floats[offset + channel];
          if (!Number.isFinite(value)) nonFiniteLanes++;
          if (outputs[variant].bits[offset + channel] === sentry) unwrittenLanes++;
          ranges[variant].min[channel] = Math.min(ranges[variant].min[channel], value);
          ranges[variant].max[channel] = Math.max(ranges[variant].max[channel], value);
        }
      }
      const record = {index, id: c.id, equalBits: !mismatch, oldBits: Array.from(outputs.old.bits.slice(offset, offset + 4), hex), newBits: Array.from(outputs.new.bits.slice(offset, offset + 4), hex), oldRGBA: Array.from(outputs.old.floats.slice(offset, offset + 4)), newRGBA: Array.from(outputs.new.floats.slice(offset, offset + 4))};
      if (mismatch) { mismatchTuples++; if (mismatchExamples.length < 12) mismatchExamples.push(record); }
      return record;
    });
    const valid = !bitMismatches && !nonFiniteLanes && !unwrittenLanes && !validationErrors.length;
    const byScenario = Object.fromEntries([...new Set(input.cases.map(c => c.scenario))].map(name => [name, {tuples: input.cases.filter(c => c.scenario === name).length, mismatchTuples: records.filter((r,i) => input.cases[i].scenario === name && !r.equalBits).length}]));
    const summary = {status: valid ? 'PASS' : 'FAIL', gpuExecuted: true, started, completed: new Date().toISOString(), baselineCommit: provenance.baselineCommit, scope: '216 finite segment tuples; final pre-film RGBA f32 bits only; not full shader or FPS equivalence', adapter: adapter.info ? {vendor: adapter.info.vendor, architecture: adapter.info.architecture, device: adapter.info.device, description: adapter.info.description} : null, tuples: input.count, comparedChannels: input.count * 4, bitMismatches, mismatchTuples, nonFiniteLanes, unwrittenLanes, validationErrors, oldOutputSHA256: outputs.old.sha256, newOutputSHA256: outputs.new.sha256, frozenResources: Object.fromEntries(['cases.json','old.wgsl','new.wgsl','provenance.json'].map(name => [name, manifest.files[name].sha256])), ranges, byScenario, mismatchExamples};
    result.textContent = JSON.stringify(summary, null, 2);
    recordsElement.textContent = JSON.stringify(records, null, 2);
    status.textContent = valid ? 'PASS: tutti gli 864 canali sono identici per bit, finiti e scritti dalla GPU.' : 'FAIL: consultare i conteggi e gli esempi nel JSON.';
  } catch (error) {
    const failure = {status: 'ERROR', gpuExecuted: gpuCompleted, gpuSubmitted, started, completed: new Date().toISOString(), error: String(error?.stack || error), validationErrors};
    result.textContent = JSON.stringify(failure, null, 2);
    status.textContent = 'Errore: nessun PASS assegnato.';
  } finally {
    for (const resource of resources) resource.destroy();
    device?.destroy();
  }
}
button.addEventListener('click', async () => {
  button.disabled = true;
  result.textContent = JSON.stringify({status: 'RUNNING', gpuExecuted: false});
  recordsElement.textContent = 'Confronto in corso.';
  try { await runComparison(); } finally { button.disabled = false; }
});
