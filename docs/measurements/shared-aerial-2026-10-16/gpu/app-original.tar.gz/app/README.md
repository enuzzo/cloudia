# Witness GPU shared aerial: segmenti

Pagina esterna predisposta, **non eseguita dall'autore dell'archivio**. Il root avvia il confronto tramite il pulsante «Esegui confronto segmenti» e legge il JSON nel DOM. Non vengono aperti browser né eseguiti shader durante la preparazione.

Servire questa cartella da localhost, per esempio:

```sh
python3 -m http.server 4199 --bind 127.0.0.1 --directory /Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle15/shared-aerial-witness
```

URL previsto: `http://127.0.0.1:4199/`. Nessun server è avviato da questo archivio. Per verificare gli SHA con sole letture:

```sh
python3 /Users/enuzzo/Documents/Codex/Cloudia-QA-2026-10-16-cycle15/shared-aerial-witness/verify.py
```

La baseline Git `10493` è risolta al commit completo in `provenance.json`. `frozen/` conserva cinque sorgenti originali e il candidato esterno congelato `candidate-cloudShader.ts` (SHA256 `a6e6bf07ed5ce8393d0424dfccfa8bfc7e7d07261c418b0ba51da2f83180da6c`); `aerial.wgsl` e `medium.wgsl` sono estratti dalle effettive costanti template del prodotto. I due shader completi del piccolo harness sono `old.wgsl` e `new.wgsl`, compilati separatamente con gli stessi 216 input. La formula `exp` resta diretta in entrambi; nessuna ricorrenza atmosferica v19. `prepare.py` conserva la procedura di estrazione iniziale: non serve eseguirla per usare la pagina e non va rilanciata nell'archivio congelato.

Il candidato mantiene `rainSource=rainLight` nel ramo della colonna positiva; dopo il gate comune dei mezzi nulli, usa il singolo `aerial` anche per la pioggia soltanto se `rainExtinction>0`. La baseline calcola prima il mix atmosferico per la pioggia, poi il medesimo `aerial` per la nube. L'integrazione finale `cloudMediaSegment` è uguale. Si confronta RGBA **del segmento** prima del film, senza ricomporre la raggiera o l'immagine.

Le 216 tuple sono 6 distanze dalla camera (`0`, `0,006`, `1`, `10`, `16`, `60` km) × 3 haze (`0`, `0,35`, `1`) × 12 scenari: nube sola, pioggia sola, sovrapposizione, colonna positiva con quantità/attachment/evaporazione zero, entrambi i mezzi nulli, colonna nulla, pioggia molto debole positiva, nube di ghiaccio e lunghezza del segmento nulla. Gli altri segmenti mantengono il passo pioggia di 6 m. Le palette sono valori espliciti finiti e non negativi, non una replica della LUT atmosferica di una scena reale.

I lookup texture sono sostituiti da risultati espliciti; anche attachment ed evaporazione sono input. La loro generazione non cambia nel candidato e qui non viene verificata. La branch della raggiera che fa `continue` con entrambi i mezzi nulli restituisce l'identità del compositing `(0,0,0,1)` nell'harness. Il witness non certifica la traversata, le texture, il film, l'intero shader, la presenza/assenza di CSE o alcun guadagno FPS.

Gli output sono scritti dalla GPU come `bitcast<vec4<u32>>` in due buffer distinti inizializzati a una sentinella NaN. PASS richiede zero differenze di bit su tutti gli 864 canali, zero valori non finiti, zero sentinelle residue e nessun errore di validazione GPU. JSON di riepilogo, hash degli output e tutti i record sono visibili nel DOM. Una discrepanza viene riportata come FAIL; l'app non assegna un esito previsto o simulato. Il confronto copre soltanto le tuple selezionate e l'adattatore che le esegue.
