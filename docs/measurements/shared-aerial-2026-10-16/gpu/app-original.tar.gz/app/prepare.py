"""Freeze a small, manually launched GPU segment witness; never runs the GPU."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/enuzzo/Library/CloudStorage/Dropbox/Mitnick/Cloudia')
BASE = subprocess.check_output(['git', 'rev-parse', '10493^{commit}'], cwd=REPO, text=True).strip()
(ROOT / 'frozen').mkdir(exist_ok=True)
sources = {}
for name in ['aerial.ts', 'medium.ts', 'cloudShader.ts', 'precipitation.ts', 'volume.ts']:
    data = subprocess.check_output(['git', 'show', f'{BASE}:src/cumulonimbus/{name}'], cwd=REPO)
    (ROOT / 'frozen' / name).write_bytes(data)
    sources[name] = data.decode()

def constant(name, source):
    found = re.search(r'export const ' + name + r'\s*=\s*([.\d]+)\s*;', source)
    assert found, name
    return float(found[1])

base_a = constant('AERIAL_BASE_EXTINCTION', sources['aerial.ts'])
haze_a = constant('AERIAL_HAZE_EXTINCTION', sources['aerial.ts'])
rain_ext = constant('RAIN_EXTINCTION', sources['precipitation.ts'])
cloud_ext = constant('EXTINCTION', sources['volume.ts'])
ice_ext = constant('ICE_EXTINCTION', sources['volume.ts'])
aerial = re.search(r'export const AERIAL_WGSL=`(.*?)`;', sources['aerial.ts'], re.S)[1]
aerial = aerial.replace('${AERIAL_BASE_EXTINCTION}', str(base_a)).replace('${AERIAL_HAZE_EXTINCTION}', str(haze_a))
media = re.search(r'export const MEDIA_WGSL=`(.*?)`;', sources['medium.ts'], re.S)[1]
assert '${' not in aerial + media
(ROOT / 'aerial.wgsl').write_text(aerial + '\n')
(ROOT / 'medium.wgsl').write_text(media + '\n')

base_lines = [
    'rainSource=mix(sky,rainLight,aerialTransmittance(t,weather.x));',
    'if(density<=0.0&&rainExtinction<=0.0){t+=sampleStep;continue;}',
    'let aerial=aerialTransmittance(t,weather.x);',
    'let cell=cloudMediaSegment(density*mix(extinction,iceExtinction,ice),mix(sky,source,aerial),rainExtinction,rainSource,sampleStep);',
]
for line in base_lines:
    assert line in sources['cloudShader.ts'], line

# Eight vec4<f32> values per tuple. Post-texture material/source inputs are fixed.
# This deliberately excludes textures, ray traversal, film and accumulated rays.
scenarios = [
    dict(id='cloud-region-off', density=.65, rainRegion=0, amount=.8, column=0, attached=1, evaporation=1, ice=0),
    dict(id='column-positive-rain-amount-zero', density=.45, rainRegion=1, amount=0, column=.7, attached=1, evaporation=1, ice=0),
    dict(id='rain-only', density=0, rainRegion=1, amount=1, column=.7, attached=1, evaporation=1, ice=0),
    dict(id='rain-cloud-overlap', density=.75, rainRegion=1, amount=.8, column=.55, attached=.7, evaporation=.8, ice=0),
    dict(id='attachment-zero-cloud-positive', density=.55, rainRegion=1, amount=.8, column=.7, attached=0, evaporation=1, ice=0),
    dict(id='evaporation-zero-cloud-positive', density=.55, rainRegion=1, amount=.8, column=.7, attached=1, evaporation=0, ice=0),
    dict(id='attachment-zero-both-media-zero', density=0, rainRegion=1, amount=.8, column=.7, attached=0, evaporation=1, ice=0),
    dict(id='evaporation-zero-both-media-zero', density=0, rainRegion=1, amount=.8, column=.7, attached=1, evaporation=0, ice=0),
    dict(id='column-zero-cloud-positive', density=.35, rainRegion=1, amount=.8, column=0, attached=1, evaporation=1, ice=.3),
    dict(id='tiny-positive-rain-cloud', density=.2, rainRegion=1, amount=.2, column=1/255, attached=.001, evaporation=.002, ice=.6),
    dict(id='ice-cloud-rain', density=.25, rainRegion=1, amount=.9, column=.8, attached=.9, evaporation=.7, ice=1),
    dict(id='zero-segment-length-overlap', density=.4, rainRegion=1, amount=.6, column=.5, attached=1, evaporation=.6, ice=.4, distance=0),
]
palettes = [
    dict(id='clear', haze=0, overcast=0, mu=1, sky=[.45,.65,1.1], source=[1.3,1.15,.95], ambient=[.65,.75,.9], solar=[1.2,1.05,.9]),
    dict(id='intermediate', haze=.35, overcast=.45, mu=0, sky=[.9,.95,1.05], source=[.55,.62,.75], ambient=[.45,.5,.62], solar=[1.1,.9,.65]),
    dict(id='hazy', haze=1, overcast=1, mu=-1, sky=[.2,.24,.32], source=[.16,.2,.3], ambient=[.22,.27,.36], solar=[.8,.45,.22]),
]
cases = []
for t in [0, .006, 1, 10, 16, 60]:
    for palette in palettes:
        for scenario in scenarios:
            step = scenario.get('distance', .006)
            # Physical values selected within the product's finite, nonnegative domain.
            vectors = [
                [t, palette['haze'], step, scenario['density']],
                [cloud_ext, ice_ext, scenario['ice'], scenario['amount']],
                [scenario['column'], scenario['attached'], scenario['evaporation'], .4],
                [.7, palette['mu'], palette['overcast'], scenario['rainRegion']],
                palette['sky'] + [0], palette['source'] + [0], palette['ambient'] + [0], palette['solar'] + [0],
            ]
            cases.append(dict(index=len(cases), id=f"t={t}/{palette['id']}/{scenario['id']}", scenario=scenario['id'], palette=palette['id'], vectors=vectors))
assert len(cases) == 216 and len(cases) <= 256
(ROOT / 'cases.json').write_text(json.dumps(dict(schema=1, strideFloats=32, count=len(cases), cases=cases), indent=2) + '\n')

prefix = '''// Standalone segment harness, not a complete Cloudia shader.
struct SegmentInput {
  p0:vec4<f32>, p1:vec4<f32>, p2:vec4<f32>, p3:vec4<f32>,
  sky:vec4<f32>, source:vec4<f32>, ambient:vec4<f32>, solar:vec4<f32>,
};
@group(0) @binding(0) var<storage,read> cases:array<SegmentInput>;
@group(0) @binding(1) var<storage,read_write> results:array<vec4<u32>>;
'''
body_before = '''
@compute @workgroup_size(32)
fn compareSegments(@builtin(global_invocation_id) id:vec3<u32>) {
  if(id.x>=arrayLength(&cases)){return;}
  let c=cases[id.x];
  let t=c.p0.x;
  let weather=vec3<f32>(c.p0.y,c.p3.z,c.p1.w);
  let sampleStep=c.p0.z;
  let density=c.p0.w;
  let extinction=c.p1.x;
  let iceExtinction=c.p1.y;
  let ice=c.p1.z;
  let column=c.p2.x;
  let attached=c.p2.y;
  let evaporation=c.p2.z;
  let sheets=c.p2.w;
  let streaks=c.p3.x;
  let mu=c.p3.y;
  let rainRegion=c.p3.w>0.0;
  let sky=c.sky.xyz;
  let source=c.source.xyz;
  let ambientColor=c.ambient.xyz;
  let solarColor=c.solar.xyz;
  var rainExtinction=0.0;
  var rainSource=vec3<f32>(0.0);
  // All lookup results, attachment and evaporation are explicit fixed inputs.
  if(rainRegion){
    if(column>0.0){
      let rainDensity=column*attached*evaporation*(.15+1.85*sheets*sheets)*(.35+1.3*streaks);
      rainExtinction=weather.z*rainDensity*RAIN_EXTINCTION_LITERAL;
      let forwardRain=.08+.2*pow(max(0.0,mu),8.0);
      let rainLight=sky*.25+ambientColor*.28+solarColor*forwardRain*(1.0-weather.y*.7);
      RAIN_SOURCE_ASSIGNMENT
    }
  }
  if(density<=0.0&&rainExtinction<=0.0){
    // The real loop continues, so its compositing identity is returned here.
    results[id.x]=bitcast<vec4<u32>>(vec4<f32>(0.0,0.0,0.0,1.0));
    return;
  }
  let aerial=aerialTransmittance(t,weather.x);
  SHARED_AERIAL_ASSIGNMENT
  let cell=cloudMediaSegment(density*mix(extinction,iceExtinction,ice),mix(sky,source,aerial),rainExtinction,rainSource,sampleStep);
  results[id.x]=bitcast<vec4<u32>>(cell);
}
'''.replace('RAIN_EXTINCTION_LITERAL', str(rain_ext))
variants = {
    'old': ('rainSource=mix(sky,rainLight,aerialTransmittance(t,weather.x));', ''),
    'new': ('rainSource=rainLight;', 'if(rainExtinction>0.0){rainSource=mix(sky,rainSource,aerial);}'),
}
for name, (assignment, shared) in variants.items():
    body = body_before.replace('RAIN_SOURCE_ASSIGNMENT', assignment).replace('SHARED_AERIAL_ASSIGNMENT', shared)
    (ROOT / f'{name}.wgsl').write_text(prefix + aerial + '\n' + media + '\n' + body)

provenance = dict(schema=1, baselineCommit=BASE, baselineShort='10493', tupleCount=len(cases),
    sourceScope='AERIAL_WGSL and MEDIA_WGSL extracted from frozen product. Rain/source/composition expressions retain product order. Textures, ray traversal, film and full-render compilation excluded.',
    candidateScope='Rainy specialization only: raw rainLight assigned first; if rainExtinction>0, mix with the common direct aerialTransmittance after the unchanged zero-media gate.',
    constants=dict(aerialBase=base_a, aerialHaze=haze_a, rainExtinction=rain_ext, cloudExtinction=cloud_ext, iceExtinction=ice_ext),
    frozenSources={name: dict(bytes=len(text.encode()), sha256=hashlib.sha256(text.encode()).hexdigest()) for name,text in sources.items()},
    directProductLines=base_lines,
    exclusions=['No textures or rain bounds', 'No flow, morphology or cache bake', 'No full ray accumulation or film', 'No proof of full shader equivalence', 'No performance or CSE measurement', 'Finite selected tuples only; no exhaustive f32-domain proof'])
(ROOT / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
print(json.dumps(dict(status='PREPARED_NOT_RUN', baselineCommit=BASE, tuples=len(cases)), indent=2))
