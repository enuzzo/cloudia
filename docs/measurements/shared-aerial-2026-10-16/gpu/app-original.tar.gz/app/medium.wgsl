
fn cloudMediaSegment(cloudExtinction:f32,cloudSource:vec3<f32>,rainExtinction:f32,rainSource:vec3<f32>,distance:f32)->vec4<f32>{
  let extinction=cloudExtinction+rainExtinction;
  if(extinction<=0.0||distance<=0.0){return vec4<f32>(0.0,0.0,0.0,1.0);}
  let opacity=1.0-exp(-extinction*distance);
  let source=(cloudSource*cloudExtinction+rainSource*rainExtinction)/extinction;
  return vec4<f32>(source*opacity,1.0-opacity);
}
