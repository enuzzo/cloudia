// Standalone segment harness, not a complete Cloudia shader.
struct SegmentInput {
  p0:vec4<f32>, p1:vec4<f32>, p2:vec4<f32>, p3:vec4<f32>,
  sky:vec4<f32>, source:vec4<f32>, ambient:vec4<f32>, solar:vec4<f32>,
};
@group(0) @binding(0) var<storage,read> cases:array<SegmentInput>;
@group(0) @binding(1) var<storage,read_write> results:array<vec4<u32>>;

fn aerialTransmittance(distanceKm:f32,haze:f32)->f32{
  return exp(-distanceKm*(0.006+0.004*haze));
}

fn cloudMediaSegment(cloudExtinction:f32,cloudSource:vec3<f32>,rainExtinction:f32,rainSource:vec3<f32>,distance:f32)->vec4<f32>{
  let extinction=cloudExtinction+rainExtinction;
  if(extinction<=0.0||distance<=0.0){return vec4<f32>(0.0,0.0,0.0,1.0);}
  let opacity=1.0-exp(-extinction*distance);
  let source=(cloudSource*cloudExtinction+rainSource*rainExtinction)/extinction;
  return vec4<f32>(source*opacity,1.0-opacity);
}

@compute @workgroup_size(32)
fn compareSegments(@builtin(global_invocation_id) id:vec3<u32>) {
  if(id.x>=arrayLength(&cases)){return;}
  let c=cases[id.x];
  let t=c.p0.x;
  let weather=vec3<f32>(c.p0.y,c.p3.z,c.p1.w);
  let sampleStep=c.p0.z;
  let density=c.p0.w;
  let extinction=c.p1.x;
  let iceExtinction=c.p1.y;
  let ice=c.p1.z;
  let column=c.p2.x;
  let attached=c.p2.y;
  let evaporation=c.p2.z;
  let sheets=c.p2.w;
  let streaks=c.p3.x;
  let mu=c.p3.y;
  let rainRegion=c.p3.w>0.0;
  let sky=c.sky.xyz;
  let source=c.source.xyz;
  let ambientColor=c.ambient.xyz;
  let solarColor=c.solar.xyz;
  var rainExtinction=0.0;
  var rainSource=vec3<f32>(0.0);
  // All lookup results, attachment and evaporation are explicit fixed inputs.
  if(rainRegion){
    if(column>0.0){
      let rainDensity=column*attached*evaporation*(.15+1.85*sheets*sheets)*(.35+1.3*streaks);
      rainExtinction=weather.z*rainDensity*0.85;
      let forwardRain=.08+.2*pow(max(0.0,mu),8.0);
      let rainLight=sky*.25+ambientColor*.28+solarColor*forwardRain*(1.0-weather.y*.7);
      rainSource=rainLight;
    }
  }
  if(density<=0.0&&rainExtinction<=0.0){
    // The real loop continues, so its compositing identity is returned here.
    results[id.x]=bitcast<vec4<u32>>(vec4<f32>(0.0,0.0,0.0,1.0));
    return;
  }
  let aerial=aerialTransmittance(t,weather.x);
  if(rainExtinction>0.0){rainSource=mix(sky,rainSource,aerial);}
  let cell=cloudMediaSegment(density*mix(extinction,iceExtinction,ice),mix(sky,source,aerial),rainExtinction,rainSource,sampleStep);
  results[id.x]=bitcast<vec4<u32>>(cell);
}
