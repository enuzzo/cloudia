
fn aerialTransmittance(distanceKm:f32,haze:f32)->f32{
  return exp(-distanceKm*(0.006+0.004*haze));
}
