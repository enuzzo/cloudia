"""Verify frozen witness payloads using file I/O only. Does not run the witness."""
from pathlib import Path
import hashlib
import json
base = Path(__file__).resolve().parent
manifest = json.loads((base / 'manifest.json').read_text())
observed = {}
for path in sorted(base.rglob('*')):
    assert not path.is_symlink(), path
    if path.is_file() and path != base / 'manifest.json':
        data = path.read_bytes()
        observed[str(path.relative_to(base))] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
assert observed == manifest['files'], 'Payload list, size or SHA256 differs'
assert sum(v['bytes'] for v in observed.values()) == manifest['payloadBytes']
print(json.dumps(dict(status='PASS', scope='File integrity only; GPU witness not executed', payloads=len(observed), payloadBytes=manifest['payloadBytes']), indent=2))
