import {afterAll,afterEach,describe,expect,it,vi} from 'vitest';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {dirname,join} from 'node:path';
vi.mock('three/tsl',async(importOriginal)=>{
  const actual=await importOriginal<typeof import('three/tsl')>();
  return {...actual,wgslFn:vi.fn(actual.wgslFn)};
});
import {wgslFn} from 'three/tsl';
import {createCloudIntegrator} from './cloudShader';
import {createCloudIntegrator as original10493} from '../../../baseline-source/src/cumulonimbus/cloudShader';

const hash=(code:string)=>createHash('sha256').update(code).digest('hex');
const restore=(code:string)=>code
  .replace('rainSource=rainLight;','rainSource=mix(sky,rainLight,aerialTransmittance(t,weather.x));')
  .replace('\n    if(rainExtinction>0.0){rainSource=mix(sky,rainSource,aerial);}','');
function capture(factory:typeof createCloudIntegrator,mode:number,narrow:boolean,r8:boolean){
  factory(mode,narrow,r8);
  const call=vi.mocked(wgslFn).mock.calls.at(-1);
  if(!call||typeof call[0]!=='string')throw new Error('Missing actual FunctionNode source.');
  return {code:call[0],libraries:(call[1]??[]).map(node=>Reflect.get(node,'code') as string)};
}
const witnesses:Array<Record<string,unknown>>=[];
const output=process.env.CLOUDIA_TEMPLATE_WITNESS_PATH;
afterEach(()=>vi.clearAllMocks());
afterAll(()=>{
  if(!output)return;
  mkdirSync(dirname(output),{recursive:true});
  writeFileSync(output,JSON.stringify({baseCommit:'10493af',scope:'Actual CPU Three wgslFn source and include-library hashes, not driver WGSL or rendered pixels.',witnesses},null,2)+'\n');
});

describe('rain-only shared aerial trial against frozen10493',()=>{
  it('pins the original factory file from the verified checkpoint',()=>{
    const source=readFileSync(join(process.cwd(),'../baseline-source/src/cumulonimbus/cloudShader.ts'),'utf8');
    expect(hash(source)).toBe('652c9514b7dfcee1456d15e9966087b3ff9c6a6ce9741970208cfca3750a248c');
  });
  it('pins the unmodified dry default directly to its original10493 WGSL hash',()=>{
    const expected='59523937da9df384aa57345fb99c758cee70bc83c5ada8d3084038dfa416f546';
    expect(hash(capture(original10493,0,false,false).code)).toBe(expected);
    expect(hash(capture(createCloudIntegrator,0,false,false).code)).toBe(expected);
  });
  it('preserves the entire dry specialization and changes only rain assignment and deferred mix in all guarded variants',()=>{
    for(const narrow of [false,true])for(const r8 of [false,true])for(let mode=0;mode<=5;mode++){
      const baseline=capture(original10493,mode,narrow,r8),candidate=capture(createCloudIntegrator,mode,narrow,r8);
      expect(candidate.libraries).toEqual(baseline.libraries);
      if(!narrow&&!r8)expect(candidate.code).toBe(baseline.code);
      else{
        expect(candidate.code).not.toBe(baseline.code);
        expect(restore(candidate.code)).toBe(baseline.code);
        expect(candidate.code.match(/aerialTransmittance\(t,weather\.x\)/g)).toHaveLength(1);
        const assignment=candidate.code.indexOf('rainSource=rainLight;');
        const gate=candidate.code.indexOf('if(density<=0.0&&rainExtinction<=0.0){t+=sampleStep;continue;}');
        const factor=candidate.code.indexOf('let aerial=aerialTransmittance(t,weather.x);');
        const deferred=candidate.code.indexOf('if(rainExtinction>0.0){rainSource=mix(sky,rainSource,aerial);}');
        const segment=candidate.code.indexOf('let cell=cloudMediaSegment(');
        expect(assignment).toBeGreaterThan(0);expect(gate).toBeGreaterThan(assignment);
        expect(factor).toBeGreaterThan(gate);expect(deferred).toBeGreaterThan(factor);expect(segment).toBeGreaterThan(deferred);
      }
      witnesses.push({mode,useNarrow:narrow,useDensityR8:r8,guarded:narrow||r8,baselineSha256:hash(baseline.code),candidateSha256:hash(candidate.code),restoredSha256:hash(restore(candidate.code)),librarySha256:baseline.libraries.map(hash)});
      if(output&&mode===0){
        const folder=join(dirname(output),'effective-templates');mkdirSync(folder,{recursive:true});
        writeFileSync(join(folder,`baseline-n${+narrow}-r${+r8}.wgsl`),baseline.code);
        writeFileSync(join(folder,`candidate-n${+narrow}-r${+r8}.wgsl`),candidate.code);
      }
    }
  });
  it('keeps invalid diagnostic fallback behavior equal to the default for each existing boolean combination',()=>{
    for(const narrow of [false,true])for(const r8 of [false,true])for(const mode of [-1,6,NaN]){
      expect(capture(createCloudIntegrator,mode,narrow,r8)).toEqual(capture(createCloudIntegrator,0,narrow,r8));
    }
  });
});
