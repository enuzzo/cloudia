/** PREPARATION ONLY. Root must freeze/review run.py before invoking either mode.
 * Exactly one candidate mesh build per mode. No old-module rebuild, GPU, rays,
 * app/volume construction, parameter search or extra measurement nodes.
 */
import {createHash} from 'node:crypto';
import {closeSync,openSync,readFileSync,writeFileSync,writeSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {buildTerrainMeshData,terrainMeshHeightAt,terrainMeshSurfaceY,type TerrainMeshData} from '../refine-source/src/cumulonimbus/terrainMesh.ts';
import {createDemTerrainSampler,decodeTerrainDem,sampleTerrainDem} from '../refine-source/src/cumulonimbus/terrainDem.ts';
import {terrainSurfaceSample} from '../refine-source/src/cumulonimbus/terrainSurface.ts';

const HERE=dirname(fileURLToPath(import.meta.url));
const SOURCE=resolve(HERE,'../refine-source');
const SOURCE_MANIFEST=resolve(HERE,'../refine-qualification-r1/source-manifest.json');
const BASELINE=resolve(HERE,'../geometry-preflight/run/result.json');
const EXPECTED_SOURCE='83469d62c552db7bad9cbc175bf549f7b7c0bd8c0b113c137e484e1b4f315e00';
const EXPECTED_BASELINE='5ae2135e94ffca23757f07ae985b01033d5fedf985971e2439b04d6033c71a27';
const EXPECTED_DEM='92b28f01e75692c8fba744f6b1161df578c29daa76d8d278ee20a8ce87ba071d';
const EXPECTED_OFF_STREAM='6e5ff2fecacc6a7928dc927f341906f04b369cbbd976357d31f63d2faedf191a';
const OPTIONS={cellsPerSide:256,levels:9,spacingKm:.032,normalMode:'geometry' as const};
const LIMITS={maxProbeCount:600000,maxVertices:1000000,maxTriangles:2000000,maxGeometryBytes:64*1024*1024};
const FIRST=128,LAST=896,NODES=591361,QUERY_CAP=600000,TOP_K=8;
const HIST_MIN=-5000,HIST_MAX=5000,HIST_BINS=10002;
const MAX_OUTPUT_BYTES=4*1024*1024,STREAM_BYTES=NODES*8;
const started=performance.now();
function check(condition:unknown,message:string):asserts condition{if(!condition)throw new Error(message);}
function sha(bytes:Uint8Array):string{return createHash('sha256').update(bytes).digest('hex');}
function typedSha(array:ArrayBufferView):string{return sha(new Uint8Array(array.buffer,array.byteOffset,array.byteLength));}
function progress(phase:string,extra:Record<string,unknown>={}):void{
 console.error(JSON.stringify({phase,elapsedSeconds:(performance.now()-started)/1000,...extra}));
}
function canonical(value:unknown):string{
 if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';
 if(value!==null&&typeof value==='object')return '{'+Object.entries(value).sort(([a],[b])=>a<b?-1:a>b?1:0).map(([key,v])=>JSON.stringify(key)+':'+canonical(v)).join(',')+'}';
 const encoded=JSON.stringify(value);check(encoded!==undefined,'Unsupported canonical value');return encoded;
}
function exact(a:unknown,b:unknown,label:string):void{check(canonical(a)===canonical(b),label);}
type Point={order:number;grid:[number,number];xzKm:[number,number];ring:number;category:'coast>=0'|'coast<0';heightCode:number;coastCode:number;heightKm:number;meshYKm:number;demYKm:number;errorMetres:number};
class CompensatedSum{
 sum=0;correction=0;
 add(value:number):void{const y=value-this.correction,t=this.sum+y;this.correction=(t-this.sum)-y;this.sum=t;}
}
class Aggregate{
 count=0;readonly sum=new CompensatedSum();readonly sumSquares=new CompensatedSum();
 readonly histogram=new Uint32Array(HIST_BINS);
 minimum:Point|null=null;maximum:Point|null=null;maximumAbs:Point|null=null;
 minimumTies=0;maximumTies=0;maximumAbsTies=0;
 readonly positive:Point[]=[];readonly negative:Point[]=[];readonly absolute:Point[]=[];
 add(error:number,point:()=>Point):void{
  this.count++;this.sum.add(error);this.sumSquares.add(error*error);
  const bin=error<HIST_MIN?0:error>=HIST_MAX?HIST_BINS-1:Math.floor(error-HIST_MIN)+1;
  this.histogram[bin]++;
  if(!this.minimum||error<this.minimum.errorMetres){this.minimum=point();this.minimumTies=1;}else if(error===this.minimum.errorMetres)this.minimumTies++;
  if(!this.maximum||error>this.maximum.errorMetres){this.maximum=point();this.maximumTies=1;}else if(error===this.maximum.errorMetres)this.maximumTies++;
  if(!this.maximumAbs||Math.abs(error)>Math.abs(this.maximumAbs.errorMetres)){this.maximumAbs=point();this.maximumAbsTies=1;}else if(Math.abs(error)===Math.abs(this.maximumAbs.errorMetres))this.maximumAbsTies++;
  this.retain(this.absolute,Math.abs(error),point,p=>Math.abs(p.errorMetres));
  if(error>0)this.retain(this.positive,error,point,p=>p.errorMetres);
  if(error<0)this.retain(this.negative,-error,point,p=>-p.errorMetres);
 }
 private retain(list:Point[],score:number,point:()=>Point,scoreOf:(p:Point)=>number):void{
  if(list.length===TOP_K&&score<=scoreOf(list[list.length-1]))return;
  const record=point();let i=0;while(i<list.length&&score<=scoreOf(list[i]))i++;
  list.splice(i,0,record);if(list.length>TOP_K)list.pop();
 }
 result():Record<string,unknown>{
  let histCount=0;for(const n of this.histogram)histCount+=n;
  check(histCount===this.count,'Histogram count mismatch');
  return {count:this.count,sumErrorMetres:this.sum.sum,sumSquaredErrorMetres2:this.sumSquares.sum,
   signedMeanMetres:this.count?this.sum.sum/this.count:null,rmsMetres:this.count?Math.sqrt(this.sumSquares.sum/this.count):null,
   minimum:this.minimum,minimumTies:this.minimumTies,maximum:this.maximum,maximumTies:this.maximumTies,
   maximumAbs:this.maximumAbs,maximumAbsTies:this.maximumAbsTies,
   top8Absolute:this.absolute,top8Positive:this.positive,top8Negative:this.negative,
   histogramCounts:Array.from(this.histogram)};
 }
}
type PairPoint={order:number;grid:[number,number];xzKm:[number,number];ring:number;category:'coast>=0'|'coast<0';offErrorMetres:number;onErrorMetres:number;absoluteErrorDeltaMetres:number};
class PairedAggregate{
 count=0;improved=0;worsened=0;equal=0;signFlips=0;offAbove5m=0;onAbove5m=0;enteredAbove5m=0;leftAbove5m=0;
 readonly offSquared=new CompensatedSum();readonly onSquared=new CompensatedSum();readonly absoluteDelta=new CompensatedSum();
 readonly regressions:PairPoint[]=[];readonly improvements:PairPoint[]=[];
 add(off:number,on:number,point:()=>PairPoint):void{
  this.count++;const a=Math.abs(off),b=Math.abs(on),delta=b-a;
  if(b<a)this.improved++;else if(b>a)this.worsened++;else this.equal++;
  if(off*on<0)this.signFlips++;
  if(a>5)this.offAbove5m++;if(b>5)this.onAbove5m++;
  if(a<=5&&b>5)this.enteredAbove5m++;if(a>5&&b<=5)this.leftAbove5m++;
  this.offSquared.add(off*off);this.onSquared.add(on*on);this.absoluteDelta.add(delta);
  if(delta>0)this.retain(this.regressions,delta,point,p=>p.absoluteErrorDeltaMetres);
  if(delta<0)this.retain(this.improvements,-delta,point,p=>-p.absoluteErrorDeltaMetres);
 }
 private retain(list:PairPoint[],score:number,point:()=>PairPoint,scoreOf:(p:PairPoint)=>number):void{
  if(list.length===TOP_K&&score<=scoreOf(list[list.length-1]))return;
  const record=point();let i=0;while(i<list.length&&score<=scoreOf(list[i]))i++;
  list.splice(i,0,record);if(list.length>TOP_K)list.pop();
 }
 result():Record<string,unknown>{
  check(this.improved+this.worsened+this.equal===this.count,'Paired partition mismatch');
  return {count:this.count,improved:this.improved,worsened:this.worsened,equalAbsoluteError:this.equal,
   signFlips:this.signFlips,offAbove5m:this.offAbove5m,onAbove5m:this.onAbove5m,enteredAbove5m:this.enteredAbove5m,leftAbove5m:this.leftAbove5m,
   sumOffSquaredErrorMetres2:this.offSquared.sum,sumOnSquaredErrorMetres2:this.onSquared.sum,
   offRMSMetres:this.count?Math.sqrt(this.offSquared.sum/this.count):null,onRMSMetres:this.count?Math.sqrt(this.onSquared.sum/this.count):null,
   sumAbsoluteErrorDeltaMetres:this.absoluteDelta.sum,top8Regressions:this.regressions,top8Improvements:this.improvements};
 }
}
function ringAt(x:number,z:number):number{
 const radius=Math.max(Math.abs(x),Math.abs(z));let ring=0;
 while(ring<OPTIONS.levels&&radius>Math.fround(OPTIONS.cellsPerSide/2*OPTIONS.spacingKm*2**ring))ring++;
 return ring;
}
function verifyMesh(mesh:TerrainMeshData,on:boolean,observedCalls:number,old:any):Record<string,unknown>{
 const {vertices:v,triangles:t}=mesh.stats;
 check(mesh.positions.length===3*v&&mesh.normals.length===3*v&&mesh.surface.length===2*v&&mesh.indices.length===3*t,'Typed-array dimensions differ from stats');
 check(mesh.cellFirstIndex.length===OPTIONS.levels*OPTIONS.cellsPerSide**2,'Cell first-index size mismatch');
 const bytes=mesh.positions.byteLength+mesh.normals.byteLength+mesh.surface.byteLength+mesh.indices.byteLength;
 check(bytes===mesh.stats.geometryBytes&&bytes===32*v+12*t,'Geometry payload byte count mismatch');
 for(const array of [mesh.positions,mesh.normals,mesh.surface])for(const n of array)check(Number.isFinite(n),'Nonfinite geometry attribute');
 let maxIndex=0;for(const index of mesh.indices){check(index<v,'Out-of-range vertex index');maxIndex=Math.max(maxIndex,index);}
 const meshHashes={positions:typedSha(mesh.positions),normals:typedSha(mesh.normals),surface:typedSha(mesh.surface),indices:typedSha(mesh.indices),cellFirstIndex:typedSha(mesh.cellFirstIndex)};
 let cursor=0,visibleCells=0,holeCells=0,maxCellTriangles=0;
 check(on?mesh.cellTriangleCount?.length===mesh.cellFirstIndex.length:mesh.cellTriangleCount===undefined,'Unexpected cell-count array presence/size');
 const cells=OPTIONS.cellsPerSide,half=cells/2,hole=cells/4;
 for(let level=0;level<OPTIONS.levels;level++)for(let z=-half;z<half;z++)for(let x=-half;x<half;x++){
  const cell=(level*cells+z+half)*cells+x+half,first=mesh.cellFirstIndex[cell];
  const missing=level>0&&x>=-hole&&x<hole&&z>=-hole&&z<hole;
  if(missing){holeCells++;check(first===0xffffffff&&(!on||mesh.cellTriangleCount![cell]===0),'Hole cell has live triangle range');continue;}
  visibleCells++;check(first===cursor,'Visible cell ranges are not contiguous');
  const next=on?mesh.cellTriangleCount![cell]:((level>0&&((x===hole&&z>=-hole&&z<hole)||(z===-hole-1&&x>=-hole&&x<hole)||(x===-hole-1&&z>=-hole&&z<hole)||(z===hole&&x>=-hole&&x<hole)))?5:2);
  check(Number.isInteger(next)&&next>=2&&next<=(on?20:5),'Cell triangle count outside bounded lookup');
  maxCellTriangles=Math.max(maxCellTriangles,next);cursor+=3*next;
 }
 check(cursor===mesh.indices.length&&visibleCells+holeCells===mesh.cellFirstIndex.length,'Cell ranges do not cover every index exactly');
 check(observedCalls===mesh.stats.sampleCalls,'Observed sample calls differ from mesh stats');
 const prefixPositions=typedSha(mesh.positions.subarray(0,old.meshStats.vertices*3));
 const prefixSurface=typedSha(mesh.surface.subarray(0,old.meshStats.vertices*2));
 check(prefixPositions===old.baselineIdentity.meshHashes.positions&&prefixSurface===old.baselineIdentity.meshHashes.surface,'Original position/surface prefix changed');
 if(!on){
  exact(meshHashes,old.baselineIdentity.meshHashes,'OFF: one or more of five historical buffer hashes differ');
  exact(mesh.stats,old.meshStats,'OFF: historical mesh stats differ');
  check(observedCalls===old.buildSampleCalls,'OFF: historical sampler count differs');
 }else{
  const r=mesh.stats.refinement;check(r,'ON: refinement stats absent');
  check(r.originalVertices===old.meshStats.vertices&&r.originalTriangles===old.meshStats.triangles,'ON: original counts changed');
  check(r.probeSampleCalls===NODES&&r.selectedNodeColumns===769&&r.selectedNodeRows===769,'ON: source-node selection count changed');
  check(r.vertexSampleCalls===v&&r.totalSampleCalls===v+NODES,'ON: sampler decomposition mismatch');
  check(r.addedVertices===v-r.originalVertices&&r.splitEdgeCount===r.addedVertices&&r.addedTriangles===t-r.originalTriangles,'ON: added geometry stats mismatch');
  check(r.addedGeometryBytes===bytes-old.meshStats.geometryBytes&&r.cellTriangleCountBytes===mesh.cellTriangleCount!.byteLength,'ON: added byte stats mismatch');
  check(r.maximumCellTriangles===maxCellTriangles,'ON: max cell count statistic mismatch');
  check(r.originalFacesBySplitEdgeCount.reduce((s,n)=>s+n,0)===r.originalTriangles,'ON: original split-face partition mismatch');
  check(v<=LIMITS.maxVertices&&t<=LIMITS.maxTriangles&&bytes<=LIMITS.maxGeometryBytes,'ON: exact engine geometry budget exceeded');
 }
 return {meshHashes,prefixHashes:{positions:prefixPositions,surface:prefixSurface},originalPositionAndSurfacePrefixesExact:true,
  cellRanges:{visibleCells,holeCells,indexCount:cursor,maximumCellTriangles:maxCellTriangles,completeContiguous:true},
  indicesInRange:true,maximumVertexIndex:maxIndex,attributesFinite:true,
  cellTriangleCountSHA256:mesh.cellTriangleCount?typedSha(mesh.cellTriangleCount):null,
  CPUCellLookupBytes:mesh.cellFirstIndex.byteLength+(mesh.cellTriangleCount?.byteLength??0),
  historicalFiveBufferHashesExact:!on,historicalAllMeshStatsExact:!on,
  originalFaceIndexIdentityClaim:false};
}
function main():void{
 check(process.argv.length===4,'Usage: witness.ts off|on EXCLUSIVE_MODE_OUTPUT_DIRECTORY');
 const mode=process.argv[2];check(mode==='off'||mode==='on','Unknown mode');const on=mode==='on';
 check(process.env.CLOUDIA_REFINE_WITNESS_APPROVED==='cycle28-prepared-r1','Invoke only approved run.py');
 const output=resolve(process.argv[3]);check(output===resolve(HERE,'run-'+mode),'Unexpected output directory');
 check(sha(readFileSync(SOURCE_MANIFEST))===EXPECTED_SOURCE,'Candidate source manifest mismatch');
 const baselineRaw=readFileSync(BASELINE);check(sha(baselineRaw)===EXPECTED_BASELINE,'Historical result mismatch');
 const old=JSON.parse(baselineRaw.toString('utf8'));
 check(old.errorStream.sha256===EXPECTED_OFF_STREAM&&old.errorStream.bytes===STREAM_BYTES,'Historical error digest/length mismatch');
 const demRaw=readFileSync(resolve(SOURCE,'src/cumulonimbus/assets/liguria-apuane-dem.bin'));check(sha(demRaw)===EXPECTED_DEM,'DEM hash mismatch');
 const grid=decodeTerrainDem(demRaw.buffer.slice(demRaw.byteOffset,demRaw.byteOffset+demRaw.byteLength) as ArrayBuffer);
 check(grid.side===1025&&grid.spacingKm===.125&&grid.minX===-64&&grid.minZ===-64,'Unexpected DEM domain');
 check((LAST-FIRST+1)**2===NODES&&NODES<=QUERY_CAP,'Frozen query plan mismatch');
 let offStream:Buffer|null=null,offProvenance:Record<string,unknown>|null=null;
 if(on){
  const offRunRaw=readFileSync(resolve(HERE,'run-off/run.json')),offRun=JSON.parse(offRunRaw.toString('utf8'));
  check(offRun.status==='PASS'&&offRun.mode==='off'&&offRun.budgetPASS===true&&offRun.terminalObserved===true&&offRun.exitCode===0,'ON requires completed OFF parity and terminal budget PASS');
  const offResultRaw=readFileSync(resolve(HERE,'run-off/result.json'));check(sha(offResultRaw)===offRun.resultSHA256,'OFF result differs from terminal record');
  const offResult=JSON.parse(offResultRaw.toString('utf8'));
  check(offResult.status==='OFF_PARITY_PASS_NODES_ONLY'&&offResult.sourceManifestSHA256===EXPECTED_SOURCE,'OFF parity provenance mismatch');
  offStream=readFileSync(resolve(HERE,'run-off/errors.f64le'));
  check(offStream.length===STREAM_BYTES&&sha(offStream)===EXPECTED_OFF_STREAM,'Authenticated OFF reproduction stream mismatch');
  check(offResult.errorStream.sha256===EXPECTED_OFF_STREAM&&offResult.errorStream.retained===true,'OFF result stream mismatch');
  offProvenance={runSHA256:sha(offRunRaw),resultSHA256:sha(offResultRaw),errorStreamSHA256:EXPECTED_OFF_STREAM,
   bytes:STREAM_BYTES,origin:'New OFF reproduction authenticated by all five historical buffers, exact stats and historical node error digest; original historical stream was not retained'};
 }
 const refinement={sourceGrid:{minXKm:grid.minX,minZKm:grid.minZ,spacingKm:grid.spacingKm,columns:grid.side,rows:grid.side},
  domain:{minXKm:-48,maxXKm:48,minZKm:-48,maxZKm:48},maxErrorKm:.005,limits:LIMITS};
 const options=on?{...OPTIONS,refinement}:OPTIONS;
 const sampler=createDemTerrainSampler(grid,terrainSurfaceSample);let buildSampleCalls=0;
 progress('mesh-build-start',{mode,options});const buildStart=performance.now();
 const mesh=buildTerrainMeshData((x,z)=>{buildSampleCalls++;return sampler(x,z);},options);
 const buildMs=performance.now()-buildStart;
 const identity=verifyMesh(mesh,on,buildSampleCalls,old);progress('mesh-invariants-pass',{mode,vertices:mesh.stats.vertices,triangles:mesh.stats.triangles,buildMs});
 const makeGroup=()=>({all:new Aggregate(),landMask:new Aggregate(),seaMask:new Aggregate()});
 const global=makeGroup(),rings=Array.from({length:5},makeGroup);
 const makePairGroup=()=>({all:new PairedAggregate(),landMask:new PairedAggregate(),seaMask:new PairedAggregate()});
 const paired=on?makePairGroup():null,pairRings=on?Array.from({length:5},makePairGroup):null;
 const hash=createHash('sha256'),chunk=Buffer.allocUnsafe(8192*8);let used=0,streamWritten=0;
 const fd=openSync(resolve(output,'errors.f64le'),'wx');
 function flush():void{
  if(!used)return;const bytes=chunk.subarray(0,used);hash.update(bytes);let written=0;
  while(written<bytes.length){const n=writeSync(fd,bytes,written,bytes.length-written);check(n>0,'Stream write made no progress');written+=n;}
  streamWritten+=used;used=0;
 }
 let queries=0;const queryStart=performance.now();let lastProgress=performance.now();
 try{
  for(let iz=FIRST;iz<=LAST;iz++)for(let ix=FIRST;ix<=LAST;ix++){
   check(queries<QUERY_CAP,'Measurement query cap exceeded');
   const x=grid.minX+ix*grid.spacingKm,z=grid.minZ+iz*grid.spacingKm,index=iz*grid.side+ix;
   const measured=sampleTerrainDem(grid,x,z);check(measured,'Measurement node outside DEM');
   check(measured.heightKm===grid.heights[index]*.000125&&measured.coastKm===grid.coast[index]*.008,'DEM node decode mismatch');
   const yMesh=terrainMeshHeightAt(mesh,x,z);check(yMesh!==null&&Number.isFinite(yMesh),'Missing/nonfinite mesh lookup');
   const yDem=terrainMeshSurfaceY(x,z,measured.heightKm),error=1000*(yDem-yMesh),ring=ringAt(x,z);
   check(Number.isFinite(error)&&ring>=0&&ring<5,'Nonfinite error or unexpected ring');
   const land=measured.coastKm>=0,order=queries;let record:Point|undefined;
   const point=():Point=>record??=({order,grid:[ix,iz],xzKm:[x,z],ring,category:land?'coast>=0':'coast<0',heightCode:grid.heights[index],coastCode:grid.coast[index],heightKm:measured.heightKm,meshYKm:yMesh,demYKm:yDem,errorMetres:error});
   global.all.add(error,point);(land?global.landMask:global.seaMask).add(error,point);
   rings[ring].all.add(error,point);(land?rings[ring].landMask:rings[ring].seaMask).add(error,point);
   if(paired&&pairRings&&offStream){
    const off=offStream.readDoubleLE(queries*8);check(Number.isFinite(off),'Nonfinite authenticated OFF error');let pairRecord:PairPoint|undefined;
    const pairPoint=():PairPoint=>pairRecord??=({order,grid:[ix,iz],xzKm:[x,z],ring,category:land?'coast>=0':'coast<0',offErrorMetres:off,onErrorMetres:error,absoluteErrorDeltaMetres:Math.abs(error)-Math.abs(off)});
    paired.all.add(off,error,pairPoint);(land?paired.landMask:paired.seaMask).add(off,error,pairPoint);
    pairRings[ring].all.add(off,error,pairPoint);(land?pairRings[ring].landMask:pairRings[ring].seaMask).add(off,error,pairPoint);
   }
   chunk.writeDoubleLE(error,used);used+=8;if(used===chunk.length)flush();queries++;
   if(ix===LAST&&performance.now()-lastProgress>=5000){progress('core-progress',{mode,queries,total:NODES});lastProgress=performance.now();}
  }
  flush();
 }finally{closeSync(fd);}
 check(queries===NODES&&streamWritten===STREAM_BYTES&&global.all.count===NODES,'Incomplete node stream');
 check(global.landMask.count+global.seaMask.count===NODES&&rings.reduce((n,r)=>n+r.all.count,0)===NODES,'Mask/ring partition mismatch');
 for(const ring of rings)check(ring.all.count===ring.landMask.count+ring.seaMask.count,'Ring mask partition mismatch');
 const streamSHA=hash.digest('hex');if(!on)check(streamSHA===EXPECTED_OFF_STREAM,'OFF: historical complete error stream digest differs');
 const pack=(group:typeof global)=>({all:group.all.result(),landMask:group.landMask.result(),seaMask:group.seaMask.result()});
 const aggregate=pack(global),ringResults=rings.map((group,ring)=>({ring,outerHalfExtentKm:Math.fround(128*.032*2**ring),...pack(group)}));
 if(!on){exact(aggregate,old.aggregate,'OFF: historical aggregate differs');exact(ringResults,old.rings,'OFF: historical rings differ');}
 const packPair=(group:NonNullable<typeof paired>)=>({all:group.all.result(),landMask:group.landMask.result(),seaMask:group.seaMask.result()});
 const result={status:on?'ON_FIT_COMPLETE_NODES_ONLY':'OFF_PARITY_PASS_NODES_ONLY',mode,
  scope:'One candidate build per mode; same 591361 source nodes, OFF historical parity then ON fit on selection nodes. No holdout, render, art or FPS qualification.',
  sourceManifestSHA256:EXPECTED_SOURCE,historicalResultSHA256:EXPECTED_BASELINE,assetSHA256:EXPECTED_DEM,
  runtime:{bun:process.versions.bun,architecture:process.arch,platform:process.platform},
  plan:{firstSourceIndex:FIRST,lastSourceIndex:LAST,side:769,nodes:NODES,queryCap:QUERY_CAP,order:'increasing iz then ix; both inclusive',coreKm:[-48,48],options},
  identity,meshStats:mesh.stats,buildSampleCalls,measurementQueries:queries,
  errorDefinition:old.errorDefinition,
  errorStream:{path:'errors.f64le',sha256:streamSHA,bytes:streamWritten,retained:true,encoding:'one Float64LE signed error in metres per node, no header, row-major increasing iz then ix'},
  historicalStream:{sha256:EXPECTED_OFF_STREAM,bytes:STREAM_BYTES,retained:false,interpretation:'Historical digest only. The new OFF file is an authenticated reproduction, not a recovered historical raw stream.'},
  histogram:old.histogram,maskDefinition:old.maskDefinition,worstCasePolicy:old.worstCasePolicy,
  aggregate,rings:ringResults,
  pairedComparison:paired&&pairRings?{offProvenance,comparison:'Strict absolute-error comparisons with no epsilon; equal includes opposite signs of equal magnitude. Threshold strictly >5m; top8 ties retain earlier row-major node.',
   aggregate:packPair(paired),rings:pairRings.map((group,ring)=>({ring,outerHalfExtentKm:Math.fround(128*.032*2**ring),...packPair(group)}))}:null,
  aggregateChangeFromHistorical:{allRMSMetres:Number(aggregate.all.rmsMetres)-Number(old.aggregate.all.rmsMetres),landRMSMetres:Number(aggregate.landMask.rmsMetres)-Number(old.aggregate.landMask.rmsMetres),seaRMSMetres:Number(aggregate.seaMask.rmsMetres)-Number(old.aggregate.seaMask.rmsMetres)},
  timings:{meshBuildMs:buildMs,coreQueryAndStreamWriteMs:performance.now()-queryStart,totalProgramMs:performance.now()-started},
  limits:['Same source nodes select and assess refinement: fit only, no holdout or continuous/areal error bound. A 5m selection threshold does not certify final error <=5m.',
   'Float32 mesh attributes with Float64 JS lookup/arithmetic; no GPU/WGSL parity, shadow causality, photographic or 60FPS claim.',
   'New triangle/normal/index values may differ. Only original position/surface prefixes and OFF five complete buffers are identity gates; no ON original faceIndex claim.',
   'Engine geometry-byte cap excludes CPU lookup arrays, temporary allocations, Maps and peak RSS. Terminal wrapper decides CPU/wall/sum-of-peaks RSS acceptance.',
   'Ring4 is sampled only inside measured ±48km, not its entire outer square; coast>=0 is a material mask, not independent land truth.']};
 const json=JSON.stringify(result,null,2)+'\n';check(Buffer.byteLength(json)<=MAX_OUTPUT_BYTES,'Bounded result JSON exceeded 4MiB');
 writeFileSync(resolve(output,'result.json'),json,{flag:'wx'});
 progress('complete',{mode,queries,errorStreamSHA256:streamSHA,streamBytes:streamWritten,resultBytes:Buffer.byteLength(json)});
 console.log(JSON.stringify({status:result.status,mode,measurementQueries:queries,errorStreamSHA256:streamSHA,resultBytes:Buffer.byteLength(json)}));
}
try{main();}catch(error){console.error(error instanceof Error?error.stack:String(error));process.exitCode=1;}
